
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from resilient_agent import ResilientAgent, AgentConfig, ATTACK_SCENARIOS
import logging

app = FastAPI(title="Resilient AI Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class RunRequest(BaseModel):
    input: str
    attack: str | None = None

@app.post("/run")
def run_agent(req: RunRequest):
    # `attack`, previously accepted but never used, now actually drives a
    # deterministic scenario against the real agent + real guardrails —
    # this is what the frontend's Attack Lab calls into.
    if req.attack and req.attack in ATTACK_SCENARIOS:
        scenario = ATTACK_SCENARIOS[req.attack]
        config = AgentConfig(
            max_iterations=5,
            max_retries=scenario.get("max_retries", 3),
            tool_timeout=2,
            allowed_tools=["search", "calculator", "file_read"] + scenario["extra_tools"],
        )
        agent = ResilientAgent(
            config,
            forced_action=scenario["forced_action"],
            force_repeat=scenario["force_repeat"],
        )
    else:
        config = AgentConfig(max_iterations=5, max_retries=3, tool_timeout=2)
        agent = ResilientAgent(config)

    result = agent.run(req.input)
    return result

@app.get("/attacks")
def list_attacks():
    return list(ATTACK_SCENARIOS.keys())

@app.get("/")
def root():
    return {"status": "Resilient Agent API running"}

