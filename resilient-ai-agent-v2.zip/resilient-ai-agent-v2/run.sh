#!/bin/bash
echo "Starting backend..."
cd backend
python3 -m uvicorn main:app --port 8000 &
BACKEND_PID=$!
cd ../frontend
echo "Starting frontend..."
npm install
npm run dev &
FRONTEND_PID=$!
wait
