# Resilient AI Agent — v2 (post-review fixes)

This is the original submission with every bug identified in review fixed
and re-verified by actually running the code, plus a real (not simulated)
connection between the frontend Attack Lab and the backend guardrails.

## Bugs fixed, each verified by direct reproduction before/after

1. **Crash on malformed LLM output (`UnboundLocalError`).**
   `"Unexpected output handling"` was listed as a feature, but feeding the
   agent a non-dict LLM response crashed with an unhandled `UnboundLocalError`
   (`tool_name` was referenced in the `except` block without ever being
   assigned). `run()` now pre-declares `tool_name`/`args` and explicitly
   checks `isinstance(llm_output, dict)`, so malformed output is now a
   logged, recoverable failure instead of a crash.

2. **Timeout that didn't actually bound anything.** `calculator_tool` used
   raw `eval()` behind a regex character allowlist, which still permitted
   `9**9**9` — a classic resource-exhaustion payload. Worse, the
   `ThreadPoolExecutor` was used as a context manager, whose `__exit__`
   blocks until the submitted thread *actually finishes* — so even after
   `future.result(timeout=...)` raised, the caller kept silently waiting for
   the tool's real duration anyway. Fixed two ways: the calculator is now
   AST-sandboxed (only a fixed set of numeric operators, `eval()` never
   runs), and the executor is now shut down with `wait=False` so a timeout
   actually returns control to the caller instead of blocking on it.

3. **False-positive loop detection.** The detector flagged a run the
   *first* time any exact output repeated across the whole run — with a
   demo picking randomly from 8 possible actions, a coincidental repeat by
   iteration 3-4 was close to guaranteed, and it wasn't testing anything
   about real repetition. It's now a sliding-window frequency check (same
   state 3+ times within the last 6 iterations), which catches genuine
   stuck loops (including simple alternation) without flagging normal
   variety. Residual false-positive rate against the random demo dropped
   from "almost every run" to about 1 in 3 — and that remainder is a known
   property of the toy `random.choice` mock, not the detector, since a real
   LLM doesn't uniformly sample a fixed action set.

4. **Trivially-bypassable malicious-input blocklist.** Exact substring
   checks like `"drop table" in v.lower()` let `"drop  table"` (double
   space) or `"drop\ttable"` straight through. Replaced with whitespace-
   flexible regexes. Still a blocklist — not a substitute for the
   calculator's AST sandbox or the path-traversal check — but meaningfully
   harder to bypass by accident or casual attempt.

5. **Per-request config was silently ignored.** `validate_tool_call` and
   the retry/timeout decorator read every setting off a module-level
   `CONFIG` global, not the `AgentConfig` instance actually passed into
   `ResilientAgent`. A per-request config built by the API (different
   timeout, different allowed tools) had no effect on validation or retry
   behavior — only `max_iterations` (read directly elsewhere) actually
   varied per instance. Both functions now take an explicit `config`
   argument threaded through from `ResilientAgent.run()`.

6. **Deterministic errors were retried anyway.** A bad tool name, a failed
   schema check, a blocked pattern, an invalid expression — none of these
   change on retry, but the old code retried them 3x with backoff regardless.
   These now fail fast (no retry), while genuinely transient-looking
   failures (`ConnectionError`, timeouts) still retry as before.

7. **Frontend and backend were completely disconnected.** The 960-line
   dashboard never made a single real network call — the only `fetch(` in
   the file was a hardcoded string used as *display text* inside a code
   snippet. Every attack outcome was scripted
   (`id === "malicious_input" ? "BLOCKED" : "HANDLED"`), regardless of what
   the Python guardrails would actually do. Now:
   - The API's `attack` field (accepted before, never used) drives a real
     deterministic scenario (`ATTACK_SCENARIOS` in `resilient_agent.py`) for
     all 7 attack types against the real guardrails.
   - The frontend does a real health check on load and a real
     `POST /run` call per attack, classifying BLOCKED vs HANDLED from the
     actual response — history, status, and error messages — not a
     hardcoded id check.
   - If the backend is unreachable, it falls back to the old animation, but
     the log now says `[SIMULATED — backend offline]` instead of silently
     presenting a scripted result as if it were real.

## Verification

Every fix above was confirmed with a direct before/after repro (not just
read/reasoned about). Run `python backend/resilient_agent.py` for the
built-in break-test suite. All 7 Attack Lab scenarios were run directly
through the same code path `main.py` uses and produce genuine, correct,
differentiated outcomes (see `ATTACK_SCENARIOS` in `resilient_agent.py`).

## Known limitations (not fixed, not hidden)

- The malicious-pattern check is still a blocklist. It's harder to bypass
  than before, but a blocklist is fundamentally reactive — it's not a
  substitute for the structural guarantees the calculator's AST sandbox and
  the path-traversal check provide.
- `mock_llm_decision`'s default (non-attack) path is still `random.choice`
  over a fixed scenario list — fine for a demo, not a stand-in for real LLM
  behavior.
- Orphaned background threads from a timed-out tool call are not forcibly
  killed (Python threads can't be) — they're abandoned and left to finish on
  their own. This is safe for the bundled demo tools (bounded sleep/compute)
  but would need a process-based executor (which *can* be terminated) to be
  safe against a genuinely unbounded/malicious tool in production.

## Run it

```
# backend
cd backend
pip install -r requirements.txt
python resilient_agent.py     # run break tests directly
uvicorn main:app --reload     # serve the API on :8000

# frontend (separate terminal)
cd frontend
npm install
npm run dev                   # http://localhost:5173 — auto-detects backend on :8000
```

Or both together: `./run.sh`
