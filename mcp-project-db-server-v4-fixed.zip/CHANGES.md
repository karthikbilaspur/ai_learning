# Changes from v3 → v4

1. **Auth**: `check_auth` now uses `secrets.compare_digest` (constant-time)
   instead of `!=`. Error messages no longer hint at the expected key.
   Documented limitation left in place: MCP tool args aren't a real auth
   transport — the key still travels as plain text in the tool call. If you
   need real secret hygiene, put an auth-aware proxy/gateway in front of this
   server rather than relying on the `api_key` tool argument.

2. **ID generation race condition**: `create()` no longer derives the new ID
   from `COUNT(*) + 1`. Postgres uses a `SEQUENCE`; the JSON backend uses a
   short uuid4-derived ID. This removes both the concurrent-write race and
   the reuse-after-delete collision bug.

3. **`analytics()` overdue count**: no longer reads `cur.rowcount` after a
   `SELECT` (driver-dependent, not part of the DB-API spec). Uses
   `SELECT COUNT(*)` instead.

4. **Structure**: `DB` (one class, if/else per method) split into
   `JSONBackend` / `PostgresBackend`, both implementing a small `Backend`
   ABC. Each method is backend-specific instead of interleaved.

5. **Error handling**: every `@mcp.tool()` now wraps backend calls in
   try/except and returns structured `{"error": ...}` JSON instead of
   letting exceptions propagate as raw tracebacks.

6. **Deadline validation**: `CreateProjectInput` now has a real
   `field_validator` on `deadline` (regex + `date.fromisoformat`) instead of
   importing `validator` and never using it.

7. **Log rotation**: `activity.log` rotates to `activity.log.1` once it
   exceeds ~1MB instead of growing unbounded.

## Not changed
- `docker-compose.yml`, `Dockerfile`, `init.sql`, `requirements.txt` are
  unchanged — no new dependencies were introduced.
- The overall tool/resource/prompt surface (`list_projects`, `get_project`,
  etc.) is identical, so this is a drop-in replacement for `server.py`.
