"""
Production MCP Server v4 - Real World (fixed)
Features: Postgres + JSON fallback, API Key Auth, Pydantic validation, Pagination, Analytics

Model -> MCP Client -> MCP Server (this file) -> Postgres (or JSON fallback) -> External System

Env:
  DATABASE_URL=postgresql://user:pass@localhost:5432/projects  # optional, falls back to JSON
  MCP_API_KEY=sk-secret-key  # optional, if set, all tools require it
  USE_JSON_FALLBACK=true     # set to true to force JSON even if DATABASE_URL exists

--- Changes from v3 ---
1. Auth uses secrets.compare_digest (constant-time) instead of `!=`, and error
   messages never echo back the expected key. NOTE: the underlying model is
   unchanged: MCP tool calls carry the key as a plain tool argument, not a
   transport header, so anything that can see prior tool calls (including the
   model itself) can see the key. That's inherent to doing auth this way over
   stdio MCP without a custom transport -- this fix makes the comparison safe,
   it does not make in-band key-passing a substitute for real transport auth.
   If you need real secret hygiene, terminate auth at a reverse proxy / MCP
   gateway in front of this server instead of inside tool args.
2. ID generation no longer uses COUNT(*)+1 (race condition + reuse-after-delete
   collisions). Postgres uses a proper SEQUENCE-backed id; JSON backend uses
   uuid4-derived short ids.
3. analytics() no longer relies on cur.rowcount after a SELECT (driver-dependent,
   not guaranteed by DB-API). Uses SELECT COUNT(*) instead.
4. DB access split into JSONBackend / PostgresBackend behind one interface
   instead of if/else in every method.
5. Every tool wraps backend calls in try/except and returns structured JSON
   errors instead of letting exceptions bubble up as raw tracebacks.
6. deadline is validated as real YYYY-MM-DD via a pydantic field_validator
   (the v3 file imported `validator` but never used it).
7. activity.log rotates once it exceeds ~1MB instead of growing unbounded.
"""

import os
import re
import json
import uuid
import secrets
import pathlib
import datetime
from typing import Optional, List, Literal
from contextlib import contextmanager
from abc import ABC, abstractmethod

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, field_validator
from dotenv import load_dotenv

load_dotenv()

DB_PATH = pathlib.Path(__file__).parent / "project_db.json"
LOG_PATH = pathlib.Path(__file__).parent / "activity.log"
LOG_MAX_BYTES = 1_000_000

VALID_STATUSES = ("planning", "active", "in_progress", "done", "archived")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# --- Auth ---
API_KEY = os.getenv("MCP_API_KEY")


def check_auth(provided_key: Optional[str] = None):
    """If MCP_API_KEY is set, require a matching key (constant-time compare).

    See module docstring point 1 for the limits of doing auth this way over
    stdio MCP -- this only fixes the comparison, not the transport.
    """
    if not API_KEY:
        return True  # auth disabled for educational / local mode
    key = provided_key or os.getenv("CLIENT_API_KEY") or os.getenv("X_API_KEY") or ""
    if not secrets.compare_digest(key, API_KEY):
        raise PermissionError("Unauthorized: invalid or missing API key.")
    return True


def _rotate_log_if_needed():
    if LOG_PATH.exists() and LOG_PATH.stat().st_size > LOG_MAX_BYTES:
        archive = LOG_PATH.with_suffix(".log.1")
        LOG_PATH.replace(archive)


def _append_log(line: str):
    _rotate_log_if_needed()
    with open(LOG_PATH, "a") as log:
        log.write(line + "\n")


def new_json_id(existing_ids) -> str:
    """Short, collision-resistant id that doesn't depend on row count."""
    existing = set(existing_ids)
    while True:
        candidate = "p" + uuid.uuid4().hex[:8]
        if candidate not in existing:
            return candidate


# ============ Backend interface ============
class Backend(ABC):
    @abstractmethod
    def list(self, status=None, owner=None, limit=50, offset=0): ...
    @abstractmethod
    def get(self, project_id: str): ...
    @abstractmethod
    def search(self, query: str, limit=20): ...
    @abstractmethod
    def create(self, proj: dict): ...
    @abstractmethod
    def update_status(self, project_id: str, new_status: str): ...
    @abstractmethod
    def delete(self, project_id: str): ...
    @abstractmethod
    def analytics(self): ...
    @abstractmethod
    def overdue(self): ...


class JSONBackend(Backend):
    def _load(self):
        if not DB_PATH.exists():
            return {"projects": []}
        return json.loads(DB_PATH.read_text())

    def _save(self, data):
        DB_PATH.write_text(json.dumps(data, indent=2))
        _append_log(f"{datetime.datetime.now().isoformat()} save {len(data['projects'])}")

    def list(self, status=None, owner=None, limit=50, offset=0):
        data = self._load()["projects"]
        if status:
            data = [p for p in data if p["status"] == status]
        if owner:
            data = [p for p in data if owner.lower() in p["owner"].lower()]
        return data[offset:offset + limit]

    def get(self, project_id: str):
        for p in self._load()["projects"]:
            if p["id"] == project_id:
                return p
        return None

    def search(self, query: str, limit=20):
        q = query.lower()
        return [p for p in self._load()["projects"] if q in json.dumps(p).lower()][:limit]

    def create(self, proj: dict):
        data = self._load()
        existing_ids = [p["id"] for p in data["projects"]]
        proj["id"] = new_json_id(existing_ids)
        proj.setdefault("created_at", datetime.datetime.now().isoformat())
        data["projects"].append(proj)
        self._save(data)
        return proj

    def update_status(self, project_id: str, new_status: str):
        data = self._load()
        for p in data["projects"]:
            if p["id"] == project_id:
                p["status"] = new_status
                self._save(data)
                return p
        return None

    def delete(self, project_id: str):
        data = self._load()
        before = len(data["projects"])
        data["projects"] = [p for p in data["projects"] if p["id"] != project_id]
        after = len(data["projects"])
        if after != before:
            self._save(data)
        return {"deleted": project_id, "before": before, "after": after, "removed": before != after}

    def analytics(self):
        projs = self._load()["projects"]
        by_status, by_owner, total = {}, {}, 0
        for p in projs:
            by_status[p["status"]] = by_status.get(p["status"], 0) + 1
            by_owner[p["owner"]] = by_owner.get(p["owner"], 0) + p.get("budget_usd", 0)
            total += p.get("budget_usd", 0)
        today = datetime.date.today().isoformat()
        overdue_count = len([
            p for p in projs
            if p.get("deadline") and p["deadline"] < today and p["status"] not in ("done", "archived")
        ])
        return {
            "total_projects": len(projs),
            "total_budget": total,
            "by_status": by_status,
            "by_owner": by_owner,
            "overdue_count": overdue_count,
        }

    def overdue(self):
        today = datetime.date.today().isoformat()
        return [
            p for p in self._load()["projects"]
            if p.get("deadline") and p["deadline"] < today and p["status"] not in ("done", "archived")
        ]


class PostgresBackend(Backend):
    def __init__(self, conn_str: str, psycopg2_module):
        self.conn_str = conn_str
        self.psycopg2 = psycopg2_module
        self._ensure_schema()

    @contextmanager
    def conn(self):
        c = self.psycopg2.connect(self.conn_str)
        try:
            yield c
        finally:
            c.close()

    def _ensure_schema(self):
        sql = """
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('planning','active','in_progress','done','archived')),
            owner TEXT NOT NULL,
            stack JSONB DEFAULT '[]',
            deadline DATE,
            budget_usd INTEGER DEFAULT 0,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );
        CREATE SEQUENCE IF NOT EXISTS projects_id_seq;
        """
        with self.conn() as c, c.cursor() as cur:
            cur.execute(sql)
            cur.execute("SELECT COUNT(*) FROM projects")
            if cur.fetchone()[0] == 0 and DB_PATH.exists():
                data = json.loads(DB_PATH.read_text())
                for p in data.get("projects", []):
                    cur.execute(
                        "INSERT INTO projects (id,name,status,owner,stack,deadline,budget_usd) "
                        "VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING",
                        (p["id"], p["name"], p["status"], p["owner"], json.dumps(p.get("stack", [])),
                         p.get("deadline") or None, p.get("budget_usd", 0)),
                    )
            c.commit()

    def list(self, status=None, owner=None, limit=50, offset=0):
        with self.conn() as c, c.cursor() as cur:
            q = "SELECT id,name,status,owner,stack,deadline,budget_usd,created_at FROM projects WHERE 1=1"
            params = []
            if status:
                q += " AND status=%s"; params.append(status)
            if owner:
                q += " AND owner ILIKE %s"; params.append(f"%{owner}%")
            q += " ORDER BY updated_at DESC LIMIT %s OFFSET %s"
            params.extend([limit, offset])
            cur.execute(q, params)
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def get(self, project_id: str):
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                "SELECT id,name,status,owner,stack,deadline,budget_usd FROM projects WHERE id=%s",
                (project_id,),
            )
            row = cur.fetchone()
            if not row:
                return None
            cols = [d[0] for d in cur.description]
            return dict(zip(cols, row))

    def search(self, query: str, limit=20):
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                "SELECT id,name,status,owner,stack FROM projects "
                "WHERE name ILIKE %s OR owner ILIKE %s OR stack::text ILIKE %s LIMIT %s",
                (f"%{query}%", f"%{query}%", f"%{query}%", limit),
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]

    def create(self, proj: dict):
        with self.conn() as c, c.cursor() as cur:
            # SEQUENCE-backed id: no COUNT(*) race, no reuse-after-delete collisions.
            cur.execute("SELECT nextval('projects_id_seq')")
            seq = cur.fetchone()[0]
            pid = proj.get("id") or f"p{seq}"
            cur.execute(
                "INSERT INTO projects (id,name,status,owner,stack,deadline,budget_usd) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id",
                (pid, proj["name"], proj["status"], proj["owner"], json.dumps(proj.get("stack", [])),
                 proj.get("deadline"), proj.get("budget_usd", 0)),
            )
            c.commit()
            return self.get(pid)

    def update_status(self, project_id: str, new_status: str):
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                "UPDATE projects SET status=%s, updated_at=NOW() WHERE id=%s RETURNING id",
                (new_status, project_id),
            )
            c.commit()
            if cur.rowcount == 0:
                return None
            return self.get(project_id)

    def delete(self, project_id: str):
        with self.conn() as c, c.cursor() as cur:
            cur.execute("DELETE FROM projects WHERE id=%s", (project_id,))
            c.commit()
            return {"deleted": project_id, "removed": cur.rowcount > 0, "rows": cur.rowcount}

    def analytics(self):
        with self.conn() as c, c.cursor() as cur:
            cur.execute("SELECT status, COUNT(*), SUM(budget_usd), AVG(budget_usd) FROM projects GROUP BY status")
            by_status = [{"status": r[0], "count": r[1], "total_budget": r[2], "avg_budget": float(r[3] or 0)}
                         for r in cur.fetchall()]
            cur.execute("SELECT SUM(budget_usd), COUNT(*), MAX(budget_usd) FROM projects")
            total, count, max_b = cur.fetchone()
            cur.execute("SELECT owner, COUNT(*), SUM(budget_usd) FROM projects GROUP BY owner")
            by_owner = [{"owner": r[0], "count": r[1], "budget": r[2]} for r in cur.fetchall()]
            # Fixed: was `cur.rowcount` after a SELECT, which is driver-dependent.
            cur.execute(
                "SELECT COUNT(*) FROM projects WHERE deadline < CURRENT_DATE "
                "AND status NOT IN ('done','archived')"
            )
            overdue_count = cur.fetchone()[0]
            return {
                "by_status": by_status,
                "total_budget": total or 0,
                "total_projects": count,
                "max_budget": max_b,
                "by_owner": by_owner,
                "overdue_count": overdue_count,
            }

    def overdue(self):
        with self.conn() as c, c.cursor() as cur:
            cur.execute(
                "SELECT id,name,deadline,status,owner FROM projects "
                "WHERE deadline < CURRENT_DATE AND status NOT IN ('done','archived')"
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]


def build_backend() -> Backend:
    conn_str = os.getenv("DATABASE_URL")
    force_json = os.getenv("USE_JSON_FALLBACK", "false").lower() == "true"
    if conn_str and not force_json:
        try:
            import psycopg2
            test = psycopg2.connect(conn_str)
            test.close()
            print(f"[DB] Using Postgres: {conn_str[:30]}...")
            return PostgresBackend(conn_str, psycopg2)
        except Exception as e:
            print(f"[DB] Postgres failed ({e}), falling back to JSON")
    print("[DB] Using JSON fallback:", DB_PATH)
    return JSONBackend()


db = build_backend()
mcp = FastMCP("project-db-prod")


# ============ Pydantic Schemas ============
class CreateProjectInput(BaseModel):
    name: str = Field(..., min_length=2, max_length=100, description="Project name")
    owner: str = Field(..., min_length=2, description="Owner name")
    status: Literal["planning", "active", "in_progress", "done", "archived"] = "planning"
    stack: str = Field("", description="Comma separated tech stack, e.g. Python,FastAPI")
    budget_usd: int = Field(0, ge=0, le=1_000_000)
    deadline: Optional[str] = Field(None, description="YYYY-MM-DD")

    @field_validator("deadline")
    @classmethod
    def validate_deadline(cls, v):
        if v is None or v == "":
            return None
        if not DATE_RE.match(v):
            raise ValueError("deadline must be in YYYY-MM-DD format")
        try:
            datetime.date.fromisoformat(v)
        except ValueError:
            raise ValueError("deadline is not a real calendar date")
        return v


def _err(msg: str, **extra) -> str:
    return json.dumps({"error": msg, **extra}, indent=2, default=str)


# ============ Resources ============
@mcp.resource("projects://all")
def res_all() -> str:
    return json.dumps(db.list(limit=100), indent=2, default=str)


@mcp.resource("projects://stats")
def res_stats() -> str:
    return json.dumps(db.analytics(), indent=2, default=str)


@mcp.resource("projects://activity")
def res_activity() -> str:
    if not LOG_PATH.exists():
        return "No activity yet"
    return LOG_PATH.read_text()[-3000:]


@mcp.resource("projects://{project_id}")
def res_one(project_id: str) -> str:
    proj = db.get(project_id)
    return json.dumps(proj or {"error": "not found"}, indent=2, default=str)


# ============ Tools ============
@mcp.tool()
def list_projects(status: str = "", owner: str = "", limit: int = 20, offset: int = 0, api_key: str = "") -> str:
    """List projects with filtering + pagination. Use status filter e.g. active, limit 1-100."""
    try:
        check_auth(api_key)
        if status and status not in VALID_STATUSES:
            return _err(f"Invalid status '{status}'", valid=list(VALID_STATUSES))
        limit = max(1, min(limit, 100))
        offset = max(0, offset)
        result = db.list(status=status or None, owner=owner or None, limit=limit, offset=offset)
        return json.dumps(result, indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def get_project(project_id: str, api_key: str = "") -> str:
    """Get one project by ID."""
    try:
        check_auth(api_key)
        proj = db.get(project_id)
        if not proj:
            return _err("not found", hint="Use list_projects to see IDs")
        return json.dumps(proj, indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def search_projects(query: str, limit: int = 20, api_key: str = "") -> str:
    """Search by name, owner, or stack."""
    try:
        check_auth(api_key)
        limit = max(1, min(limit, 100))
        return json.dumps(db.search(query, limit), indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def create_project(name: str, owner: str, status: str = "planning", stack: str = "",
                    budget_usd: int = 0, deadline: str = "", api_key: str = "") -> str:
    """Create project with validation. Auth required if MCP_API_KEY set."""
    try:
        check_auth(api_key)
        validated = CreateProjectInput(
            name=name, owner=owner, status=status, stack=stack,
            budget_usd=budget_usd, deadline=deadline or None,
        )
        proj_dict = {
            "name": validated.name,
            "owner": validated.owner,
            "status": validated.status,
            "stack": [s.strip() for s in validated.stack.split(",") if s.strip()],
            "budget_usd": validated.budget_usd,
            "deadline": validated.deadline,
        }
        created = db.create(proj_dict)
        return json.dumps({"created": created}, indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except ValueError as e:
        return _err("validation error", detail=str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def update_project_status(project_id: str, new_status: str, api_key: str = "") -> str:
    """Update status: planning, active, in_progress, done, archived."""
    try:
        check_auth(api_key)
        if new_status not in VALID_STATUSES:
            return _err(f"Invalid status '{new_status}'", valid=list(VALID_STATUSES))
        updated = db.update_status(project_id, new_status)
        if not updated:
            return _err("not found")
        return json.dumps({"updated": updated}, indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def delete_project(project_id: str, api_key: str = "") -> str:
    """Delete a project (dangerous, requires MCP_API_KEY to be set on the server)."""
    try:
        check_auth(api_key)
        if not API_KEY:
            return _err("Delete requires MCP_API_KEY to be set for safety")
        result = db.delete(project_id)
        if not result.get("removed"):
            return _err("not found")
        return json.dumps(result, indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def analytics_dashboard(api_key: str = "") -> str:
    """Full analytics: by_status, by_owner, total_budget, overdue. Use for reports."""
    try:
        check_auth(api_key)
        return json.dumps(db.analytics(), indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def budget_summary(api_key: str = "") -> str:
    """Quick budget summary."""
    try:
        check_auth(api_key)
        a = db.analytics()
        return json.dumps(
            {"total_budget": a.get("total_budget"), "by_owner": a.get("by_owner"), "by_status": a.get("by_status")},
            indent=2, default=str,
        )
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


@mcp.tool()
def overdue_projects(api_key: str = "") -> str:
    """List projects past deadline and not done."""
    try:
        check_auth(api_key)
        return json.dumps(db.overdue(), indent=2, default=str)
    except PermissionError as e:
        return _err(str(e))
    except Exception as e:
        return _err("internal error", detail=str(e))


# ============ Prompts ============
@mcp.prompt()
def project_status_report() -> str:
    db_data = db.list(limit=100)
    analytics = db.analytics()
    return f"""You are a project manager. Data:

Projects: {json.dumps(db_data, indent=2, default=str)}

Analytics: {json.dumps(analytics, indent=2, default=str)}

Create:
1. Markdown table ID | Name | Status | Owner | Budget | Deadline
2. 3 risks (overdue, high budget in planning, owner overloaded)
3. Budget insights from analytics
4. Recommended next 3 actions
"""


@mcp.prompt()
def budget_review() -> str:
    return f"""Review budgets using:

{json.dumps(db.analytics(), indent=2, default=str)}

Identify overspend, underutilized budgets, and suggest reallocations.
"""


if __name__ == "__main__":
    mcp.run()
