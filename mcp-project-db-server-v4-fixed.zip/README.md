# MCP Server v3 — Production: Postgres + Auth + Analytics

![Architecture](architecture.png)

## What's new from v2 -> v3 (Real-World)

### 1. Postgres + JSON fallback (DB abstraction)
`DB` class tries `DATABASE_URL`. If it fails or `USE_JSON_FALLBACK=true`, uses `project_db.json`. So you can demo without Postgres, but deploy with it.

- Table: `projects` with CHECK constraint on status, JSONB for stack, timestamps
- Auto-seed from JSON if table empty
- `init.sql` + `docker-compose.yml` included

### 2. Auth
Set `MCP_API_KEY` in server env. Then every tool requires `api_key` arg.

Claude Desktop config:
```json
{
  "mcpServers": {
    "project-db": {
      "command": "python",
      "args": ["/path/to/server.py"],
      "env": { "CLIENT_API_KEY": "sk-secret", "DATABASE_URL": "postgresql://..." }
    }
  }
}
```

In code `check_auth(api_key)` validates. If `MCP_API_KEY` not set, auth disabled (edu mode).

Why auth in MCP? Model never sees real DB creds, only API key to MCP server. DB URL stays server-side.

### 3. Pydantic Validation
`CreateProjectInput` validates name length, status enum, budget 0-1M, deadline format. Model can't insert garbage.

### 4. Pagination & Filtering
`list_projects(status, owner, limit 1-100, offset)` — prevents LLM dumping 10k rows into context.

### 5. Analytics Tools (so model doesn't calculate)
- `analytics_dashboard()` -> by_status counts, sum, avg, by_owner, overdue
- `budget_summary()` -> quick total + breakdown
- `overdue_projects()` -> date comparison in SQL (not in LLM)
- `delete_project()` -> dangerous tool guarded by auth

SQL version uses real `GROUP BY`, `SUM`, `WHERE deadline < CURRENT_DATE` — shows off why DB > JSON.

### 6. Prompts upgraded
- `project_status_report` now injects both list + analytics
- `budget_review` — finance focused

## Run

### Quick (JSON)
```bash
pip install -r requirements.txt
python server.py
npx @modelcontextprotocol/inspector python server.py
```

### Full Postgres (Docker)
```bash
docker-compose up --build
# or locally:
createdb projects
psql projects < init.sql
export DATABASE_URL=postgresql://postgres:postgres@localhost:5432/projects
export MCP_API_KEY=sk-test123
python server.py
```

Test prompts in Inspector:
- Tools: `analytics_dashboard`, `overdue_projects`, `list_projects(status="active", limit=2)`
- Prompts: `project_status_report`

## Architecture: Model -> Client -> Server -> Tools/Resources/Prompts -> Postgres

Model never touches Postgres. Server is the gatekeeper with auth + validation + analytics.

## Files
- server.py — production server (330 lines)
- project_db.json — fallback DB
- init.sql — Postgres schema
- .env.example — env template
- docker-compose.yml + Dockerfile — one-command prod
- architecture.png — diagram
