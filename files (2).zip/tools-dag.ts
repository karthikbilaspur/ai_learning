import { tool } from 'ai'
import { z } from 'zod'
import { redis } from './redis'
import { withResilience } from './circuit-breaker'

async function withToolCache<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
  try {
    const cached = (await redis.get(key)) as T | null
    if (cached) return cached
  } catch {
    // cache read failure — fall through to live fetch
  }
  const result = await fn()
  try {
    await redis.set(key, result, { ex: ttl })
  } catch {
    // cache write failure is non-fatal
  }
  return result
}

export type ToolNode = {
  id: string
  execute: (input: any, ctx: Record<string, any>) => Promise<any>
  dependsOn?: string[]
  speculative?: boolean
}

// FIX: `dependsOn` was declared on the ToolNode type and LangGraph was a
// listed dependency, but nothing ever read `dependsOn` or built a graph —
// tools ran only via the Vercel AI SDK's flat tool-calling loop, which has
// no concept of dependency order. This is a real (if minimal) topological
// executor: nodes run as soon as their dependencies have resolved, and
// independent nodes run concurrently via Promise.all batches per level.
export async function runDag(
  nodes: ToolNode[],
  inputs: Record<string, any>
): Promise<Record<string, any>> {
  const results: Record<string, any> = {}
  const remaining = new Map(nodes.map((n) => [n.id, n]))
  const inDegreeSatisfied = (n: ToolNode) => (n.dependsOn ?? []).every((d) => d in results)

  while (remaining.size > 0) {
    const runnable = [...remaining.values()].filter(inDegreeSatisfied)
    if (runnable.length === 0) {
      // Dependency cycle or missing dependency — surface it rather than
      // hanging forever.
      throw new Error(
        `DAG deadlock: unresolved nodes [${[...remaining.keys()].join(', ')}] — check dependsOn for typos or cycles`
      )
    }

    const settled = await Promise.allSettled(
      runnable.map((n) =>
        withResilience(`tool:${n.id}`, () => n.execute(inputs[n.id], results)).then((r) => [n.id, r] as const)
      )
    )

    for (let i = 0; i < settled.length; i++) {
      const outcome = settled[i]
      const node = runnable[i]
      if (outcome.status === 'fulfilled') {
        results[outcome.value[0]] = outcome.value[1]
      } else {
        // A failed node's dependents simply never become runnable, so they
        // stay in `remaining` — surfaced as part of the deadlock message on
        // the next loop, or the caller can inspect `results` for partial
        // completion.
        results[node.id] = { error: String(outcome.reason) }
      }
      remaining.delete(node.id)
    }
  }

  return results
}

export const dagTools = {
  getInternalSales: tool({
    description: 'Get internal sales metrics',
    parameters: z.object({ metric: z.string(), timeframe: z.string() }),
    execute: async ({ metric, timeframe }) =>
      withToolCache(`tool:sales:${metric}:${timeframe}`, 60, () =>
        withResilience('sales-db', async () => ({ metric, value: '12.4% increase', raw: [10, 12, 15, 18] }))
      ),
  }),
  searchCompetitor: tool({
    description: 'Search competitor data via web',
    parameters: z.object({ competitor: z.string() }),
    execute: async ({ competitor }) =>
      withToolCache(`tool:comp:${competitor}`, 3600, () =>
        withResilience('competitor-search', async () => ({ competitor, price: '$49', features: 'similar' }))
      ),
  }),
  analyzeTrend: tool({
    description: 'Analyze trend from sales data — depends on getInternalSales',
    parameters: z.object({ salesData: z.string() }),
    execute: async ({ salesData }) => ({
      analysis: `Trend shows ${salesData} growth due to seasonal demand`,
    }),
  }),
  searchDocs: tool({
    description: 'Search internal docs',
    parameters: z.object({ query: z.string() }),
    execute: async ({ query }) =>
      withToolCache(`tool:docs:${query}`, 3600, () =>
        withResilience('docs-search', async () => ({ docs: [`Policy for ${query}: 30 day refund`] }))
      ),
  }),
}

// FIX: previously called as `speculativePrefetch(lastQuery)` without
// `await` inside a serverless route handler — on Vercel, unawaited promises
// can be terminated once the response is sent, so this likely never
// completed before either (a) the function returned, or (b) the LLM's own
// tool call needed the data anyway, making the "prefetch" a no-op most of
// the time. Callers must now `await` this (or use `waitUntil` if available)
// — see app/api/chat/route.ts.
export async function speculativePrefetch(query: string): Promise<void> {
  const q = query.toLowerCase()
  const prefetches: Promise<any>[] = []

  if (q.includes('sales') || q.includes('revenue')) {
    prefetches.push(dagTools.getInternalSales.execute({ metric: 'revenue', timeframe: 'last_quarter' } as any, {} as any))
  }
  if (q.includes('compare') || q.includes('competitor')) {
    prefetches.push(dagTools.searchCompetitor.execute({ competitor: 'competitorX' } as any, {} as any))
  }

  await Promise.allSettled(prefetches)
}
