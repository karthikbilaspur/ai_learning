import {
  circuitBreaker,
  ConsecutiveBreaker,
  handleAll,
  retry,
  ExponentialBackoff,
  wrap,
  CircuitState,
} from 'cockatiel'

// One breaker per external dependency, so a failing vector DB doesn't trip
// the breaker for, say, the sales tool. Each breaker opens after 5
// consecutive failures and stays open for 10s before allowing a half-open
// probe request through.
const breakers = new Map<string, ReturnType<typeof circuitBreaker>>()

function getBreaker(key: string) {
  let b = breakers.get(key)
  if (!b) {
    b = circuitBreaker(handleAll, {
      halfOpenAfter: 10_000,
      breaker: new ConsecutiveBreaker(5),
    })
    breakers.set(key, b)
  }
  return b
}

// retry (3 attempts, exponential backoff) wrapped INSIDE the circuit breaker,
// so retries count toward the failure threshold instead of masking it.
export function withResilience<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const retryPolicy = retry(handleAll, { maxAttempts: 3, backoff: new ExponentialBackoff() })
  const breaker = getBreaker(key)
  const policy = wrap(retryPolicy, breaker)
  return policy.execute(() => fn())
}

export function breakerState(key: string): CircuitState | 'unknown' {
  return breakers.get(key)?.state ?? 'unknown'
}

export function allBreakerStates(): Record<string, CircuitState> {
  const out: Record<string, CircuitState> = {}
  for (const [k, b] of breakers) out[k] = b.state
  return out
}
