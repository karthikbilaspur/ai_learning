import { Redis } from '@upstash/redis'
import { Index } from '@upstash/vector'
import { Ratelimit } from '@upstash/ratelimit'

export const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

export const vectorIndex = new Index({
  url: process.env.UPSTASH_VECTOR_REST_URL!,
  token: process.env.UPSTASH_VECTOR_REST_TOKEN!,
})

// 20 req/min per user
export const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(20, '1 m'),
})

// Bloom-filter-style pre-check to avoid embedding obviously non-cacheable
// queries. (Named accurately now — this is a heuristic filter, not an
// actual Bloom filter data structure.)
export function isCacheableQuery(query: string): boolean {
  if (!query || query.length < 10 || query.length > 500) return false
  if (/\d{6,}/.test(query)) return false // looks like an ID / order number
  if (query.split(' ').length < 3) return false
  return true
}

// FIX: exact-match cache previously had no tenant scoping in its key
// (`exact:${hash}`) while the vector-tier cache did (`cache:${tenantId}:...`).
// That meant tenant A's cached answer to a verbatim-identical query could be
// served to tenant B. All cache key construction now goes through these two
// helpers so the two tiers can't drift apart again.
export function exactCacheKey(tenantId: string, hash: string) {
  return `exact:${tenantId}:${hash}`
}

export function vectorCacheKey(tenantId: string, cacheId: string) {
  return `cache:${tenantId}:${cacheId}`
}

export async function incrCacheHit() {
  try {
    await redis.incr('stats:cache_hit_tier2')
  } catch {
    // stats are best-effort — never let a metrics failure break the request
  }
}

// FIX: this counter was read by /api/cache/stats but nothing ever
// incremented it, so hitRate was always computed as 100%.
export async function incrCacheMiss() {
  try {
    await redis.incr('stats:cache_miss')
  } catch {
    // best-effort
  }
}
