import { vectorIndex, redis, exactCacheKey, vectorCacheKey, incrCacheHit, incrCacheMiss } from './redis'
import { withResilience } from './circuit-breaker'
import { generateObject } from 'ai'
import { anthropic } from '@ai-sdk/anthropic'
import { z } from 'zod'
import OpenAI from 'openai'
import crypto from 'crypto'

const openai = new OpenAI()
const THRESHOLD = 0.92

async function openaiEmbedding(text: string): Promise<number[]> {
  return withResilience('openai-embedding', async () => {
    const r = await openai.embeddings.create({ model: 'text-embedding-3-small', input: text })
    return r.data[0].embedding
  })
}

async function checkExactCache(query: string, tenantId: string) {
  const hash = crypto.createHash('sha256').update(query.trim().toLowerCase()).digest('hex')
  const cached = (await redis.get(exactCacheKey(tenantId, hash))) as any
  if (cached) {
    await redis.zincrby('cache:popular', 1, hash)
    return cached
  }
  return null
}

// FIX: this used to be a bare `if (top.score > THRESHOLD)` — the code
// comment claimed "re-rank with Haiku to avoid false positives" but no such
// call existed. Vector similarity measures surface-level closeness, not
// whether the cached answer actually answers the new query (e.g. "sales
// last quarter" vs "sales next quarter" embed close but need different
// answers). This now asks Haiku directly.
const rerankSchema = z.object({
  sameIntent: z.boolean(),
  confidence: z.number().min(0).max(1),
})

async function rerankMatch(newQuery: string, cachedQuery: string): Promise<boolean> {
  try {
    const { object } = await withResilience('haiku-rerank', () =>
      generateObject({
        model: anthropic('claude-3-5-haiku-20241022'),
        schema: rerankSchema,
        prompt: `Query A: "${newQuery}"\nQuery B: "${cachedQuery}"\n\nWould the correct answer to Query A also correctly and completely answer Query B (same intent, same time frame, same entities)? Be strict — reject if timeframe, scope, or subject differs even slightly.`,
      })
    )
    return object.sameIntent && object.confidence >= 0.7
  } catch {
    // If the re-rank call itself fails, fail closed: treat as a miss rather
    // than risk serving a wrong cached answer.
    return false
  }
}

export async function checkSemanticCacheV2(query: string, tenantId = 'default') {
  const exact = await checkExactCache(query, tenantId)
  if (exact) {
    await incrCacheHit()
    return { hit: true, tier: 1, answer: exact.answer, score: 1.0, model: exact.model }
  }

  let embedding: number[]
  try {
    embedding = await openaiEmbedding(query)
  } catch {
    // Embedding provider down — degrade to cache miss rather than 500ing.
    await incrCacheMiss()
    return { hit: false, degraded: true }
  }

  const results = await withResilience('vector-query', () =>
    vectorIndex.query({ vector: embedding, topK: 3, includeMetadata: true })
  )

  if (!results || results.length === 0) {
    await incrCacheMiss()
    return { hit: false }
  }

  const top = results[0]
  if (top.score > THRESHOLD) {
    const cacheId = top.metadata?.cacheId as string
    const cachedQuery = (top.metadata?.query as string) ?? ''
    const cached = (await redis.get(vectorCacheKey(tenantId, cacheId))) as any

    if (cached) {
      const confirmed = await rerankMatch(query, cachedQuery)
      if (confirmed) {
        await redis.zincrby('cache:popular', 1, cacheId)
        await incrCacheHit()
        return { hit: true, tier: 2, answer: cached.answer, score: top.score, model: cached.model }
      }
    }
  }

  await incrCacheMiss()
  return { hit: false, score: results[0]?.score ?? 0 }
}

// FIX: caller previously passed `routing.tier` (e.g. "large") into the
// `model` parameter here — a mismatched-argument bug. Signature unchanged,
// but see app/api/chat/route.ts for the corrected call site.
export async function setCacheV2(query: string, answer: string, model: string, tenantId = 'default') {
  if (answer.length < 50) return
  const hash = crypto.createHash('sha256').update(query.trim().toLowerCase()).digest('hex')
  const cacheId = crypto.randomUUID()

  try {
    await redis.set(exactCacheKey(tenantId, hash), { answer, model }, { ex: 60 * 60 * 24 * 7 })
    const embedding = await openaiEmbedding(query)
    await vectorIndex.upsert([
      { id: cacheId, vector: embedding, metadata: { cacheId, query: query.slice(0, 200) } },
    ])
    await redis.set(vectorCacheKey(tenantId, cacheId), { answer, model, query }, { ex: 60 * 60 * 24 * 7 })
  } catch {
    // Caching is an optimization, not a correctness requirement — a failed
    // write shouldn't fail the user-facing request that triggered it.
  }
}
