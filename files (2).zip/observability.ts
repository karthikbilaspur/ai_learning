import { Langfuse } from 'langfuse'
import { computeCost } from './pricing'

export const langfuse = new Langfuse({
  secretKey: process.env.LANGFUSE_SECRET_KEY!,
  publicKey: process.env.LANGFUSE_PUBLIC_KEY!,
  baseUrl: process.env.LANGFUSE_HOST || 'https://cloud.langfuse.com',
})

export async function traceQuery(data: {
  query: string
  cacheHit: boolean
  tier: string
  modelId: string
  cacheScore?: number
  toolLatency?: number
  ttft?: number
  cost?: number
}) {
  try {
    langfuse.trace({
      name: 'ai-gateway-query',
      metadata: data,
      tags: [data.tier, data.cacheHit ? 'cache_hit' : 'cache_miss'],
    })
    // FIX: Langfuse batches events client-side and nothing previously
    // flushed the batch before the serverless function's execution context
    // could be frozen or torn down, so traces could be silently dropped.
    await langfuse.flushAsync()
  } catch {
    // Observability must never break the user-facing request.
  }
}

// FIX: this used to duplicate its own pricing table that could (and did)
// drift from router-v2.ts's MODEL_PRICING. Now delegates to the single
// shared table in lib/pricing.ts.
export { computeCost }
