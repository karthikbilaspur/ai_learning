import { anthropic } from '@ai-sdk/anthropic'
import { generateObject } from 'ai'
import { z } from 'zod'
import { withResilience } from './circuit-breaker'
import { ModelId } from './pricing'

export type Tier = 'tiny' | 'small' | 'large' | 'critical'

const schema = z.object({
  type: z.enum(['SIMPLE_FACTUAL', 'REASONING', 'NEEDS_TOOLS', 'CRITICAL_CODE']),
  confidence: z.number().min(0).max(1),
  reason: z.string(),
  needsTools: z.boolean(),
})

// FIX: previously the regex fast-path and the Haiku-classifier slow-path
// each hardcoded their own tier->model mapping, and they disagreed —
// fast-path sent CRITICAL_CODE to claude-opus-4, slow-path's `mapping`
// table sent the same label to gpt-4o. Same classification, two different
// models depending on which branch happened to catch the query. Both
// branches now resolve through this single table.
export const TIER_MODEL: Record<Tier, ModelId> = {
  tiny: 'gpt-4o-mini',
  small: 'claude-3-5-haiku-20241022',
  large: 'claude-sonnet-4-20250514',
  critical: 'claude-opus-4-20250514',
}

const TYPE_TO_TIER: Record<z.infer<typeof schema>['type'], Tier> = {
  SIMPLE_FACTUAL: 'tiny',
  REASONING: 'small',
  NEEDS_TOOLS: 'large',
  CRITICAL_CODE: 'critical',
}

export async function routeQueryV2(query: string): Promise<{ tier: Tier; modelId: string; meta: any }> {
  const q = query.toLowerCase()

  // Fast path: regex heuristics — ~5ms, replaces a fine-tuned classifier for MVP
  if (q.length < 40 && !q.includes('compare') && !q.includes('analyze') && !q.includes('why')) {
    const tier: Tier = 'tiny'
    return { tier, modelId: TIER_MODEL[tier], meta: { type: 'SIMPLE_FACTUAL', confidence: 0.9 } }
  }
  if (q.includes('code') || q.includes('bug') || q.includes('error') || q.includes('algorithm')) {
    const tier: Tier = 'critical'
    return { tier, modelId: TIER_MODEL[tier], meta: { type: 'CRITICAL_CODE', confidence: 0.85 } }
  }
  if (q.includes('compare') || q.includes('sales') || q.includes('search') || q.includes('find')) {
    const tier: Tier = 'large'
    return { tier, modelId: TIER_MODEL[tier], meta: { type: 'NEEDS_TOOLS', confidence: 0.8 } }
  }

  // Slow path: Haiku classification for ambiguous queries, wrapped with
  // retry + circuit breaker, with a safe fallback if the classifier itself
  // is unavailable.
  try {
    const { object } = await withResilience('router-haiku', () =>
      generateObject({
        model: anthropic('claude-3-5-haiku-20241022'),
        schema,
        prompt: `Classify this query: "${query}"\n\nOptions:\n- SIMPLE_FACTUAL: direct lookup, no reasoning\n- REASONING: needs explanation or multi-step thought\n- NEEDS_TOOLS: needs search, database, or external data\n- CRITICAL_CODE: code generation, debugging, or algorithm design\n\nReturn type, confidence (0-1), reason, and whether tools are needed.`,
      })
    )
    const tier = TYPE_TO_TIER[object.type]
    return { tier, modelId: TIER_MODEL[tier], meta: object }
  } catch {
    // Classifier unavailable — fail to a safe middle tier rather than 500ing
    // the whole request.
    const tier: Tier = 'small'
    return {
      tier,
      modelId: TIER_MODEL[tier],
      meta: { type: 'REASONING', confidence: 0, reason: 'classifier_unavailable_fallback' },
    }
  }
}
