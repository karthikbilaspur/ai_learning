import { streamText, convertToCoreMessages } from 'ai'
import { anthropic } from '@ai-sdk/anthropic'
import { openai } from '@ai-sdk/openai'
import { checkSemanticCacheV2, setCacheV2 } from '@/lib/semantic-cache-v2'
import { routeQueryV2 } from '@/lib/router-v2'
import { dagTools, speculativePrefetch } from '@/lib/tools-dag'
import { traceQuery, computeCost } from '@/lib/observability'
import { ratelimit, isCacheableQuery, redis } from '@/lib/redis'

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages, tenantId = 'default' } = await req.json()
  const lastMessageContent = messages[messages.length - 1]?.content

  // FIX: message content can be a string OR an array of parts (multi-modal /
  // tool-result messages) under the Vercel AI SDK's message format. The
  // previous code assumed it was always a string.
  const lastQuery =
    typeof lastMessageContent === 'string'
      ? lastMessageContent
      : Array.isArray(lastMessageContent)
      ? lastMessageContent.map((p: any) => p.text ?? '').join(' ')
      : ''

  const ip = req.headers.get('x-forwarded-for') || 'anon'

  const { success } = await ratelimit.limit(ip)
  if (!success) return new Response('Rate limited', { status: 429 })

  const start = Date.now()
  let ttft = 0

  // FIX: previously called without `await`, which in a serverless function
  // risks the process being frozen/killed before the prefetch resolves —
  // making it do effectively nothing most of the time. Now awaited before
  // the cache check, so its Redis-cached results are actually available to
  // the DAG tools if the LLM calls them a moment later.
  await speculativePrefetch(lastQuery)

  if (isCacheableQuery(lastQuery)) {
    const cache = await checkSemanticCacheV2(lastQuery, tenantId)
    if (cache.hit) {
      await traceQuery({
        query: lastQuery,
        cacheHit: true,
        tier: 'cache',
        modelId: cache.model ?? 'unknown',
        cacheScore: cache.score,
      })
      return new Response(JSON.stringify({ answer: cache.answer, cached: true, tier: cache.tier }), {
        headers: { 'X-Cache': 'HIT', 'X-Tier': String(cache.tier), 'Content-Type': 'application/json' },
      })
    }
    // cache miss stat is incremented inside checkSemanticCacheV2 itself now
  }

  const routing = await routeQueryV2(lastQuery)
  const model = routing.modelId.includes('claude') ? anthropic(routing.modelId) : openai(routing.modelId)
  redis.incr(`stats:tier:${routing.tier}`).catch(() => {}) // fire-and-forget; stats are best-effort

  const result = await streamText({
    model,
    messages: convertToCoreMessages(messages),
    tools: dagTools,
    maxSteps: 4,
    onChunk: () => {
      if (ttft === 0) ttft = Date.now() - start
    },
    onFinish: async ({ text, usage }) => {
      // FIX: previously `setCacheV2(lastQuery, text, routing.tier)` —
      // routing.tier (e.g. "large") was passed into the `model` parameter,
      // so every cached entry stored a tier string instead of the model ID
      // that actually generated it. Downstream reads of `cached.model`
      // (e.g. in checkSemanticCacheV2's tier-2 hit response) were corrupted.
      if (text.length > 50) await setCacheV2(lastQuery, text, routing.modelId, tenantId)

      const cost = computeCost(routing.modelId, usage.promptTokens, usage.completionTokens)
      await traceQuery({
        query: lastQuery,
        cacheHit: false,
        tier: routing.tier,
        modelId: routing.modelId,
        ttft,
        cost,
      })
    },
  })

  return result.toDataStreamResponse({
    headers: {
      'X-Cache': 'MISS',
      'X-Tier': routing.tier,
      'X-Model': routing.modelId,
      'X-Confidence': String(routing.meta.confidence ?? 0),
    },
  })
}
