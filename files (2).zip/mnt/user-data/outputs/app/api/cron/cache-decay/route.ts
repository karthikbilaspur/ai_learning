import { redis } from '@/lib/redis'

const EXTEND_THRESHOLD = 10 // popularity score above which TTL is extended
const DELETE_THRESHOLD = 2 // popularity score below which entry is purged
const EXTENDED_TTL = 60 * 60 * 24 * 30 // 30 days
const MIN_AGE_FOR_DELETE = 60 * 60 * 24 * 7 // 7 days, in seconds

// FIX: this route previously fetched the popularity ZSET, commented what it
// *would* do ("Extend TTL for score > 10...", "Delete score < 2..."), and
// returned a count without doing either. It now actually does both.
export async function GET() {
  const popular = (await redis.zrange('cache:popular', 0, -1, { withScores: true })) as (string | number)[]

  // zrange with withScores returns a flat [member, score, member, score, ...] array
  const entries: { id: string; score: number }[] = []
  for (let i = 0; i < popular.length; i += 2) {
    entries.push({ id: popular[i] as string, score: Number(popular[i + 1]) })
  }

  let extended = 0
  let deleted = 0
  let skipped = 0

  for (const entry of entries) {
    try {
      if (entry.score > EXTEND_THRESHOLD) {
        // Find and extend TTL on whichever cache key this id belongs to.
        // Popularity ZSET stores both exact-cache hashes and vector cacheIds
        // under the same set, so we try both key shapes.
        const keysToTry = await redis.keys(`*:${entry.id}` as any)
        for (const key of keysToTry as unknown as string[]) {
          await redis.expire(key, EXTENDED_TTL)
        }
        extended++
        continue
      }

      if (entry.score < DELETE_THRESHOLD) {
        const keysToTry = await redis.keys(`*:${entry.id}` as any)
        let anyOldEnough = false
        for (const key of keysToTry as unknown as string[]) {
          const ttl = await redis.ttl(key)
          // A key with low remaining TTL relative to its original window
          // implies it's old; as a simpler proxy, only delete keys that
          // already have less than (original TTL - MIN_AGE_FOR_DELETE) left.
          if (ttl > 0 && ttl < 60 * 60 * 24 * 7 - MIN_AGE_FOR_DELETE + 60 * 60 * 24 * 7) {
            anyOldEnough = true
          }
        }
        if (anyOldEnough) {
          for (const key of keysToTry as unknown as string[]) {
            await redis.del(key)
          }
          await redis.zrem('cache:popular', entry.id)
          deleted++
        } else {
          skipped++
        }
        continue
      }

      skipped++
    } catch {
      // one bad entry shouldn't abort the whole decay pass
      skipped++
    }
  }

  return Response.json({ processed: entries.length, extended, deleted, skipped })
}
