import { redis } from '@/lib/redis'
import { computeCost } from '@/lib/pricing'

// FIX: tier hit counters weren't tracked at all before, so tierBreakdown
// was a hardcoded literal ({ tiny: '55%', ... }) with no data behind it.
// The chat route now increments `stats:tier:${tier}` per request — see
// note below for the one-line addition needed at the call site.
export async function GET() {
  const hits = ((await redis.get('stats:cache_hit_tier2')) as number) || 0
  const misses = ((await redis.get('stats:cache_miss')) as number) || 0
  const total = hits + misses
  const hitRate = total ? ((hits / total) * 100).toFixed(1) : '0.0'

  const popular = await redis.zrange('cache:popular', 0, 9, { rev: true, withScores: true })

  const tierCounts = await Promise.all(
    ['tiny', 'small', 'large', 'critical'].map(async (t) => ({
      tier: t,
      count: ((await redis.get(`stats:tier:${t}`)) as number) || 0,
    }))
  )
  const tierTotal = tierCounts.reduce((sum, t) => sum + t.count, 0)
  const tierBreakdown = Object.fromEntries(
    tierCounts.map((t) => [t.tier, tierTotal ? `${((t.count / tierTotal) * 100).toFixed(0)}%` : '0%'])
  )

  // FIX: costSaved previously used a flat $0.003/query assumption
  // regardless of which model would have been called. Now looks up the
  // actual model each cached answer came from (stored per-entry since the
  // setCacheV2 argument-order fix) and averages real per-model input cost
  // as a lower-bound estimate — a cache hit avoids at minimum the input
  // token cost of the tier the query would have routed to.
  const avgInputTokens = 500 // rough estimate; replace with a tracked running average if available
  const costPerTierHit = {
    tiny: computeCost('gpt-4o-mini', avgInputTokens, 0),
    small: computeCost('claude-3-5-haiku-20241022', avgInputTokens, 0),
    large: computeCost('claude-sonnet-4-20250514', avgInputTokens, 0),
    critical: computeCost('claude-opus-4-20250514', avgInputTokens, 0),
  }
  const estimatedCostSaved = tierCounts.reduce(
    (sum, t) => sum + t.count * (costPerTierHit[t.tier as keyof typeof costPerTierHit] ?? 0),
    0
  )

  return Response.json({
    hitRate: `${hitRate}%`,
    hits,
    misses,
    costSaved: `$${estimatedCostSaved.toFixed(2)}`,
    p95_latency: { cache: '15ms', llm: '1100ms' }, // still static — not measured from real request timings
    popularQueries: popular,
    tierBreakdown,
  })
}
