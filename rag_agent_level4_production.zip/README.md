# Production-Oriented RAG Agent with Automated Evaluation & Observability - Level 4

One-line pitch: Built an end-to-end RAG agent platform that combines hybrid retrieval, tool routing, automated quality evaluation, distributed-style tracing, per-query cost attribution, and CI regression gates.

## What makes this production real-time?

| Capability | Implementation |
|---|---|
| **Hybrid Retrieval** | dense embeddings (all-MiniLM-L6-v2) + BM25 + CrossEncoder reranker |
| **Agent** | Explicit tool-routing policy, Pydantic validation, timeout/retry, fallback |
| **Evaluation** | Recall@k, MRR, Faithfulness, Answer Relevancy, Citation correctness - gates block PR |
| **Observability** | Trace with retrieval/rerank/tool/LLM spans, latency, tokens, cost, errors |
| **Cost** | Per-query attribution, cost/1k queries, budget alert |
| **Deployment** | FastAPI + Docker Compose + health/ready + rate limit + request ID |
| **CI/CD** | pytest + eval suite runs on every PR, publishes regression report |

## Quickstart

```bash
pip install -r requirements.txt
python ingestion/index.py
uvicorn api.main:app --reload --port 8000
# in another terminal
streamlit run dashboard/app.py
```

Set OPENAI_API_KEY for real LLM, else uses safe mock fallback.

## Demo Flow (for portfolio video)

1. Ask knowledge-base question -> POST /query
2. Show retrieved sources with hybrid scores
3. Show agent/tool decision in trace
4. Show final cited answer
5. Open trace -> latency/tokens/cost
6. Run evaluation dashboard -> evals/run_eval.py
7. Demonstrate failing quality gate -> edit prompt to lower threshold

## API

POST /query {"question": "What is RAG?"}
GET /health, /ready, /metrics

## Production checklist - all implemented

- [x] Env-based config
- [x] Health/readiness
- [x] Structured JSON logging via tracer
- [x] Request IDs
- [x] Rate limiting (60 req/min)
- [x] Input validation (Pydantic)
- [x] Eval dataset versioning
- [x] Automated regression gates
- [x] Docker Compose
- [x] API docs (FastAPI /docs)

## Architecture
User -> FastAPI (validation+rate limit) -> Agent Orchestrator -> [Hybrid Retrieve -> Reranker] + [Tool Router] -> LLM -> Trace+Eval+Cost -> Response
