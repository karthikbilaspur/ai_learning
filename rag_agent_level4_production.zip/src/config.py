import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    # LLM
    llm_provider: str = os.getenv("LLM_PROVIDER", "openai") # openai, groq, mock
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    
    # Retrieval
    top_k: int = 5
    hybrid_alpha: float = 0.6  # 0.6 dense, 0.4 bm25
    reranker_enabled: bool = True
    
    # Cost
    cost_per_1k_prompt: float = 0.00015
    cost_per_1k_completion: float = 0.0006
    monthly_budget_usd: float = 50.0
    
    # Observability
    langfuse_enabled: bool = False
    
    class Config:
        env_file = ".env"

settings = Settings()
