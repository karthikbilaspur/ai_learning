# Hybrid retriever: dense + BM25
# Uses sentence-transformers if available, else falls back to TF-IDF for demo portability
from typing import List, Dict
import numpy as np

try:
    from sentence_transformers import SentenceTransformer
    import faiss
    EMBEDDING_AVAILABLE = True
except:
    EMBEDDING_AVAILABLE = False
    from sklearn.feature_extraction.text import TfidfVectorizer

from rank_bm25 import BM25Okapi

class HybridRetriever:
    def __init__(self, chunks: List[Dict], embedding_model="sentence-transformers/all-MiniLM-L6-v2"):
        self.chunks = chunks
        self.texts = [c["text"] for c in chunks]
        
        # BM25
        tokenized = [t.lower().split() for t in self.texts]
        self.bm25 = BM25Okapi(tokenized)
        
        # Dense
        if EMBEDDING_AVAILABLE:
            self.model = SentenceTransformer(embedding_model)
            embeddings = self.model.encode(self.texts, normalize_embeddings=True)
            self.embeddings = np.array(embeddings).astype('float32')
            self.index = faiss.IndexFlatIP(self.embeddings.shape[1])
            self.index.add(self.embeddings)
        else:
            self.vectorizer = TfidfVectorizer()
            self.tfidf_matrix = self.vectorizer.fit_transform(self.texts)
    
    def retrieve(self, query: str, top_k=5, alpha=0.6) -> List[Dict]:
        # alpha = weight for dense, 1-alpha for BM25
        # BM25 scores
        bm25_scores = self.bm25.get_scores(query.lower().split())
        bm25_scores = (bm25_scores - np.min(bm25_scores)) / (np.max(bm25_scores)-np.min(bm25_scores)+1e-9)
        
        if EMBEDDING_AVAILABLE:
            q_emb = self.model.encode([query], normalize_embeddings=True).astype('float32')
            dense_scores, indices = self.index.search(q_emb, len(self.chunks))
            dense_scores = dense_scores[0]
            dense_order = indices[0]
            # map to original order
            dense_score_map = np.zeros(len(self.chunks))
            for score, idx in zip(dense_scores, dense_order):
                dense_score_map[idx] = score
        else:
            from sklearn.metrics.pairwise import cosine_similarity
            q_vec = self.vectorizer.transform([query])
            dense_score_map = cosine_similarity(q_vec, self.tfidf_matrix)[0]
        
        hybrid = alpha * dense_score_map + (1-alpha) * bm25_scores
        top_indices = np.argsort(hybrid)[::-1][:top_k]
        
        results=[]
        for idx in top_indices:
            c = self.chunks[idx]
            results.append({**c, "score": float(hybrid[idx]), "bm25": float(bm25_scores[idx]), "dense": float(dense_score_map[idx])})
        return results
