from typing import List, Dict
try:
    from sentence_transformers import CrossEncoder
    RERANK_AVAILABLE = True
except:
    RERANK_AVAILABLE = False

class Reranker:
    def __init__(self, model_name="cross-encoder/ms-marco-MiniLM-L-6-v2"):
        if RERANK_AVAILABLE:
            self.model = CrossEncoder(model_name)
        else:
            self.model = None
    
    def rerank(self, query: str, docs: List[Dict], top_k=5) -> List[Dict]:
        if not docs:
            return docs
        if self.model:
            pairs = [(query, d["text"]) for d in docs]
            scores = self.model.predict(pairs)
            for d, s in zip(docs, scores):
                d["rerank_score"] = float(s)
            docs = sorted(docs, key=lambda x: x["rerank_score"], reverse=True)
        else:
            # fallback: sort by existing hybrid score
            docs = sorted(docs, key=lambda x: x.get("score",0), reverse=True)
            for d in docs:
                d["rerank_score"] = d.get("score",0)
        return docs[:top_k]
