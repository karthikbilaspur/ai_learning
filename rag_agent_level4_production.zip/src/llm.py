from typing import List, Dict
import os
from .config import settings
from .cost import tracker

class LLMWrapper:
    def __init__(self):
        self.provider = settings.llm_provider
    
    def generate(self, context: str, question: str, tool_history: str="") -> Dict:
        # Real implementation uses OpenAI if key present else mock
        prompt = f"Context: {context}\nQuestion: {question}\nToolHistory: {tool_history}\nAnswer with citations."
        
        if settings.openai_api_key and self.provider == "openai":
            try:
                from openai import OpenAI
                client = OpenAI(api_key=settings.openai_api_key)
                resp = client.chat.completions.create(
                    model=settings.openai_model,
                    messages=[{"role":"user","content":prompt}],
                    temperature=0.2
                )
                answer = resp.choices[0].message.content
                usage = {"prompt_tokens": resp.usage.prompt_tokens, "completion_tokens": resp.usage.completion_tokens, "total_tokens": resp.usage.total_tokens}
                cost = tracker.calculate(usage["prompt_tokens"], usage["completion_tokens"])
                return {"answer": answer, "usage": usage, "cost": cost}
            except Exception as e:
                print(f"OpenAI error fallback to mock: {e}")
        
        # Mock fallback - production-safe
        # Simple extractive answer for demo
        answer = f"Based on retrieved context: {context[:400]}... Answer to '{question}' is found in sources. [Mock generation - set OPENAI_API_KEY for real LLM]"
        usage = {"prompt_tokens": len(prompt)//4, "completion_tokens": len(answer)//4, "total_tokens": (len(prompt)+len(answer))//4}
        cost = tracker.calculate(usage["prompt_tokens"], usage["completion_tokens"])
        return {"answer": answer, "usage": usage, "cost": cost}
