from .config import settings

class CostTracker:
    def __init__(self):
        self.total_cost = 0.0
        self.query_costs = []
    
    def calculate(self, prompt_tokens, completion_tokens):
        cost = (prompt_tokens/1000)*settings.cost_per_1k_prompt + (completion_tokens/1000)*settings.cost_per_1k_completion
        self.total_cost += cost
        self.query_costs.append(cost)
        if len(self.query_costs) > 1000:
            self.query_costs = self.query_costs[-1000:]
        return cost
    
    def cost_per_1k_queries(self):
        if not self.query_costs:
            return 0.0
        avg = sum(self.query_costs)/len(self.query_costs)
        return avg * 1000
    
    def budget_status(self):
        return {"total_spent": self.total_cost, "budget": settings.monthly_budget_usd, "remaining": settings.monthly_budget_usd - self.total_cost, "over_budget": self.total_cost > settings.monthly_budget_usd}

tracker = CostTracker()
