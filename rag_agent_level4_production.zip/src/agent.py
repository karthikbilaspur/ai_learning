import time
from typing import Dict, List
from .retriever import HybridRetriever
from .reranker import Reranker
from .llm import LLMWrapper
from .tools import router
from .tracer import get_tracer
from .config import settings
from ingestion.loader import load_documents
from ingestion.chunker import chunk_all
from .prompts import RAG_TEMPLATE

class AgentOrchestrator:
    def __init__(self):
        self.tracer = get_tracer()
        docs = load_documents()
        chunks = chunk_all(docs)
        self.retriever = HybridRetriever(chunks, embedding_model=settings.embedding_model)
        self.reranker = Reranker()
        self.llm = LLMWrapper()
        self._doc_count = len(docs)
    
    def is_ready(self):
        return True
    
    def doc_count(self):
        return self._doc_count
    
    async def run(self, question: str, trace_id: str, top_k=5, require_citations=True) -> Dict:
        spans=[]
        
        # Span 1: retrieval
        s = self.tracer.start_span("retrieval", trace_id)
        retrieved = self.retriever.retrieve(question, top_k=top_k*2, alpha=settings.hybrid_alpha)
        s.finish(query=question, top_k=top_k*2, docs_found=len(retrieved), scores=[r["score"] for r in retrieved])
        spans.append(s.to_dict())
        
        # Span 2: rerank
        s2 = self.tracer.start_span("rerank", trace_id)
        reranked = self.reranker.rerank(question, retrieved, top_k=top_k)
        s2.finish(candidate_count=len(retrieved), reranked_count=len(reranked))
        spans.append(s2.to_dict())
        
        # Span 3: tool routing (simple heuristic: if math symbols, use calculator)
        tool_calls=[]
        tool_history=""
        if any(sym in question for sym in ["+", "-", "*", "/", "calculate", "math", "%"]):
            s3 = self.tracer.start_span("tool_call", trace_id)
            # naive extraction
            try:
                # for demo, try to evaluate numbers
                expr = "".join([c for c in question if c.isdigit() or c in "+-*/().% "]).strip()
                if expr:
                    router.validate("calculator", {"expression": expr})
                    res = router.execute("calculator", {"expression": expr})
                    tool_calls.append(res)
                    tool_history = f"calculator({expr})={res.get('result')}"
                    s3.finish(tool="calculator", args={"expression": expr}, result=res, latency_ms=res.get("latency_ms"))
                else:
                    s3.finish(tool="none")
            except Exception as e:
                s3.finish(error=str(e))
                tool_history = f"tool error: {e}"
            spans.append(s3.to_dict())
        
        # Span 4: LLM generation
        s4 = self.tracer.start_span("llm_generation", trace_id)
        context_text = "\n".join([f"[{c['doc_id']}:{c['chunk_id']}] {c['text']} (score={c.get('rerank_score', c['score']):.3f})" for c in reranked])
        llm_res = self.llm.generate(context=context_text, question=question, tool_history=tool_history)
        s4.finish(model=settings.openai_model, tokens=llm_res["usage"], cost=llm_res["cost"])
        spans.append(s4.to_dict())
        
        # Build citations
        citations=[]
        for c in reranked:
            citations.append({
                "doc_id": c["doc_id"],
                "chunk_id": c["chunk_id"],
                "text": c["text"][:300],
                "score": c.get("rerank_score", c.get("score",0))
            })
        
        return {
            "answer": llm_res["answer"],
            "citations": citations,
            "trace": spans,
            "usage": llm_res["usage"],
            "cost": llm_res["cost"],
            "retrieval_scores": [r.get("rerank_score", r["score"]) for r in reranked],
            "tool_calls": tool_calls
        }
