import time, json, math
from typing import Dict, Any
from pydantic import BaseModel, Field

class CalculatorInput(BaseModel):
    expression: str = Field(..., description="Valid python math expression, e.g. 2* (3+4) / 5")

TOOLS_SCHEMA = {
    "calculator": {
        "name": "calculator",
        "description": "Use for math calculations",
        "parameters": CalculatorInput.schema()
    }
}

class ToolRouter:
    def __init__(self, timeout=3.0, max_retries=2):
        self.timeout = timeout
        self.max_retries = max_retries
    
    def validate(self, tool_name, args: Dict):
        if tool_name not in TOOLS_SCHEMA:
            raise ValueError(f"Unknown tool {tool_name}")
        if tool_name == "calculator":
            CalculatorInput(**args)  # validation
        return True
    
    def execute(self, tool_name, args: Dict) -> Dict[str, Any]:
        self.validate(tool_name, args)
        last_err = None
        for attempt in range(self.max_retries+1):
            try:
                start = time.time()
                if tool_name == "calculator":
                    # safe eval
                    expr = args["expression"]
                    # allow only math
                    allowed = {"__builtins__": {}}
                    allowed.update({k: getattr(math, k) for k in dir(math) if not k.startswith("_")})
                    result = eval(expr, allowed, {})
                    latency = (time.time()-start)*1000
                    return {"tool": tool_name, "result": result, "latency_ms": latency, "attempt": attempt}
            except Exception as e:
                last_err = str(e)
                time.sleep(0.2 * (attempt+1))
        return {"tool": tool_name, "error": last_err, "latency_ms": 0, "attempt": self.max_retries}

router = ToolRouter()
