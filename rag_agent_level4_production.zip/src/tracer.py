import time, json, threading
from typing import Dict, List, Any
from datetime import datetime

class Span:
    def __init__(self, name: str, trace_id: str):
        self.name = name
        self.trace_id = trace_id
        self.start = time.time()
        self.end = None
        self.data = {}
        self.error = None
    
    def finish(self, **kwargs):
        self.end = time.time()
        self.data.update(kwargs)
        self.data["latency_ms"] = int((self.end - self.start)*1000)
    
    def to_dict(self):
        return {"span": self.name, "trace_id": self.trace_id, "start": self.start, "end": self.end, **self.data, "error": self.error}

class Tracer:
    def __init__(self):
        self.traces: Dict[str, List[Dict]] = {}
        self.lock = threading.Lock()
        self.metrics = []
    
    def start_span(self, name, trace_id):
        return Span(name, trace_id)
    
    def log_trace(self, trace_id, spans: List[Dict]):
        with self.lock:
            self.traces[trace_id] = spans
            # aggregate for dashboard
            total_lat = sum(s.get("latency_ms",0) for s in spans)
            total_tokens = sum(s.get("tokens",{}).get("total_tokens",0) if isinstance(s.get("tokens"), dict) else 0 for s in spans)
            self.metrics.append({
                "trace_id": trace_id,
                "timestamp": datetime.utcnow().isoformat(),
                "latency_ms": total_lat,
                "tokens": total_tokens,
                "spans": spans
            })
            if len(self.metrics) > 500:
                self.metrics = self.metrics[-500:]
    
    def log_error(self, trace_id, err):
        with self.lock:
            self.traces[trace_id] = [{"error": err}]
    
    def get_dashboard_metrics(self):
        if not self.metrics:
            return {"count":0}
        latencies = [m["latency_ms"] for m in self.metrics]
        latencies_sorted = sorted(latencies)
        def pct(p):
            idx = int(len(latencies_sorted)*p)
            return latencies_sorted[min(idx, len(latencies_sorted)-1)]
        return {
            "count": len(self.metrics),
            "p50_latency_ms": pct(0.5),
            "p95_latency_ms": pct(0.95),
            "avg_latency_ms": sum(latencies)/len(latencies),
            "total_tokens": sum(m["tokens"] for m in self.metrics),
            "last_5": self.metrics[-5:]
        }

_singleton = None
def get_tracer():
    global _singleton
    if _singleton is None:
        _singleton = Tracer()
    return _singleton
