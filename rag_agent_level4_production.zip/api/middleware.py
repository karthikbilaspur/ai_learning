import time, uuid
from collections import defaultdict
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        start = time.time()
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{(time.time()-start)*1000:.2f}ms"
        return response

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, max_requests: int = 60):
        super().__init__(app)
        self.max_requests = max_requests
        self.requests = defaultdict(list)

    async def dispatch(self, request, call_next):
        # simple sliding window per IP
        ip = request.client.host if request.client else "unknown"
        now = time.time()
        window = self.requests[ip]
        # keep last 60s
        self.requests[ip] = [t for t in window if now - t < 60]
        if len(self.requests[ip]) >= self.max_requests:
            return JSONResponse(status_code=429, content={"error": "Rate limit exceeded, max 60 req/min"})
        self.requests[ip].append(now)
        return await call_next(request)
