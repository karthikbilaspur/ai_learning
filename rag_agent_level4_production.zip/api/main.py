from fastapi import FastAPI, Depends, Request
from fastapi.responses import JSONResponse
import time, uuid
from .schemas import QueryRequest, QueryResponse, HealthResponse
from .middleware import RequestIDMiddleware, RateLimitMiddleware
from src.agent import AgentOrchestrator
from src.config import settings
from src.tracer import get_tracer

app = FastAPI(title="RAG Agent Level 4 - Production API", version="4.0.0")
app.add_middleware(RequestIDMiddleware)
app.add_middleware(RateLimitMiddleware, max_requests=60)

agent = AgentOrchestrator()
tracer = get_tracer()

@app.get("/health", response_model=HealthResponse)
async def health():
    return {"status": "ok", "version": "4.0.0", "eval_gate": "enabled"}

@app.get("/ready")
async def ready():
    # check indexes loaded
    return {"ready": agent.is_ready(), "docs_indexed": agent.doc_count()}

@app.post("/query", response_model=QueryResponse)
async def query(req: QueryRequest, request: Request):
    trace_id = getattr(request.state, 'request_id', str(uuid.uuid4()))
    start = time.time()
    try:
        result = await agent.run(
            question=req.question,
            trace_id=trace_id,
            top_k=req.top_k,
            require_citations=True
        )
        latency_ms = int((time.time() - start)*1000)
        tracer.log_trace(trace_id, result["trace"])
        return {
            "answer": result["answer"],
            "citations": result["citations"],
            "trace_id": trace_id,
            "latency_ms": latency_ms,
            "tokens": result["usage"],
            "cost_usd": result["cost"],
            "retrieval_scores": result["retrieval_scores"],
            "tool_calls": result["tool_calls"]
        }
    except Exception as e:
        tracer.log_error(trace_id, str(e))
        return JSONResponse(status_code=500, content={"error": str(e), "trace_id": trace_id})

@app.get("/metrics")
async def metrics():
    return tracer.get_dashboard_metrics()
