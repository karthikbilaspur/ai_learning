from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class QueryRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=1000, description="User question")
    top_k: int = Field(default=5, ge=1, le=20)
    session_id: Optional[str] = None

class Citation(BaseModel):
    doc_id: str
    chunk_id: str
    text: str
    score: float

class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

class QueryResponse(BaseModel):
    answer: str
    citations: List[Citation]
    trace_id: str
    latency_ms: int
    tokens: Usage
    cost_usd: float
    retrieval_scores: List[float]
    tool_calls: List[Dict[str, Any]]

class HealthResponse(BaseModel):
    status: str
    version: str
    eval_gate: str
