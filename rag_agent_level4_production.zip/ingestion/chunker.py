from typing import List, Dict

def chunk_document(doc: Dict, chunk_size=300, overlap=50) -> List[Dict]:
    text = doc["text"]
    words = text.split()
    chunks = []
    i=0
    chunk_id=0
    while i < len(words):
        chunk_words = words[i:i+chunk_size]
        chunk_text = " ".join(chunk_words)
        chunks.append({
            "doc_id": doc["id"],
            "chunk_id": f"{doc['id']}_c{chunk_id}",
            "text": chunk_text,
            "title": doc.get("title","")
        })
        chunk_id+=1
        i += chunk_size - overlap
    return chunks

def chunk_all(docs: List[Dict]) -> List[Dict]:
    all_chunks=[]
    for d in docs:
        all_chunks.extend(chunk_document(d))
    return all_chunks
