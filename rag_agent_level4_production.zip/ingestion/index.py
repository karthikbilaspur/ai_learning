from .loader import load_documents
from .chunker import chunk_all
from src.retriever import HybridRetriever

def build_indexes():
    docs = load_documents()
    chunks = chunk_all(docs)
    retriever = HybridRetriever(chunks)
    print(f"Built indexes: {len(docs)} docs, {len(chunks)} chunks, dense={retriever.embeddings.shape if hasattr(retriever, 'embeddings') else 'TF-IDF'}")
    return retriever

if __name__ == "__main__":
    build_indexes()
