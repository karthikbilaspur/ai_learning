import json, pathlib
from typing import List, Dict

def load_documents(path="data/docs.json"):
    p = pathlib.Path(path)
    if not p.exists():
        # create 10-doc demo corpus if missing
        demo = [
            {"id": f"doc_{i}", "title": f"Sample Doc {i}", "text": f"This is sample content for document {i}. RAG stands for Retrieval Augmented Generation. Agent routing uses tool schemas. Evaluation measures faithfulness."}
            for i in range(1, 11)
        ]
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w") as f:
            json.dump(demo, f, indent=2)
    with open(p) as f:
        return json.load(f)
