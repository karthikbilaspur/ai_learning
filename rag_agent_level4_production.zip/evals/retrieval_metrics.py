from typing import List, Dict
import numpy as np

def recall_at_k(retrieved: List[Dict], expected_doc: str, k=5):
    top_k = retrieved[:k]
    return 1.0 if any(expected_doc in r["doc_id"] for r in top_k) else 0.0

def mrr(retrieved: List[Dict], expected_doc: str):
    for i, r in enumerate(retrieved):
        if expected_doc in r["doc_id"]:
            return 1.0/(i+1)
    return 0.0

def evaluate_retrieval(results: List[Dict]):
    recalls = [r["recall@5"] for r in results]
    mrrs = [r["mrr"] for r in results]
    return {"Recall@5": float(np.mean(recalls)), "MRR": float(np.mean(mrrs)), "count": len(results)}
