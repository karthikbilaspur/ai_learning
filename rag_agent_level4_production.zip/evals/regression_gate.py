import json, pathlib, sys

BASELINE = {
    "Recall@5": 0.90,
    "MRR": 0.80,
    "Faithfulness": 0.90,
    "Answer Relevancy": 0.85,
    "Citation correctness": 0.95
}

def check_gate(current_metrics: dict, baseline=BASELINE, tolerance=0.05):
    failures=[]
    for k, threshold in baseline.items():
        cur = current_metrics.get(k)
        if cur is None:
            continue
        if cur < threshold - tolerance:
            failures.append(f"{k} regression: {cur:.3f} < {threshold:.3f}")
    return failures

if __name__ == "__main__":
    # usage: python regression_gate.py current_metrics.json
    p = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path("evals/latest_metrics.json")
    if not p.exists():
        print("No metrics file, skipping gate")
        sys.exit(0)
    with open(p) as f:
        cur = json.load(f)
    fails = check_gate(cur)
    if fails:
        print("REGRESSION GATE FAILED:")
        for f in fails:
            print(" -", f)
        sys.exit(1)
    else:
        print("GATE PASSED", cur)
