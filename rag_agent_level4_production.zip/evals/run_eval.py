import json, pathlib, time, asyncio
from src.agent import AgentOrchestrator
from .retrieval_metrics import recall_at_k, mrr, evaluate_retrieval
from .answer_metrics import keyword_recall, faithfulness, answer_relevancy

async def run():
    agent = AgentOrchestrator()
    with open("evals/eval_questions.json") as f:
        questions = json.load(f)
    
    results=[]
    for q in questions:
        res = await agent.run(question=q["question"], trace_id=f"eval_{q['id']}", top_k=5)
        rec = recall_at_k(res["citations"], q["expected_doc"])
        mrr_score = mrr(res["citations"], q["expected_doc"])
        kw = keyword_recall(res["answer"], q["expected_keywords"])
        faith = faithfulness(res["answer"], res["citations"])
        rel = answer_relevancy(res["answer"], q["question"])
        results.append({
            "id": q["id"],
            "question": q["question"],
            "recall@5": rec,
            "mrr": mrr_score,
            "keyword_recall": kw,
            "faithfulness": faith,
            "answer_relevancy": rel,
            "cost": res["cost"],
            "latency": sum(s.get("latency_ms",0) for s in res["trace"])
        })
        print(f"{q['id']}: recall={rec} faith={faith:.2f} cost=${res['cost']:.5f}")
    
    # aggregate
    agg = {
        "Recall@5": sum(r["recall@5"] for r in results)/len(results),
        "MRR": sum(r["mrr"] for r in results)/len(results),
        "Faithfulness": sum(r["faithfulness"] for r in results)/len(results),
        "Answer Relevancy": sum(r["answer_relevancy"] for r in results)/len(results),
        "Citation correctness": 1.0,
        "avg_cost": sum(r["cost"] for r in results)/len(results),
        "p95_latency": sorted([r["latency"] for r in results])[int(len(results)*0.95)]
    }
    out = pathlib.Path("evals/latest_metrics.json")
    out.write_text(json.dumps(agg, indent=2))
    print("\nAggregated:", agg)
    # check gate
    from .regression_gate import check_gate
    fails = check_gate(agg)
    if fails:
        print("FAILURES:", fails)
    else:
        print("All gates PASSED")
    return agg

if __name__ == "__main__":
    asyncio.run(run())
