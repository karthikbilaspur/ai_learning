# Simplified faithfulness / relevancy - in prod use LLM-as-judge
from typing import List

def keyword_recall(answer: str, expected_keywords: List[str]):
    answer_l = answer.lower()
    hits = sum(1 for kw in expected_keywords if kw.lower() in answer_l)
    return hits / max(len(expected_keywords),1)

def faithfulness(answer: str, citations: List[dict]):
    # heuristic: has citations and not hallucinating numbers not in context
    if not citations:
        return 0.0
    return 0.9 if len(answer) > 20 else 0.5

def answer_relevancy(answer: str, question: str):
    # heuristic overlap
    q_words = set(question.lower().split())
    a_words = set(answer.lower().split())
    return len(q_words & a_words) / max(len(q_words),1)
