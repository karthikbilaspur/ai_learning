from src.tools import router

def test_tool_validation():
    router.validate("calculator", {"expression": "2+2"})
    try:
        router.validate("calculator", {"wrong": "field"})
        assert False, "should have raised"
    except:
        pass
    print("tool validation passed")

def test_tool_execution():
    res = router.execute("calculator", {"expression": "2*(3+4)"})
    assert res["result"] == 14
    print("tool execution passed")

if __name__ == "__main__":
    test_tool_validation()
    test_tool_execution()
