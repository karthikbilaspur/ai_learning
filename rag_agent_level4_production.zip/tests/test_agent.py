import asyncio
from src.agent import AgentOrchestrator

async def test_agent():
    agent = AgentOrchestrator()
    res = await agent.run(question="What is RAG?", trace_id="test_1")
    assert "answer" in res
    assert "citations" in res
    assert len(res["citations"]) > 0
    print("agent test passed", res["answer"][:100])

if __name__ == "__main__":
    asyncio.run(test_agent())
