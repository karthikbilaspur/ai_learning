from ingestion.loader import load_documents
from ingestion.chunker import chunk_all
from src.retriever import HybridRetriever

def test_retrieval():
    docs = load_documents()
    chunks = chunk_all(docs)
    retr = HybridRetriever(chunks)
    res = retr.retrieve("What is RAG?", top_k=3)
    assert len(res) == 3
    assert "score" in res[0]
    print("retrieval test passed")

if __name__ == "__main__":
    test_retrieval()
