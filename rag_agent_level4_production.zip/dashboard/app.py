import streamlit as st
import json, pathlib, pandas as pd
from src.cost import tracker

st.set_page_config(page_title="RAG Agent Level 4 Dashboard", layout="wide")
st.title("Production RAG Agent - Operational Dashboard")

col1, col2, col3, col4 = st.columns(4)
metrics_path = pathlib.Path("evals/latest_metrics.json")
if metrics_path.exists():
    with open(metrics_path) as f:
        m = json.load(f)
    col1.metric("Recall@5", f"{m.get('Recall@5',0):.2%}")
    col2.metric("Faithfulness", f"{m.get('Faithfulness',0):.2%}")
    col3.metric("Avg Cost/query", f"${m.get('avg_cost',0):.5f}")
    col4.metric("p95 Latency", f"{m.get('p95_latency',0)} ms")
else:
    st.warning("Run evals/run_eval.py to generate metrics")

st.divider()
st.subheader("Cost Tracking")
st.json(tracker.budget_status())
st.metric("Cost per 1k queries", f"${tracker.cost_per_1k_queries():.4f}")

st.subheader("Trace Viewer")
from src.tracer import get_tracer
t = get_tracer()
if t.metrics:
    df = pd.DataFrame(t.metrics)
    st.dataframe(df.tail(20))
else:
    st.info("No traces yet - query the API first")
