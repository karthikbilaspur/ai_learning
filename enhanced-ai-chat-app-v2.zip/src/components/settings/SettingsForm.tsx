'use client';

import React, { useState } from "react";

export default function SettingsForm() {
  const [model, setModel] = useState("gpt-4-turbo");

  return (
    <div className="space-y-4 border p-4 rounded-lg">
      <div>
        <label className="block text-sm font-medium text-gray-700">Model Choice</label>
        <select 
          value={model} 
          onChange={(e) => setModel(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 p-2 border"
        >
          <option value="gpt-4-turbo">GPT-4 Turbo</option>
          <option value="claude-3-5-sonnet">Claude 3.5 Sonnet</option>
          <option value="gemini-1-5-pro">Gemini 1.5 Pro</option>
        </select>
      </div>
    </div>
  );
}
