'use client';

import React from "react";

export default function ConversationList() {
  const conversations = [
    { id: "1", title: "RAG Architecture Setup", date: "2026-08-15" },
    { id: "2", title: "Redis Caching Strategy", date: "2026-08-14" },
  ];

  return (
    <div className="space-y-3">
      {conversations.map((c) => (
        <div key={c.id} className="p-4 border rounded-lg hover:bg-slate-50 transition flex justify-between">
          <span className="font-medium">{c.title}</span>
          <span className="text-sm text-gray-500">{c.date}</span>
        </div>
      ))}
    </div>
  );
}
