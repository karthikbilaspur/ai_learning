import { Redis } from "@upstash/redis";
import { env } from "../config/env";

class CacheService {
  private client: Redis | null = null;

  constructor() {
    if (env.UPSTASH_REDIS_REST_URL && env.UPSTASH_REDIS_REST_TOKEN) {
      this.client = new Redis({
        url: env.UPSTASH_REDIS_REST_URL,
        token: env.UPSTASH_REDIS_REST_TOKEN,
      });
    }
  }

  async get<T>(key: string): Promise<T | null> {
    if (!this.client) return null;
    try {
      const data = await this.client.get<T>(key);
      return data;
    } catch (err) {
      console.warn(`[Redis Cache GET Error] Key ${key}:`, err);
      return null;
    }
  }

  async set<T>(key: string, value: T, ttlSeconds: number = 3600): Promise<void> {
    if (!this.client) return;
    try {
      await this.client.set(key, JSON.stringify(value), { ex: ttlSeconds });
    } catch (err) {
      console.warn(`[Redis Cache SET Error] Key ${key}:`, err);
    }
  }

  async invalidate(key: string): Promise<void> {
    if (!this.client) return;
    try {
      await this.client.del(key);
    } catch (err) {
      console.warn(`[Redis Cache DEL Error] Key ${key}:`, err);
    }
  }
}

export const cacheService = new CacheService();
