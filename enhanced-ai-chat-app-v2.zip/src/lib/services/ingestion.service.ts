import { db } from "../db";
import { cacheService } from "./cache.service";
import { telemetryService } from "./telemetry.service";

export class IngestionService {
  static async processDocument(conversationId: string, filename: string, rawContent: string): Promise<{ chunkCount: number }> {
    const startTime = Date.now();
    const chunks = this.chunkText(rawContent, 500);

    const chunkRecords = chunks.map((chunk) => ({
      conversationId,
      content: chunk,
      metadata: JSON.stringify({ filename, length: chunk.length }),
    }));

    await db.documentChunk.createMany({
      data: chunkRecords,
    });

    // Invalidate RAG cache for this conversation
    await cacheService.invalidate(`rag:query:${conversationId}:*`);
    
    telemetryService.logEvent("document_ingested", {
      conversationId,
      filename,
      chunksCount: chunks.length,
      durationMs: Date.now() - startTime,
    });

    return { chunkCount: chunks.length };
  }

  private static chunkText(text: string, chunkSize: number): string[] {
    const words = text.split(" ");
    const chunks: string[] = [];
    let currentChunk: string[] = [];

    for (const word of words) {
      currentChunk.push(word);
      if (currentChunk.join(" ").length >= chunkSize) {
        chunks.push(currentChunk.join(" "));
        currentChunk = [];
      }
    }
    if (currentChunk.length > 0) chunks.push(currentChunk.join(" "));
    return chunks;
  }
}
