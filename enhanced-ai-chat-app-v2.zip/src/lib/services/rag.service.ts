import { cacheService } from "./cache.service";
import { db } from "../db";
import { telemetryService } from "./telemetry.service";

export interface ContextChunk {
  id: string;
  content: string;
  score: number;
  metadata?: Record<string, any>;
}

export class RagService {
  static async retrieveContext(query: string, conversationId: string): Promise<ContextChunk[]> {
    const startTime = Date.now();
    const cacheKey = `rag:query:${conversationId}:${Buffer.from(query).toString('base64').substring(0, 32)}`;

    // Check Redis Cache
    const cached = await cacheService.get<ContextChunk[]>(cacheKey);
    if (cached) {
      telemetryService.logEvent("rag_retrieval", { query, conversationId, cacheHit: true, latencyMs: Date.now() - startTime });
      return cached;
    }

    // Database Vector Retrieval Fallback
    const documents = await db.documentChunk.findMany({
      where: { conversationId },
      take: 5,
    });

    const results: ContextChunk[] = documents.map((doc, idx) => ({
      id: doc.id,
      content: doc.content,
      score: 1.0 - idx * 0.1,
    }));

    // Cache results for 15 minutes
    await cacheService.set(cacheKey, results, 900);
    telemetryService.logEvent("rag_retrieval", { query, conversationId, cacheHit: false, latencyMs: Date.now() - startTime });

    return results;
  }
}
