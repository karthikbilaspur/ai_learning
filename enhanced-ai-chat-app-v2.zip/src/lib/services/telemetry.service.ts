export interface TelemetryEvent {
  eventName: string;
  metadata: Record<string, any>;
  timestamp: string;
}

export class TelemetryService {
  logEvent(eventName: string, metadata: Record<string, any> = {}): void {
    const payload: TelemetryEvent = {
      eventName,
      metadata,
      timestamp: new Date().toISOString(),
    };
    console.log(`[TELEMETRY] ${JSON.stringify(payload)}`);
  }

  logTokenUsage(conversationId: string, promptTokens: number, completionTokens: number): void {
    this.logEvent("token_consumption", {
      conversationId,
      promptTokens,
      completionTokens,
      totalTokens: promptTokens + completionTokens,
    });
  }
}

export const telemetryService = new TelemetryService();
