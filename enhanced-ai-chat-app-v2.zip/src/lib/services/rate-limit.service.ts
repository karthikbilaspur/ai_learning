import { cacheService } from "./cache.service";

interface RateLimitConfig {
  limit: number;
  windowInSeconds: number;
}

export class RateLimitService {
  private static defaultConfig: RateLimitConfig = {
    limit: 60,
    windowInSeconds: 60,
  };

  static async check(identifier: string, config: RateLimitConfig = this.defaultConfig): Promise<{ success: boolean; remaining: number }> {
    const key = `rate_limit:${identifier}`;
    const current = await cacheService.get<number>(key) || 0;

    if (current >= config.limit) {
      return { success: false, remaining: 0 };
    }

    await cacheService.set(key, current + 1, config.windowInSeconds);
    return { success: true, remaining: config.limit - (current + 1) };
  }
}
