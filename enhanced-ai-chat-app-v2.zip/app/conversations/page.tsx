import React from "react";
import ConversationList from "@/components/conversations/ConversationList";

export default function ConversationsPage() {
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <h1 className="text-2xl font-bold mb-4">Your Conversations</h1>
      <ConversationList />
    </div>
  );
}
