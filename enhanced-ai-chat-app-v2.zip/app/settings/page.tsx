import React from "react";
import SettingsForm from "@/components/settings/SettingsForm";

export default function SettingsPage() {
  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Application Settings</h1>
      <SettingsForm />
    </div>
  );
}
