import { NextRequest, NextResponse } from "next/server";
import { RagService } from "@/lib/services/rag.service";
import { RateLimitService } from "@/lib/services/rate-limit.service";
import { telemetryService } from "@/lib/services/telemetry.service";
import { db } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { message, conversationId, userId } = body;

    // Rate Limiting
    const rateCheck = await RateLimitService.check(userId || "anonymous");
    if (!rateCheck.success) {
      return NextResponse.json({ error: "Too many requests" }, { status: 429 });
    }

    // Context Retrieval via Service Layer
    const context = await RagService.retrieveContext(message, conversationId);

    // Persist User Message
    await db.message.create({
      data: { conversationId, sender: "user", text: message },
    });

    const aiResponseText = `[RAG Context Applied] Processed query: "${message}". Context matching ${context.length} relevant chunks.`;

    // Persist Assistant Message
    await db.message.create({
      data: { conversationId, sender: "assistant", text: aiResponseText },
    });

    // Telemetry Logging
    telemetryService.logTokenUsage(conversationId, message.length, aiResponseText.length);

    return NextResponse.json({ response: aiResponseText, contextCount: context.length });
  } catch (error: any) {
    telemetryService.logEvent("chat_error", { error: error.message });
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
