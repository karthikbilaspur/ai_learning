import { NextRequest, NextResponse } from "next/server";
import { IngestionService } from "@/lib/services/ingestion.service";

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;
    const conversationId = formData.get("conversationId") as string;

    if (!file || !conversationId) {
      return NextResponse.json({ error: "Missing file or conversation ID" }, { status: 400 });
    }

    const text = await file.text();
    const result = await IngestionService.processDocument(conversationId, file.name, text);

    return NextResponse.json({ success: true, chunksProcessed: result.chunkCount });
  } catch (err: any) {
    return NextResponse.json({ error: "Failed to upload document" }, { status: 500 });
  }
}
