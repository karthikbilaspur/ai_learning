# Enhanced AI Chat App v2

A rewritten Next.js/Prisma RAG application focused on the shortcomings in the original project.

## Improvements

- Real OpenAI embeddings and cosine-similarity retrieval instead of positional fake scores.
- Real OpenAI chat completion with source-aware prompting.
- Authenticated API routes using NextAuth + Google OAuth.
- Authorization checks ensure conversations and documents belong to the logged-in user.
- Atomic Redis rate limiting with `INCR`/`EXPIRE`.
- SHA-256 cache keys and versioned RAG caches. New ingestion increments `ragVersion`, avoiding broken wildcard invalidation.
- File-size, MIME-type and empty-file validation.
- Paragraph-aware chunking with overlap.
- Persistent user model settings.
- Database-backed conversation listing/creation.
- Zod request validation.
- Unit tests for chunking and vector similarity.
- Structured error handling and telemetry.

## Setup

1. Copy `.env.example` to `.env.local` and configure PostgreSQL, NextAuth, Google OAuth and OpenAI.
2. Install dependencies with `npm install`.
3. Run `npm run db:push`.
4. Run `npm run dev`.

Google OAuth is intentionally required for production API access. Configure the callback URL as `/api/auth/callback/google` on your deployed domain.

## Important scalability note

This implementation stores embeddings as JSON and calculates cosine similarity in application memory. That makes it easy to run and test, but for large corpora it should be migrated to PostgreSQL `pgvector` or a dedicated vector database. The service boundary is already isolated so that migration can be made without changing the API contract.

## Supported uploads

The upload endpoint accepts plain text, Markdown, CSV and JSON files. PDF/DOCX extraction is deliberately not silently faked; add a dedicated parser before enabling those MIME types.
