export function apiError(error: unknown): { status: number; message: string } {
  if (error instanceof Error && error.message === 'UNAUTHORIZED') return { status: 401, message: 'Authentication required' };
  if (error instanceof Error && error.message === 'FORBIDDEN') return { status: 403, message: 'You do not have access to this resource' };
  if (error instanceof Error && error.message === 'NOT_FOUND') return { status: 404, message: 'Resource not found' };
  if (error instanceof Error && error.message === 'RATE_LIMITED') return { status: 429, message: 'Too many requests' };
  if (error instanceof Error && error.message.startsWith('INVALID_')) return { status: 400, message: error.message.slice(8).replaceAll('_', ' ') };
  console.error(error);
  return { status: 500, message: 'Internal server error' };
}
