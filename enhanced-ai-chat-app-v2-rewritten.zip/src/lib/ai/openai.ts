import OpenAI from 'openai';
import { env } from '@/lib/config/env';

export const openai = new OpenAI({ apiKey: env.OPENAI_API_KEY });

export async function createEmbedding(input: string): Promise<number[]> {
  const result = await openai.embeddings.create({ model: env.OPENAI_EMBEDDING_MODEL, input });
  return result.data[0].embedding;
}

export async function createEmbeddings(input: string[]): Promise<number[][]> {
  if (!input.length) return [];
  const result = await openai.embeddings.create({ model: env.OPENAI_EMBEDDING_MODEL, input });
  return result.data.sort((a, b) => a.index - b.index).map((item) => item.embedding);
}
