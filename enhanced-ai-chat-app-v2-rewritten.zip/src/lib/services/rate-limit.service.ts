import { cacheService } from '@/lib/services/cache.service';
import { env } from '@/lib/config/env';

export class RateLimitService {
  static async check(identifier: string): Promise<{ success: boolean; remaining: number }> {
    const key = `rate:v1:${identifier}`;
    const count = await cacheService.incrementWithWindow(key, env.RATE_LIMIT_WINDOW_SECONDS);

    // Fail open if Redis is unavailable; API still has authentication and request validation.
    if (count === null) return { success: true, remaining: env.RATE_LIMIT };
    if (count > env.RATE_LIMIT) throw new Error('RATE_LIMITED');
    return { success: true, remaining: env.RATE_LIMIT - count };
  }
}
