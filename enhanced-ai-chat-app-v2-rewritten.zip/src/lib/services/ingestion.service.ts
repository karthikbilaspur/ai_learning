import { db } from '@/lib/db';
import { createEmbeddings } from '@/lib/ai/openai';
import { telemetryService } from '@/lib/services/telemetry.service';

export interface IngestionResult { chunkCount: number; }

export class IngestionService {
  static chunkText(text: string, targetCharacters = 1800, overlapCharacters = 250): string[] {
    const normalized = text.replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    if (!normalized) return [];

    const paragraphs = normalized.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
    const chunks: string[] = [];
    let current = '';

    for (const paragraph of paragraphs) {
      if (!current) { current = paragraph; continue; }
      const candidate = `${current}\n\n${paragraph}`;
      if (candidate.length <= targetCharacters) current = candidate;
      else {
        chunks.push(current);
        const tail = current.slice(Math.max(0, current.length - overlapCharacters));
        current = `${tail}\n\n${paragraph}`;
        if (current.length > targetCharacters) {
          for (let start = 0; start < current.length; start += targetCharacters - overlapCharacters) {
            chunks.push(current.slice(start, start + targetCharacters).trim());
          }
          current = '';
        }
      }
    }
    if (current) chunks.push(current);
    return chunks.filter(Boolean);
  }

  static async processDocument(userId: string, conversationId: string, filename: string, rawContent: string): Promise<IngestionResult> {
    const conversation = await db.conversation.findFirst({ where: { id: conversationId, userId }, select: { id: true } });
    if (!conversation) throw new Error('NOT_FOUND');

    const chunks = this.chunkText(rawContent);
    if (!chunks.length) throw new Error('INVALID_EMPTY_FILE');

    const embeddings = await createEmbeddings(chunks);

    await db.$transaction(async (tx) => {
      await tx.documentChunk.deleteMany({ where: { conversationId, filename } });
      await tx.documentChunk.createMany({
        data: chunks.map((content, index) => ({
          conversationId,
          filename,
          chunkIndex: index,
          content,
          embedding: embeddings[index],
          metadata: { characters: content.length }
        }))
      });
      await tx.conversation.update({ where: { id: conversationId }, data: { ragVersion: { increment: 1 } } });
    });

    telemetryService.logEvent('document_ingested', { conversationId, filename, chunksCount: chunks.length });
    return { chunkCount: chunks.length };
  }
}
