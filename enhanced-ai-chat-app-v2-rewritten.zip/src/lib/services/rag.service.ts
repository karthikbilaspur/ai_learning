import { createEmbedding } from '@/lib/ai/openai';
import { db } from '@/lib/db';
import { env } from '@/lib/config/env';
import { cacheService } from '@/lib/services/cache.service';
import { telemetryService } from '@/lib/services/telemetry.service';
import { createHash } from 'crypto';

export interface ContextChunk {
  id: string;
  content: string;
  score: number;
  filename: string;
  chunkIndex: number;
}

function cosineSimilarity(a: number[], b: number[]) {
  if (a.length !== b.length || a.length === 0) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i]; normA += a[i] ** 2; normB += b[i] ** 2;
  }
  return normA && normB ? dot / (Math.sqrt(normA) * Math.sqrt(normB)) : 0;
}

export class RagService {
  static async retrieveContext(query: string, conversationId: string, userId: string): Promise<ContextChunk[]> {
    const start = Date.now();
    const conversation = await db.conversation.findFirst({ where: { id: conversationId, userId }, select: { id: true, ragVersion: true } });
    if (!conversation) throw new Error('NOT_FOUND');

    const hash = createHash('sha256').update(query.trim().toLowerCase()).digest('hex');
    const key = `rag:v2:${conversationId}:${conversation.ragVersion}:${hash}`;
    const cached = await cacheService.get<ContextChunk[]>(key);
    if (cached) return cached;

    const queryEmbedding = await createEmbedding(query);
    const documents = await db.documentChunk.findMany({ where: { conversationId } });

    const results = documents.map((doc) => ({
      id: doc.id,
      content: doc.content,
      filename: doc.filename,
      chunkIndex: doc.chunkIndex,
      score: cosineSimilarity(queryEmbedding, Array.isArray(doc.embedding) ? doc.embedding.map(Number) : [])
    })).sort((a, b) => b.score - a.score).slice(0, env.RAG_TOP_K);

    await cacheService.set(key, results, env.RAG_CACHE_TTL_SECONDS);
    telemetryService.logEvent('rag_retrieval', { conversationId, cacheHit: false, latencyMs: Date.now() - start, resultCount: results.length });
    return results;
  }
}
