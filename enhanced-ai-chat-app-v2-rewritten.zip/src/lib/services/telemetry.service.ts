export type TelemetryMetadata = Record<string, string | number | boolean | null | undefined>;

class TelemetryService {
  logEvent(eventName: string, metadata: TelemetryMetadata = {}) {
    console.log(JSON.stringify({ eventName, metadata, timestamp: new Date().toISOString() }));
  }
}

export const telemetryService = new TelemetryService();
