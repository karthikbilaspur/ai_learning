import { Redis } from '@upstash/redis';
import { env } from '@/lib/config/env';

class CacheService {
  private readonly client: Redis | null;

  constructor() {
    this.client = env.UPSTASH_REDIS_REST_URL && env.UPSTASH_REDIS_REST_TOKEN
      ? new Redis({ url: env.UPSTASH_REDIS_REST_URL, token: env.UPSTASH_REDIS_REST_TOKEN })
      : null;
  }

  get enabled() { return Boolean(this.client); }

  async get<T>(key: string): Promise<T | null> {
    if (!this.client) return null;
    try { return await this.client.get<T>(key); }
    catch (error) { console.warn('[Redis GET]', error); return null; }
  }

  async set<T>(key: string, value: T, ttlSeconds: number): Promise<void> {
    if (!this.client) return;
    try { await this.client.set(key, value, { ex: ttlSeconds }); }
    catch (error) { console.warn('[Redis SET]', error); }
  }

  async incrementWithWindow(key: string, windowSeconds: number): Promise<number | null> {
    if (!this.client) return null;
    try {
      const count = await this.client.incr(key);
      if (count === 1) await this.client.expire(key, windowSeconds);
      return count;
    } catch (error) {
      console.warn('[Redis INCR]', error);
      return null;
    }
  }
}

export const cacheService = new CacheService();
