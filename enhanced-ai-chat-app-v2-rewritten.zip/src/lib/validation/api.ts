import { z } from 'zod';

export const chatSchema = z.object({
  message: z.string().trim().min(1).max(12_000),
  conversationId: z.string().cuid()
});

export const settingsSchema = z.object({
  model: z.enum(['gpt-4o-mini', 'gpt-4o'])
});
