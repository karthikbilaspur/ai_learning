'use client';

import { useEffect, useState } from 'react';

type Conversation = { id: string; title: string; updatedAt: string };

export default function ConversationList() {
  const [items, setItems] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/conversations')
      .then((res) => res.json())
      .then((data) => setItems(data.conversations ?? []))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-gray-500">Loading conversations…</p>;
  if (!items.length) return <p className="text-gray-500">No conversations yet.</p>;

  return (
    <div className="space-y-3">
      {items.map((conversation) => (
        <a href={`/chat/${conversation.id}`} key={conversation.id} className="block rounded-lg border p-4 transition hover:bg-slate-50">
          <div className="flex justify-between gap-4">
            <span className="font-medium">{conversation.title}</span>
            <span className="text-sm text-gray-500">{new Date(conversation.updatedAt).toLocaleDateString()}</span>
          </div>
        </a>
      ))}
    </div>
  );
}
