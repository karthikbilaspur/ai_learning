'use client';

import { useEffect, useState } from 'react';

const models = ['gpt-4o-mini', 'gpt-4o'] as const;

export default function SettingsForm() {
  const [model, setModel] = useState<(typeof models)[number]>('gpt-4o-mini');
  const [status, setStatus] = useState('');

  useEffect(() => {
    fetch('/api/settings').then((r) => r.json()).then((data) => {
      if (models.includes(data.settings?.model)) setModel(data.settings.model);
    });
  }, []);

  async function save() {
    setStatus('Saving…');
    const response = await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model }) });
    setStatus(response.ok ? 'Saved' : 'Could not save');
  }

  return (
    <div className="space-y-4 rounded-lg border p-4">
      <div>
        <label htmlFor="model" className="block text-sm font-medium text-gray-700">Model</label>
        <select id="model" value={model} onChange={(e) => setModel(e.target.value as typeof model)} className="mt-1 block w-full rounded-md border p-2">
          <option value="gpt-4o-mini">GPT-4o mini</option>
          <option value="gpt-4o">GPT-4o</option>
        </select>
      </div>
      <button onClick={save} className="rounded-md bg-black px-4 py-2 text-white">Save</button>
      {status && <p className="text-sm text-gray-500">{status}</p>}
    </div>
  );
}
