'use client';

import { FormEvent, useState } from 'react';

export default function ChatBox({ conversationId }: { conversationId: string }) {
  const [message, setMessage] = useState('');
  const [answer, setAnswer] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [uploadStatus, setUploadStatus] = useState('');


  async function upload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadStatus('Uploading and indexing…'); setError('');
    const form = new FormData(); form.append('file', file); form.append('conversationId', conversationId);
    const response = await fetch('/api/upload', { method: 'POST', body: form });
    const data = await response.json();
    if (!response.ok) setError(data.error || 'Upload failed');
    else setUploadStatus(`${data.chunksProcessed ?? data.chunkCount} chunks indexed`);
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!message.trim() || busy) return;
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ conversationId, message }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Request failed');
      setAnswer(data.response); setMessage('');
    } catch (err) { setError(err instanceof Error ? err.message : 'Request failed'); }
    finally { setBusy(false); }
  }

  return (
    <div className="space-y-4">
      <label className="inline-block cursor-pointer rounded-md border px-4 py-2 text-sm">Upload document<input type="file" accept=".txt,.md,.csv,.json,text/plain,text/markdown,text/csv,application/json" onChange={upload} className="hidden" /></label>
      {uploadStatus && <span className="ml-3 text-sm text-gray-500">{uploadStatus}</span>}
      <div className="min-h-48 rounded-lg border p-4 whitespace-pre-wrap">{answer || 'Ask a question about your uploaded documents.'}</div>
      <form onSubmit={submit} className="flex gap-2">
        <input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Ask something…" className="flex-1 rounded-md border p-3" />
        <button disabled={busy} className="rounded-md bg-black px-5 py-2 text-white disabled:opacity-50">{busy ? '…' : 'Send'}</button>
      </form>
      {error && <p className="text-sm text-red-600">{error}</p>}
    </div>
  );
}
