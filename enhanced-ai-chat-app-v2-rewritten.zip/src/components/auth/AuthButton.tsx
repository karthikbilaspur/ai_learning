'use client';

import { signOut } from 'next-auth/react';

export default function AuthButton() {
  return <button onClick={() => signOut({ callbackUrl: '/auth/signin' })} className="text-sm underline">Sign out</button>;
}
