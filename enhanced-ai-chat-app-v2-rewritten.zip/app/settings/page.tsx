import SettingsForm from '@/components/settings/SettingsForm';

export default function SettingsPage() {
  return <main className="mx-auto max-w-2xl p-6"><h1 className="mb-4 text-2xl font-bold">Application Settings</h1><SettingsForm /></main>;
}
