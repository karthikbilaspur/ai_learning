import ConversationList from '@/components/conversations/ConversationList';

export default function ConversationsPage() {
  return <main className="mx-auto max-w-4xl p-6"><h1 className="mb-4 text-2xl font-bold">Your Conversations</h1><ConversationList /></main>;
}
