import { NextResponse } from 'next/server';
import { requireUser } from '@/lib/auth/auth';
import { db } from '@/lib/db';
import { apiError } from '@/lib/utils/errors';

export async function GET() {
  try {
    const userId = await requireUser();
    const conversations = await db.conversation.findMany({ where: { userId }, orderBy: { updatedAt: 'desc' }, select: { id: true, title: true, updatedAt: true } });
    return NextResponse.json({ conversations });
  } catch (error) {
    const { status, message } = apiError(error);
    return NextResponse.json({ error: message }, { status });
  }
}

export async function POST(req: Request) {
  try {
    const userId = await requireUser();
    const body = await req.json().catch(() => ({}));
    const title = typeof body.title === 'string' ? body.title.trim().slice(0, 120) : 'New conversation';
    const conversation = await db.conversation.create({ data: { userId, title: title || 'New conversation' } });
    return NextResponse.json({ conversation }, { status: 201 });
  } catch (error) {
    const { status, message } = apiError(error);
    return NextResponse.json({ error: message }, { status });
  }
}
