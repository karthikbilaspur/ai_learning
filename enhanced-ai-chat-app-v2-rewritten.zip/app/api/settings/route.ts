import { NextResponse } from 'next/server';
import { requireUser } from '@/lib/auth/auth';
import { db } from '@/lib/db';
import { settingsSchema } from '@/lib/validation/api';
import { apiError } from '@/lib/utils/errors';

export async function GET() {
  try {
    const userId = await requireUser();
    const settings = await db.userSettings.upsert({ where: { userId }, create: { userId }, update: {} });
    return NextResponse.json({ settings });
  } catch (error) {
    const { status, message } = apiError(error);
    return NextResponse.json({ error: message }, { status });
  }
}

export async function PUT(req: Request) {
  try {
    const userId = await requireUser();
    const { model } = settingsSchema.parse(await req.json());
    const settings = await db.userSettings.upsert({ where: { userId }, create: { userId, model }, update: { model } });
    return NextResponse.json({ settings });
  } catch (error) {
    const { status, message } = apiError(error);
    return NextResponse.json({ error: message }, { status });
  }
}
