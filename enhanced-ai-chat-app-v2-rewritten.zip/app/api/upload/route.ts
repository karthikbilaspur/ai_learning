import { NextRequest, NextResponse } from 'next/server';
import { requireUser } from '@/lib/auth/auth';
import { env } from '@/lib/config/env';
import { IngestionService } from '@/lib/services/ingestion.service';
import { apiError } from '@/lib/utils/errors';
import { RateLimitService } from '@/lib/services/rate-limit.service';

const allowedTypes = new Set([
  'text/plain', 'text/markdown', 'text/csv', 'application/json'
]);

export async function POST(req: NextRequest) {
  try {
    const userId = await requireUser();
    await RateLimitService.check(userId);
    const formData = await req.formData();
    const file = formData.get('file');
    const conversationId = formData.get('conversationId');

    if (!(file instanceof File) || typeof conversationId !== 'string') throw new Error('INVALID_FILE_OR_CONVERSATION');
    if (file.size === 0) throw new Error('INVALID_EMPTY_FILE');
    if (file.size > env.MAX_UPLOAD_SIZE_MB * 1024 * 1024) throw new Error('INVALID_FILE_TOO_LARGE');
    if (!allowedTypes.has(file.type)) throw new Error('INVALID_FILE_TYPE');

    const content = await file.text();
    const result = await IngestionService.processDocument(userId, conversationId, file.name.slice(0, 255), content);
    return NextResponse.json({ success: true, ...result });
  } catch (error) {
    const { status, message } = apiError(error);
    return NextResponse.json({ error: message }, { status });
  }
}
