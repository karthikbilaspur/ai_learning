import { NextRequest, NextResponse } from 'next/server';
import { requireUser } from '@/lib/auth/auth';
import { RateLimitService } from '@/lib/services/rate-limit.service';
import { ChatService } from '@/lib/services/chat.service';
import { chatSchema } from '@/lib/validation/api';
import { apiError } from '@/lib/utils/errors';

export async function POST(req: NextRequest) {
  try {
    const userId = await requireUser();
    await RateLimitService.check(userId);
    const body = chatSchema.parse(await req.json());
    const result = await ChatService.answer(userId, body.conversationId, body.message);
    return NextResponse.json(result);
  } catch (error) {
    const { status, message } = apiError(error);
    return NextResponse.json({ error: message }, { status });
  }
}
