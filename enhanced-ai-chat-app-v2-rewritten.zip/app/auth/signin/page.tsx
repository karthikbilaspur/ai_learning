'use client';

import { signIn } from 'next-auth/react';

export default function SignInPage() {
  return (
    <main className="mx-auto max-w-md p-10 text-center">
      <h1 className="text-2xl font-bold">Sign in</h1>
      <p className="my-4 text-gray-600">Sign in to access your conversations and documents.</p>
      <button onClick={() => signIn('google', { callbackUrl: '/conversations' })} className="rounded-md bg-black px-5 py-3 text-white">Continue with Google</button>
    </main>
  );
}
