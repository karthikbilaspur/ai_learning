import ChatBox from '@/components/chat/ChatBox';

export default async function ChatPage({ params }: { params: { conversationId: string } }) {
  return (
    <main className="mx-auto max-w-4xl p-6">
      <h1 className="mb-6 text-2xl font-bold">AI Chat</h1>
      <ChatBox conversationId={params.conversationId} />
    </main>
  );
}
