export default function HomePage() {
  return <main className="mx-auto max-w-3xl p-10"><h1 className="text-3xl font-bold">Enhanced AI Chat</h1><p className="mt-3 text-gray-600">Authenticated RAG chat with embeddings, semantic retrieval, Redis caching and persistent settings.</p></main>;
}
