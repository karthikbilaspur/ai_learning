import { describe, expect, it } from 'vitest';
import { IngestionService } from '@/lib/services/ingestion.service';

describe('IngestionService.chunkText', () => {
  it('normalizes whitespace and creates multiple chunks', () => {
    const text = Array.from({ length: 20 }, (_, i) => `Paragraph ${i} contains useful information.`).join('\n\n');
    const chunks = IngestionService.chunkText(text, 120, 20);
    expect(chunks.length).toBeGreaterThan(1);
    expect(chunks.every((chunk) => chunk.trim().length > 0)).toBe(true);
  });

  it('returns an empty array for blank input', () => {
    expect(IngestionService.chunkText('   \n\n ')).toEqual([]);
  });
});
