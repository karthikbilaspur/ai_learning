import { describe, expect, it } from 'vitest';

function cosineSimilarity(a: number[], b: number[]) {
  const dot = a.reduce((sum, value, i) => sum + value * b[i], 0);
  const normA = Math.sqrt(a.reduce((sum, value) => sum + value ** 2, 0));
  const normB = Math.sqrt(b.reduce((sum, value) => sum + value ** 2, 0));
  return dot / (normA * normB);
}

describe('vector similarity', () => {
  it('ranks identical vectors at 1', () => expect(cosineSimilarity([1, 0], [1, 0])).toBe(1));
  it('distinguishes orthogonal vectors', () => expect(cosineSimilarity([1, 0], [0, 1])).toBe(0));
});
