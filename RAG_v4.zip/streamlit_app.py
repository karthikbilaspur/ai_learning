import os
import streamlit as st
import requests

API = os.getenv("API_URL", "http://localhost:8000")
API_KEY = os.getenv("API_KEY", "")  # must be one of the keys in app/config.py's API_KEYS

HEADERS = {"X-API-Key": API_KEY} if API_KEY else {}

st.set_page_config(page_title="Chat with my Docs - pgvector", layout="wide")
st.title("📄 Chat with my documents (PostgreSQL + pgvector)")

with st.sidebar:
    st.header("Controls")
    filter_file = st.text_input("Filter by filename (optional)")
    top_k = st.slider("Context chunks (final after reranking)", 3, 15, 8)
    use_streaming = st.checkbox("Stream response", value=True)

    st.markdown("---")
    st.subheader("Upload a document")
    uploaded = st.file_uploader("PDF, MD, TXT, DOCX, HTML, or CSV",
                                 type=["pdf", "md", "txt", "docx", "html", "htm", "csv"])
    if uploaded is not None and st.button("Ingest file"):
        with st.spinner("Ingesting..."):
            try:
                files = {"file": (uploaded.name, uploaded.getvalue())}
                resp = requests.post(f"{API}/documents/upload", headers=HEADERS, files=files, timeout=120)
                resp.raise_for_status()
                st.success(f"Ingested {uploaded.name}")
                st.rerun()
            except requests.RequestException as e:
                detail = ""
                try:
                    detail = e.response.json().get("detail", "")
                except Exception:
                    pass
                st.error(f"Upload failed: {detail or e}")

    st.markdown("---")
    st.write("Documents in DB:")
    try:
        docs_resp = requests.get(f"{API}/documents", headers=HEADERS, timeout=10)
        docs_resp.raise_for_status()
        docs = docs_resp.json()
        if not docs:
            st.caption("No documents ingested yet.")
        for d in docs:
            col1, col2, col3 = st.columns([3, 1, 1])
            col1.caption(f"{d['filename']} - {d['chunks']} chunks")
            if col2.button("↻", key=f"reindex_{d['id']}", help="Re-index this file"):
                try:
                    requests.post(f"{API}/documents/{d['id']}/reindex", headers=HEADERS, timeout=120).raise_for_status()
                    st.success("Reindexed")
                    st.rerun()
                except requests.RequestException as e:
                    st.error(f"Reindex failed: {e}")
            if col3.button("🗑", key=f"del_{d['id']}"):
                try:
                    requests.delete(f"{API}/documents/{d['id']}", headers=HEADERS, timeout=10).raise_for_status()
                    st.rerun()
                except requests.RequestException as e:
                    st.error(f"Delete failed: {e}")
    except requests.RequestException as e:
        st.warning(f"API not reachable: {e}")

    st.markdown("---")
    st.subheader("Usage")
    try:
        u = requests.get(f"{API}/usage", headers=HEADERS, timeout=10)
        u.raise_for_status()
        u = u.json()
        st.caption(f"Tenant: {u['owner']}")
        st.metric("Chat calls", u["total_chat_calls"])
        st.metric("Est. cost (USD)", f"${u['total_cost_usd']:.4f}")
        st.caption(f"{u['total_prompt_tokens']} prompt / {u['total_completion_tokens']} completion tokens")
    except requests.RequestException:
        st.caption("Usage data unavailable.")

if "session_id" not in st.session_state:
    st.session_state.session_id = None
if "messages" not in st.session_state:
    st.session_state.messages = []

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

q = st.chat_input("Ask about your docs...")
if q:
    st.session_state.messages.append({"role": "user", "content": q})
    with st.chat_message("user"):
        st.markdown(q)

    payload = {
        "question": q,
        "session_id": st.session_state.session_id,
        "filename_filter": filter_file or None,
        "top_k": top_k,
    }

    with st.chat_message("assistant"):
        if use_streaming:
            placeholder = st.empty()
            full_text = ""
            try:
                with requests.post(
                    f"{API}/chat/stream", json=payload, headers=HEADERS, stream=True, timeout=60
                ) as resp:
                    resp.raise_for_status()
                    for line in resp.iter_lines(decode_unicode=True):
                        if not line or not line.startswith("data: "):
                            continue
                        data = line[len("data: "):]
                        if data == "[DONE]":
                            break
                        full_text += data.replace("\\n", "\n")
                        placeholder.markdown(full_text + "▌")
                placeholder.markdown(full_text)
            except requests.RequestException as e:
                full_text = f"Error contacting API: {e}"
                placeholder.markdown(full_text)
            st.session_state.messages.append({"role": "assistant", "content": full_text})
        else:
            with st.spinner("Rewriting query, searching + reranking..."):
                try:
                    res = requests.post(f"{API}/chat", json=payload, headers=HEADERS, timeout=60)
                    res.raise_for_status()
                    res = res.json()
                    st.session_state.session_id = res["session_id"]
                    st.markdown(res["answer"])
                    st.markdown("---")
                    st.subheader("Sources (reranked)")
                    for s in res["sources"]:
                        label = f"Chunk {s['id']} | score {s.get('rerank_score', 0):.3f} | {s['metadata'].get('filename')} p{s['metadata'].get('page', '-')}"
                        with st.expander(label):
                            st.write(s["content"])
                            st.json(s["metadata"])
                    st.session_state.messages.append({"role": "assistant", "content": res["answer"]})
                except requests.RequestException as e:
                    st.error(f"Error contacting API: {e}")
