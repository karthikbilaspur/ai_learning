import asyncio
from .db import db_cursor
from .config import EMBEDDING_MODEL
from .llm import rewrite_query
from .logging_conf import get_logger
from sentence_transformers import SentenceTransformer, CrossEncoder

log = get_logger(__name__)

_embed_model = None
_reranker = None


def get_embed_model():
    global _embed_model
    if _embed_model is None:
        log.info(f"Loading embedding model {EMBEDDING_MODEL}...")
        _embed_model = SentenceTransformer(EMBEDDING_MODEL)
    return _embed_model


def get_reranker():
    global _reranker
    if _reranker is None:
        log.info("Loading reranker cross-encoder/ms-marco-MiniLM-L-6-v2...")
        _reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
    return _reranker


def _embed(text: str):
    return get_embed_model().encode(text).tolist()


async def _search_one(query: str, owner: str, top_k: int, filename_filter: str | None):
    """Run vector + full-text search for a single query string, scoped to
    `owner`. CPU-bound embedding runs in a thread so it doesn't block the
    event loop."""
    q_emb = await asyncio.to_thread(_embed, query)

    async with db_cursor() as cur:
        if filename_filter:
            await cur.execute('''
                SELECT c.id, c.content, c.metadata, 1 - (c.embedding <=> %s) as score
                FROM chunks c JOIN documents d ON c.document_id = d.id
                WHERE d.owner = %s AND c.metadata->>'filename' ILIKE %s
                ORDER BY c.embedding <=> %s
                LIMIT %s
            ''', (q_emb, owner, f"%{filename_filter}%", q_emb, top_k))
        else:
            await cur.execute('''
                SELECT c.id, c.content, c.metadata, 1 - (c.embedding <=> %s) as score
                FROM chunks c JOIN documents d ON c.document_id = d.id
                WHERE d.owner = %s
                ORDER BY c.embedding <=> %s
                LIMIT %s
            ''', (q_emb, owner, q_emb, top_k))
        vec_rows = await cur.fetchall()
        vec_ranked = [{"id": r[0], "content": r[1], "metadata": r[2], "score": r[3]} for r in vec_rows]

        if filename_filter:
            await cur.execute('''
                SELECT c.id, c.content, c.metadata, ts_rank(c.tsv, plainto_tsquery('english', %s)) as rank
                FROM chunks c JOIN documents d ON c.document_id = d.id
                WHERE d.owner = %s AND c.tsv @@ plainto_tsquery('english', %s) AND c.metadata->>'filename' ILIKE %s
                ORDER BY rank DESC
                LIMIT %s
            ''', (query, owner, query, f"%{filename_filter}%", top_k))
        else:
            await cur.execute('''
                SELECT c.id, c.content, c.metadata, ts_rank(c.tsv, plainto_tsquery('english', %s)) as rank
                FROM chunks c JOIN documents d ON c.document_id = d.id
                WHERE d.owner = %s AND c.tsv @@ plainto_tsquery('english', %s)
                ORDER BY rank DESC
                LIMIT %s
            ''', (query, owner, query, top_k))
        ft_rows = await cur.fetchall()
        ft_ranked = [{"id": r[0], "content": r[1], "metadata": r[2], "score": r[3]} for r in ft_rows]

    return vec_ranked, ft_ranked


def _reciprocal_rank_fusion(ranked_lists: list[list[dict]], k: int = 60) -> dict:
    """Standard RRF: fuse several ranked lists (from different query variants
    and/or vector vs full-text) into one score per chunk id, without needing
    the raw scores to be on the same scale."""
    fused: dict[int, dict] = {}
    scores: dict[int, float] = {}
    for ranked in ranked_lists:
        for rank, item in enumerate(ranked):
            cid = item["id"]
            fused[cid] = item
            scores[cid] = scores.get(cid, 0.0) + 1.0 / (k + rank + 1)
    for cid in fused:
        fused[cid] = {**fused[cid], "fusion_score": scores[cid]}
    return fused


async def hybrid_search(query: str, owner: str, top_k=50, final_k=8, filename_filter=None):
    """Multi-tenant hybrid search: optionally fans the query out into a few
    LLM-rewritten paraphrases (recall boost), runs vector + full-text search
    for each variant concurrently, fuses everything with RRF, then reranks
    the fused candidates with a cross-encoder for final precision."""
    variants = [query] + await rewrite_query(query)
    log.info(f"Searching {len(variants)} query variant(s) for owner={owner}")

    results = await asyncio.gather(*[
        _search_one(v, owner, top_k, filename_filter) for v in variants
    ])

    all_ranked_lists = []
    for vec_ranked, ft_ranked in results:
        all_ranked_lists.append(vec_ranked)
        all_ranked_lists.append(ft_ranked)

    fused = _reciprocal_rank_fusion(all_ranked_lists)
    merged = sorted(fused.values(), key=lambda x: x["fusion_score"], reverse=True)[:top_k]

    if not merged:
        return []

    reranker = get_reranker()
    pairs = [[query, c["content"]] for c in merged]
    scores = await asyncio.to_thread(reranker.predict, pairs)

    reranked = sorted(zip(merged, scores), key=lambda x: x[1], reverse=True)
    final = [{**doc, "rerank_score": float(score)} for doc, score in reranked[:final_k]]
    return final
