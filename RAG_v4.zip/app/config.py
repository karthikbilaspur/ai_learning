import os
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://raguser:ragpass@localhost:5432/ragdb")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "384"))
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")

# --- Auth / multi-tenancy ---
# Format: "key1:tenant_a,key2:tenant_b". Each key maps to a tenant name; all
# documents/chat/usage are scoped to the tenant resolved from the caller's key.
# Back-compat: if API_KEYS is empty but API_KEY is set, that single key maps
# to a tenant called "default" (single-tenant mode).
_raw_api_keys = os.getenv("API_KEYS", "")
API_KEYS = {}
if _raw_api_keys:
    for pair in _raw_api_keys.split(","):
        pair = pair.strip()
        if not pair or ":" not in pair:
            continue
        key, tenant = pair.split(":", 1)
        API_KEYS[key.strip()] = tenant.strip()
_legacy_single_key = os.getenv("API_KEY", "")
if not API_KEYS and _legacy_single_key:
    API_KEYS[_legacy_single_key] = "default"

AUTH_ENABLED = bool(API_KEYS)

# --- CORS ---
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8501").split(",") if o.strip()]

# --- Logging ---
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# --- Connection pool sizing ---
DB_POOL_MIN_CONN = int(os.getenv("DB_POOL_MIN_CONN", "1"))
DB_POOL_MAX_CONN = int(os.getenv("DB_POOL_MAX_CONN", "10"))

# --- Rate limiting ---
RATE_LIMIT_CHAT = os.getenv("RATE_LIMIT_CHAT", "20/minute")
RATE_LIMIT_UPLOAD = os.getenv("RATE_LIMIT_UPLOAD", "5/minute")

# --- Input validation caps ---
MAX_QUESTION_LEN = int(os.getenv("MAX_QUESTION_LEN", "2000"))
MAX_FILENAME_FILTER_LEN = int(os.getenv("MAX_FILENAME_FILTER_LEN", "255"))
MAX_TOP_K = int(os.getenv("MAX_TOP_K", "25"))
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))

# --- New: query rewriting ---
QUERY_REWRITE_ENABLED = os.getenv("QUERY_REWRITE_ENABLED", "true").lower() == "true"
QUERY_REWRITE_COUNT = int(os.getenv("QUERY_REWRITE_COUNT", "2"))  # extra paraphrases beyond the original

# --- New: usage / cost tracking (rough per-1K-token pricing, override as needed) ---
PRICE_PER_1K_PROMPT = float(os.getenv("PRICE_PER_1K_PROMPT", "0.00015"))      # gpt-4o-mini-ish default
PRICE_PER_1K_COMPLETION = float(os.getenv("PRICE_PER_1K_COMPLETION", "0.0006"))
