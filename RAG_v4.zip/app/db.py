from contextlib import asynccontextmanager
import psycopg
from psycopg_pool import AsyncConnectionPool
from pgvector.psycopg import register_vector_async
from .config import DATABASE_URL, DB_POOL_MIN_CONN, DB_POOL_MAX_CONN
from .logging_conf import get_logger

log = get_logger(__name__)

_pool: AsyncConnectionPool | None = None


async def _configure(conn: psycopg.AsyncConnection):
    await register_vector_async(conn)


async def get_pool() -> AsyncConnectionPool:
    """Lazily create + open the async connection pool. Reusing pooled
    connections instead of opening a fresh one per request is the biggest
    single latency win under concurrent load, and psycopg3's native asyncio
    support means DB I/O no longer blocks the FastAPI event loop."""
    global _pool
    if _pool is None:
        log.info(f"Creating async DB pool (min={DB_POOL_MIN_CONN}, max={DB_POOL_MAX_CONN})")
        _pool = AsyncConnectionPool(
            conninfo=DATABASE_URL,
            min_size=DB_POOL_MIN_CONN,
            max_size=DB_POOL_MAX_CONN,
            configure=_configure,
            open=False,
        )
        await _pool.open(wait=True)
    return _pool


async def close_pool():
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


@asynccontextmanager
async def db_cursor(commit: bool = False):
    """Async context manager: checks a connection out of the pool, hands
    back a cursor, commits/rolls back, and always returns the connection."""
    pool = await get_pool()
    async with pool.connection() as conn:
        async with conn.cursor() as cur:
            try:
                yield cur
                if commit:
                    await conn.commit()
            except Exception:
                await conn.rollback()
                raise


async def init_db():
    async with db_cursor(commit=True) as cur:
        await cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        await cur.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id SERIAL PRIMARY KEY,
                filename TEXT NOT NULL,
                filetype TEXT,
                owner TEXT NOT NULL DEFAULT 'default',
                total_chunks INT DEFAULT 0,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
        await cur.execute("CREATE INDEX IF NOT EXISTS documents_owner_idx ON documents (owner);")
        await cur.execute('''
            CREATE TABLE IF NOT EXISTS chunks (
                id SERIAL PRIMARY KEY,
                document_id INT REFERENCES documents(id) ON DELETE CASCADE,
                content TEXT NOT NULL,
                metadata JSONB,
                embedding vector(384),
                tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', content)) STORED
            );
        ''')
        await cur.execute("CREATE INDEX IF NOT EXISTS chunks_embedding_idx ON chunks USING hnsw (embedding vector_cosine_ops);")
        await cur.execute("CREATE INDEX IF NOT EXISTS chunks_tsv_idx ON chunks USING GIN (tsv);")
        await cur.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id SERIAL PRIMARY KEY,
                session_id TEXT,
                owner TEXT NOT NULL DEFAULT 'default',
                role TEXT,
                content TEXT,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
        await cur.execute('''
            CREATE TABLE IF NOT EXISTS usage_log (
                id SERIAL PRIMARY KEY,
                owner TEXT NOT NULL DEFAULT 'default',
                session_id TEXT,
                prompt_tokens INT DEFAULT 0,
                completion_tokens INT DEFAULT 0,
                cost_usd NUMERIC(10,6) DEFAULT 0,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
    log.info("DB initialized")
