from openai import AsyncOpenAI, OpenAIError
from .config import (
    OPENAI_API_KEY, LLM_MODEL, QUERY_REWRITE_ENABLED, QUERY_REWRITE_COUNT,
    PRICE_PER_1K_PROMPT, PRICE_PER_1K_COMPLETION,
)
from .logging_conf import get_logger

log = get_logger(__name__)

client = AsyncOpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

SYSTEM_PROMPT = '''You are a helpful assistant for "Chat with my documents".
Rules:
1. Answer ONLY from the provided context.
2. If not in context, say "I couldn't find that in your documents."
3. Always cite sources as [chunk_id] after the sentence.
4. Be concise, but include page numbers/filename if present in metadata.
5. If user asks for summary, summarize across chunks.
'''


def build_prompt(context_chunks, question, chat_history=None):
    ctx = "\n\n".join([
        f"[{c['id']}] (File: {c['metadata'].get('filename')} Page: {c['metadata'].get('page', 'N/A')})\n{c['content']}"
        for c in context_chunks
    ])
    hist = ""
    if chat_history:
        hist = "\n".join([f"{m['role']}: {m['content']}" for m in chat_history[-6:]])
    return f"{SYSTEM_PROMPT}\n\nChat History:\n{hist}\n\nContext:\n{ctx}\n\nQuestion: {question}\nAnswer:"


def estimate_cost(prompt_tokens: int, completion_tokens: int) -> float:
    return round(
        (prompt_tokens / 1000) * PRICE_PER_1K_PROMPT
        + (completion_tokens / 1000) * PRICE_PER_1K_COMPLETION,
        6,
    )


async def generate_answer(context_chunks, question, chat_history=None):
    """Non-streaming answer generation. Returns (answer_text, usage_dict) where
    usage_dict has prompt_tokens/completion_tokens/cost_usd (all 0 in mock mode)."""
    if not client:
        answer = (
            f"(Mock LLM - set OPENAI_API_KEY)\nBased on {len(context_chunks)} chunks, "
            f"the answer to '{question}' is in the context.\n\n"
            + "\n".join([c['content'][:300] for c in context_chunks])
        )
        return answer, {"prompt_tokens": 0, "completion_tokens": 0, "cost_usd": 0.0}

    prompt = build_prompt(context_chunks, question, chat_history)
    try:
        resp = await client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        usage = resp.usage
        pt, ct = (usage.prompt_tokens, usage.completion_tokens) if usage else (0, 0)
        return resp.choices[0].message.content, {
            "prompt_tokens": pt, "completion_tokens": ct, "cost_usd": estimate_cost(pt, ct),
        }
    except OpenAIError as e:
        log.error(f"OpenAI call failed: {e}")
        return "Sorry, I hit an error talking to the language model. Please try again.", {
            "prompt_tokens": 0, "completion_tokens": 0, "cost_usd": 0.0,
        }


async def stream_answer(context_chunks, question, chat_history=None):
    """Async generator yielding text chunks as they arrive (SSE-friendly).
    Falls back to yielding the whole mock/error answer in one chunk."""
    if not client:
        answer, _ = await generate_answer(context_chunks, question, chat_history)
        yield answer
        return

    prompt = build_prompt(context_chunks, question, chat_history)
    try:
        stream = await client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            stream=True,
        )
        async for event in stream:
            delta = event.choices[0].delta.content if event.choices else None
            if delta:
                yield delta
    except OpenAIError as e:
        log.error(f"OpenAI streaming call failed: {e}")
        yield "\n\n[Error talking to the language model. Please try again.]"


async def rewrite_query(question: str) -> list[str]:
    """Generate a few paraphrased variants of the question to widen recall
    before retrieval. Returns [] (just use the original) in mock mode, on
    error, or when QUERY_REWRITE_ENABLED is false."""
    if not QUERY_REWRITE_ENABLED or not client or QUERY_REWRITE_COUNT < 1:
        return []

    prompt = (
        f"Rewrite the following question into {QUERY_REWRITE_COUNT} different "
        f"phrasings that preserve its exact meaning, to improve document search "
        f"recall. Output ONLY the {QUERY_REWRITE_COUNT} rewritten questions, one "
        f"per line, no numbering, no extra text.\n\nQuestion: {question}"
    )
    try:
        resp = await client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=200,
        )
        text = resp.choices[0].message.content or ""
        variants = [line.strip("- ").strip() for line in text.splitlines() if line.strip()]
        return variants[:QUERY_REWRITE_COUNT]
    except OpenAIError as e:
        log.warning(f"Query rewrite failed, falling back to original query only: {e}")
        return []
