import asyncio
import pathlib
import json
import argparse
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from .db import db_cursor, init_db
from .config import EMBEDDING_MODEL
from .logging_conf import get_logger

log = get_logger(__name__)

splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=150,
    separators=["\n## ", "\n### ", "\n\n", "\n", ". ", " "]
)

SUPPORTED_EXTENSIONS = [".pdf", ".md", ".txt", ".docx", ".html", ".htm", ".csv"]

_model = None


def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(EMBEDDING_MODEL)
    return _model


def load_file(path: pathlib.Path):
    """Returns a list of (text, metadata) tuples. Extended in v4 with
    .docx, .html/.htm, and .csv support alongside pdf/md/txt."""
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        try:
            reader = PdfReader(str(path))
        except Exception as e:
            log.error(f"Could not read PDF {path}: {e}")
            return []
        texts = []
        for i, page in enumerate(reader.pages):
            t = page.extract_text() or ""
            if t.strip():
                texts.append((t, {"page": i + 1}))
        return texts

    elif suffix in [".md", ".txt"]:
        try:
            txt = path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            log.error(f"Could not read {path}: {e}")
            return []
        return [(txt, {})]

    elif suffix == ".docx":
        try:
            import docx  # python-docx
            document = docx.Document(str(path))
            txt = "\n".join(p.text for p in document.paragraphs if p.text.strip())
            return [(txt, {})] if txt.strip() else []
        except Exception as e:
            log.error(f"Could not read DOCX {path}: {e}")
            return []

    elif suffix in [".html", ".htm"]:
        try:
            from bs4 import BeautifulSoup
            raw = path.read_text(encoding="utf-8", errors="ignore")
            soup = BeautifulSoup(raw, "html.parser")
            for tag in soup(["script", "style"]):
                tag.decompose()
            txt = soup.get_text(separator="\n")
            txt = "\n".join(line.strip() for line in txt.splitlines() if line.strip())
            return [(txt, {})] if txt.strip() else []
        except Exception as e:
            log.error(f"Could not read HTML {path}: {e}")
            return []

    elif suffix == ".csv":
        try:
            import csv
            with open(path, newline="", encoding="utf-8", errors="ignore") as f:
                reader = csv.reader(f)
                rows = list(reader)
            if not rows:
                return []
            header, data_rows = rows[0], rows[1:]
            # Turn each row into a small readable text block: "col: val, col: val"
            texts = []
            for i, row in enumerate(data_rows):
                pairs = [f"{h.strip()}: {v.strip()}" for h, v in zip(header, row)]
                texts.append((", ".join(pairs), {"row": i + 1}))
            return texts
        except Exception as e:
            log.error(f"Could not read CSV {path}: {e}")
            return []

    else:
        return []


async def ingest_single_file(path: pathlib.Path, owner: str = "default", existing_doc_id: int | None = None) -> int:
    """Ingest (or re-ingest) one file for a given tenant. Returns the document id.

    If `existing_doc_id` is given, its old chunks are deleted first and the
    same document row is reused (used by the /reindex endpoint).
    Parsing/embedding are CPU-bound and run in a thread; DB writes are async.
    """
    pages = await asyncio.to_thread(load_file, path)
    if not pages:
        raise ValueError(f"No extractable text in {path}")

    model = await asyncio.to_thread(get_model)
    all_chunks = []
    for text, meta in pages:
        chunks = splitter.split_text(text)
        for ch in chunks:
            all_chunks.append((ch, {**meta, "filename": str(path)}))

    if not all_chunks:
        raise ValueError(f"No chunks produced for {path}")

    embeddings = await asyncio.to_thread(
        model.encode, [c[0] for c in all_chunks], show_progress_bar=False, batch_size=32
    )
    rows_data = [(content, json.dumps(meta), emb.tolist()) for (content, meta), emb in zip(all_chunks, embeddings)]

    async with db_cursor(commit=True) as cur:
        if existing_doc_id is not None:
            doc_id = existing_doc_id
            await cur.execute("DELETE FROM chunks WHERE document_id=%s", (doc_id,))
        else:
            await cur.execute(
                "INSERT INTO documents (filename, filetype, owner) VALUES (%s,%s,%s) RETURNING id",
                (str(path), path.suffix, owner),
            )
            row = await cur.fetchone()
            doc_id = row[0]

        rows = [(doc_id, content, meta_json, emb) for content, meta_json, emb in rows_data]
        await cur.executemany(
            "INSERT INTO chunks (document_id, content, metadata, embedding) VALUES (%s, %s, %s, %s)",
            rows,
        )
        await cur.execute("UPDATE documents SET total_chunks=%s WHERE id=%s", (len(rows), doc_id))

    return doc_id


async def ingest(folder="docs", owner="default"):
    await init_db()
    docs_path = pathlib.Path(folder)
    if not docs_path.exists():
        log.error(f"Folder '{folder}' does not exist.")
        return

    files = [f for f in docs_path.rglob("*") if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS]
    if not files:
        log.warning(f"No supported files ({', '.join(SUPPORTED_EXTENSIONS)}) found in '{folder}'.")

    for file in files:
        try:
            log.info(f"Ingesting {file}...")
            doc_id = await ingest_single_file(file, owner=owner)
            log.info(f"  -> doc_id={doc_id}")
        except Exception as e:
            log.error(f"Failed to ingest {file}: {e}")

    log.info("Ingestion done")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", default="docs")
    parser.add_argument("--owner", default="default", help="Tenant name to tag ingested documents with")
    args = parser.parse_args()
    asyncio.run(ingest(args.folder, args.owner))
