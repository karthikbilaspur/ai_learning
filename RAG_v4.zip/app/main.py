import time
import uuid
import pathlib
import tempfile
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, field_validator
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from .retrieval import hybrid_search
from .llm import generate_answer, stream_answer
from .db import init_db, close_pool, db_cursor
from .ingest import ingest_single_file, SUPPORTED_EXTENSIONS
from .auth import require_api_key
from .config import (
    CORS_ORIGINS, AUTH_ENABLED, RATE_LIMIT_CHAT, RATE_LIMIT_UPLOAD,
    MAX_QUESTION_LEN, MAX_FILENAME_FILTER_LEN, MAX_TOP_K, MAX_UPLOAD_MB,
)
from .logging_conf import get_logger

log = get_logger(__name__)

limiter = Limiter(key_func=get_remote_address)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    if not AUTH_ENABLED:
        log.warning("No API_KEYS/API_KEY configured - endpoints are UNAUTHENTICATED (single 'default' tenant).")
    yield
    await close_pool()


app = FastAPI(title="Chat with Docs - pgvector RAG", lifespan=lifespan)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration_ms = (time.time() - start) * 1000
    log.info(f"{request.method} {request.url.path} -> {response.status_code} ({duration_ms:.1f}ms)")
    return response


class ChatRequest(BaseModel):
    question: str
    session_id: str | None = None
    filename_filter: str | None = None
    top_k: int = 8

    @field_validator("question")
    @classmethod
    def question_not_empty_or_too_long(cls, v):
        v = v.strip()
        if not v:
            raise ValueError("question must not be empty")
        if len(v) > MAX_QUESTION_LEN:
            raise ValueError(f"question exceeds {MAX_QUESTION_LEN} characters")
        return v

    @field_validator("filename_filter")
    @classmethod
    def filter_len(cls, v):
        if v and len(v) > MAX_FILENAME_FILTER_LEN:
            raise ValueError(f"filename_filter exceeds {MAX_FILENAME_FILTER_LEN} characters")
        return v

    @field_validator("top_k")
    @classmethod
    def top_k_bounds(cls, v):
        if v < 1 or v > MAX_TOP_K:
            raise ValueError(f"top_k must be between 1 and {MAX_TOP_K}")
        return v


@app.get("/")
async def health():
    return {
        "status": "ok",
        "db": "pgvector (async, psycopg3)",
        "auth_enabled": AUTH_ENABLED,
        "features": [
            "hybrid_search", "reranking", "chat_history", "streaming", "api_key_auth",
            "connection_pooling", "rate_limiting", "file_upload", "per_file_reindex",
            "async_db", "multi_tenancy", "query_rewriting", "usage_tracking",
            "docx_html_csv_ingestion",
        ],
    }


async def _load_history(cur, owner, session_id):
    await cur.execute(
        "SELECT role, content FROM chat_history WHERE session_id=%s AND owner=%s ORDER BY id ASC LIMIT 20",
        (session_id, owner),
    )
    rows = await cur.fetchall()
    return [{"role": r[0], "content": r[1]} for r in rows]


async def _save_turn(cur, owner, session_id, question, answer):
    await cur.execute(
        "INSERT INTO chat_history (session_id, owner, role, content) VALUES (%s,%s,%s,%s)",
        (session_id, owner, "user", question),
    )
    await cur.execute(
        "INSERT INTO chat_history (session_id, owner, role, content) VALUES (%s,%s,%s,%s)",
        (session_id, owner, "assistant", str(answer)),
    )


async def _log_usage(cur, owner, session_id, usage: dict):
    await cur.execute(
        "INSERT INTO usage_log (owner, session_id, prompt_tokens, completion_tokens, cost_usd) VALUES (%s,%s,%s,%s,%s)",
        (owner, session_id, usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0), usage.get("cost_usd", 0.0)),
    )


@app.post("/chat")
@limiter.limit(RATE_LIMIT_CHAT)
async def chat(request: Request, req: ChatRequest, owner: str = Depends(require_api_key)):
    session_id = req.session_id or str(uuid.uuid4())

    try:
        chunks = await hybrid_search(req.question, owner=owner, final_k=req.top_k, filename_filter=req.filename_filter)

        async with db_cursor(commit=True) as cur:
            history = await _load_history(cur, owner, session_id)
            if not chunks:
                answer, usage = "I couldn't find that in your documents.", {"prompt_tokens": 0, "completion_tokens": 0, "cost_usd": 0.0}
            else:
                answer, usage = await generate_answer(chunks, req.question, chat_history=history)

            await _save_turn(cur, owner, session_id, req.question, answer)
            await _log_usage(cur, owner, session_id, usage)
    except Exception as e:
        log.error(f"/chat failed: {e}")
        raise HTTPException(status_code=500, detail="Something went wrong processing your question.")

    return {"session_id": session_id, "answer": answer, "sources": chunks, "usage": usage}


@app.post("/chat/stream")
@limiter.limit(RATE_LIMIT_CHAT)
async def chat_stream(request: Request, req: ChatRequest, owner: str = Depends(require_api_key)):
    session_id = req.session_id or str(uuid.uuid4())

    try:
        chunks = await hybrid_search(req.question, owner=owner, final_k=req.top_k, filename_filter=req.filename_filter)
        async with db_cursor() as cur:
            history = await _load_history(cur, owner, session_id)
    except Exception as e:
        log.error(f"/chat/stream setup failed: {e}")
        raise HTTPException(status_code=500, detail="Something went wrong preparing your answer.")

    async def event_gen():
        collected = []
        yield f"event: session\ndata: {session_id}\n\n"

        if not chunks:
            msg = "I couldn't find that in your documents."
            collected.append(msg)
            yield f"data: {msg}\n\n"
        else:
            async for piece in stream_answer(chunks, req.question, chat_history=history):
                collected.append(piece)
                safe = piece.replace("\n", "\\n")
                yield f"data: {safe}\n\n"

        full_answer = "".join(collected)
        try:
            async with db_cursor(commit=True) as cur:
                await _save_turn(cur, owner, session_id, req.question, full_answer)
        except Exception as e:
            log.error(f"Failed to save chat history after stream: {e}")

        yield "event: done\ndata: [DONE]\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/documents")
async def list_docs(owner: str = Depends(require_api_key)):
    try:
        async with db_cursor() as cur:
            await cur.execute(
                "SELECT id, filename, total_chunks, created_at FROM documents WHERE owner=%s ORDER BY created_at DESC",
                (owner,),
            )
            rows = await cur.fetchall()
    except Exception as e:
        log.error(f"/documents failed: {e}")
        raise HTTPException(status_code=500, detail="Could not list documents.")

    return [{"id": r[0], "filename": r[1], "chunks": r[2], "created_at": str(r[3])} for r in rows]


@app.delete("/documents/{doc_id}")
async def delete_doc(doc_id: int, owner: str = Depends(require_api_key)):
    try:
        async with db_cursor(commit=True) as cur:
            await cur.execute("SELECT id FROM documents WHERE id=%s AND owner=%s", (doc_id, owner))
            if await cur.fetchone() is None:
                raise HTTPException(status_code=404, detail=f"Document {doc_id} not found.")
            await cur.execute("DELETE FROM documents WHERE id=%s AND owner=%s", (doc_id, owner))
    except HTTPException:
        raise
    except Exception as e:
        log.error(f"delete_doc failed: {e}")
        raise HTTPException(status_code=500, detail="Could not delete document.")

    return {"deleted": doc_id}


@app.post("/documents/upload")
@limiter.limit(RATE_LIMIT_UPLOAD)
async def upload_doc(request: Request, file: UploadFile = File(...), owner: str = Depends(require_api_key)):
    suffix = pathlib.Path(file.filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Supported types: {', '.join(SUPPORTED_EXTENSIONS)}")

    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > MAX_UPLOAD_MB:
        raise HTTPException(status_code=413, detail=f"File exceeds {MAX_UPLOAD_MB}MB limit.")

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(contents)
        tmp_path = pathlib.Path(tmp.name)

    try:
        doc_id = await ingest_single_file(tmp_path, owner=owner)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        log.error(f"Upload ingest failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to ingest uploaded file.")
    finally:
        tmp_path.unlink(missing_ok=True)

    return {"document_id": doc_id, "filename": file.filename, "status": "ingested"}


@app.post("/documents/{doc_id}/reindex")
async def reindex_doc(doc_id: int, owner: str = Depends(require_api_key)):
    async with db_cursor() as cur:
        await cur.execute("SELECT filename FROM documents WHERE id=%s AND owner=%s", (doc_id, owner))
        row = await cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Document {doc_id} not found.")

    original_path = pathlib.Path(row[0])
    if not original_path.exists():
        raise HTTPException(
            status_code=409,
            detail=f"Original file '{original_path}' is no longer on disk - cannot reindex. Delete and re-upload instead.",
        )

    try:
        await ingest_single_file(original_path, owner=owner, existing_doc_id=doc_id)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        log.error(f"Reindex failed for doc {doc_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to reindex document.")

    return {"document_id": doc_id, "status": "reindexed"}


@app.get("/usage")
async def usage_summary(owner: str = Depends(require_api_key)):
    try:
        async with db_cursor() as cur:
            await cur.execute(
                '''SELECT COALESCE(SUM(prompt_tokens),0), COALESCE(SUM(completion_tokens),0),
                          COALESCE(SUM(cost_usd),0), COUNT(*)
                   FROM usage_log WHERE owner=%s''',
                (owner,),
            )
            row = await cur.fetchone()
    except Exception as e:
        log.error(f"/usage failed: {e}")
        raise HTTPException(status_code=500, detail="Could not fetch usage.")

    return {
        "owner": owner,
        "total_prompt_tokens": row[0],
        "total_completion_tokens": row[1],
        "total_cost_usd": float(row[2]),
        "total_chat_calls": row[3],
    }
