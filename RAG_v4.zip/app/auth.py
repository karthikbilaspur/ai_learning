"""API-key auth dependency, now resolving to a tenant name for multi-tenancy.

Set API_KEYS (preferred, multi-tenant) or the legacy single API_KEY in the
environment. Every authenticated request gets `request.state.tenant` set,
which all document/chat/usage queries are scoped by.
"""
from fastapi import Header, HTTPException, Request, status
from .config import API_KEYS, AUTH_ENABLED


def require_api_key(request: Request, x_api_key: str = Header(default=None)) -> str:
    if not AUTH_ENABLED:
        # No keys configured - single implicit tenant, useful for local dev.
        request.state.tenant = "default"
        return request.state.tenant

    tenant = API_KEYS.get(x_api_key)
    if tenant is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key. Send it in the X-API-Key header.",
        )
    request.state.tenant = tenant
    return tenant
