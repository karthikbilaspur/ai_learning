"""Unit tests for file loading logic in ingest.py (no DB/model needed)."""
import pathlib
import tempfile
from app.ingest import load_file, splitter, SUPPORTED_EXTENSIONS


def test_load_txt_file():
    with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False) as f:
        f.write("Hello world. This is a test document.")
        path = pathlib.Path(f.name)
    try:
        pages = load_file(path)
        assert len(pages) == 1
        text, meta = pages[0]
        assert "Hello world" in text
        assert meta == {}
    finally:
        path.unlink()


def test_load_csv_file_produces_row_per_chunk():
    with tempfile.NamedTemporaryFile(suffix=".csv", mode="w", delete=False, newline="") as f:
        f.write("name,age\nAlice,30\nBob,25\n")
        path = pathlib.Path(f.name)
    try:
        pages = load_file(path)
        assert len(pages) == 2
        text0, meta0 = pages[0]
        assert "name: Alice" in text0
        assert "age: 30" in text0
        assert meta0 == {"row": 1}
    finally:
        path.unlink()


def test_load_unsupported_extension_returns_empty():
    with tempfile.NamedTemporaryFile(suffix=".xyz", delete=False) as f:
        path = pathlib.Path(f.name)
    try:
        assert load_file(path) == []
    finally:
        path.unlink()


def test_supported_extensions_includes_new_v4_types():
    for ext in [".docx", ".html", ".htm", ".csv"]:
        assert ext in SUPPORTED_EXTENSIONS


def test_splitter_chunks_long_text():
    long_text = "word " * 1000
    chunks = splitter.split_text(long_text)
    assert len(chunks) > 1
    assert all(len(c) <= 900 for c in chunks)
