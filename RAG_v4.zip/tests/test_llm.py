"""Unit tests for prompt building and mock-mode answer generation.
These don't need a live DB or an OpenAI key."""
import os
os.environ.setdefault("OPENAI_API_KEY", "")  # force mock mode

import pytest
from app.llm import build_prompt, generate_answer, rewrite_query, estimate_cost


def _sample_chunks():
    return [
        {"id": 1, "content": "The sky is blue.", "metadata": {"filename": "sky.txt", "page": 1}},
        {"id": 2, "content": "Water boils at 100C.", "metadata": {"filename": "physics.txt"}},
    ]


def test_build_prompt_includes_question_and_context():
    prompt = build_prompt(_sample_chunks(), "Why is the sky blue?")
    assert "Why is the sky blue?" in prompt
    assert "The sky is blue." in prompt
    assert "sky.txt" in prompt


def test_build_prompt_includes_recent_history_only():
    history = [{"role": "user", "content": f"msg{i}"} for i in range(10)]
    prompt = build_prompt(_sample_chunks(), "question", chat_history=history)
    assert "msg9" in prompt
    assert "msg0" not in prompt


@pytest.mark.asyncio
async def test_generate_answer_mock_mode_when_no_api_key():
    answer, usage = await generate_answer(_sample_chunks(), "What color is the sky?")
    assert "Mock LLM" in answer
    assert usage["prompt_tokens"] == 0
    assert usage["cost_usd"] == 0.0


@pytest.mark.asyncio
async def test_rewrite_query_returns_empty_without_client():
    # no OPENAI_API_KEY -> client is None -> rewrite_query short-circuits
    variants = await rewrite_query("What is the refund policy?")
    assert variants == []


def test_estimate_cost_zero_tokens():
    assert estimate_cost(0, 0) == 0.0


def test_estimate_cost_scales_with_tokens():
    cost_small = estimate_cost(100, 50)
    cost_large = estimate_cost(1000, 500)
    assert cost_large > cost_small
