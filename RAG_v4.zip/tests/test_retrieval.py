"""Unit tests for the RRF fusion helper in retrieval.py (pure function, no DB)."""
from app.retrieval import _reciprocal_rank_fusion


def test_rrf_fuses_and_ranks_by_combined_score():
    list_a = [{"id": 1, "content": "a"}, {"id": 2, "content": "b"}]
    list_b = [{"id": 2, "content": "b"}, {"id": 3, "content": "c"}]
    fused = _reciprocal_rank_fusion([list_a, list_b])
    # id 2 appears in both lists (rank 1 in a, rank 0 in b) so should score highest
    assert fused[2]["fusion_score"] == max(f["fusion_score"] for f in fused.values())
    assert set(fused.keys()) == {1, 2, 3}


def test_rrf_empty_lists_returns_empty():
    assert _reciprocal_rank_fusion([]) == {}
    assert _reciprocal_rank_fusion([[], []]) == {}
