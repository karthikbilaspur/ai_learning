"""Unit tests for multi-tenant API key resolution (v4)."""
import importlib
import os


def _reload_config_and_auth(monkeypatch, api_keys_env):
    monkeypatch.setenv("API_KEYS", api_keys_env)
    monkeypatch.delenv("API_KEY", raising=False)
    import app.config as config
    importlib.reload(config)
    import app.auth as auth
    importlib.reload(auth)
    return auth


def test_api_keys_parsed_into_tenant_map(monkeypatch):
    auth = _reload_config_and_auth(monkeypatch, "key1:alice,key2:bob")
    from app.config import API_KEYS, AUTH_ENABLED
    assert API_KEYS == {"key1": "alice", "key2": "bob"}
    assert AUTH_ENABLED is True


def test_no_keys_means_auth_disabled(monkeypatch):
    auth = _reload_config_and_auth(monkeypatch, "")
    from app.config import AUTH_ENABLED
    assert AUTH_ENABLED is False
