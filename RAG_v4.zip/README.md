# Chat with my Documents - PostgreSQL + pgvector RAG (v4)

Full RAG pipeline in Postgres: ingestion, chunking, embeddings, vector storage, hybrid retrieval, reranking, LLM generation — with an async FastAPI backend and Streamlit chat UI.

### v1 → v3 recap
- Hybrid search (vector + full-text), cross-encoder reranking, chat history, HNSW index
- API key auth, locked-down CORS, SSE streaming, full Dockerization, structured error handling/logging
- File upload endpoint, per-file re-index, connection pooling, rate limiting, input validation, pytest + CI

### v4 additions
- **Async DB driver** — migrated from `psycopg2` to `psycopg3` with `AsyncConnectionPool`. Every endpoint, retrieval call, and ingestion path is now `async def`, so DB I/O no longer blocks the FastAPI event loop under concurrent requests. CPU-bound work (embedding, PDF/DOCX/HTML parsing, reranking) runs in a thread via `asyncio.to_thread` so it doesn't block either.
- **Multi-tenancy** — `API_KEYS=key1:alice,key2:bob` maps each key to a tenant. Documents, chat history, and usage are all scoped by tenant (`owner` column + query filters); one tenant can never see or touch another's data. Legacy single `API_KEY` still works as a "default" tenant.
- **Query rewriting** — before retrieval, the LLM generates a couple of paraphrased variants of the question (`QUERY_REWRITE_ENABLED`, `QUERY_REWRITE_COUNT`). All variants are searched concurrently (vector + full-text each) and fused with **Reciprocal Rank Fusion (RRF)** before the cross-encoder reranks the merged candidates — this widens recall for oddly-phrased questions without hurting precision.
- **More file types** — `.docx` (python-docx) and `.html`/`.htm` (BeautifulSoup) ingestion added, plus `.csv` (each row becomes a "col: val, col: val" chunk). `SUPPORTED_EXTENSIONS` in `app/ingest.py` is now `[.pdf, .md, .txt, .docx, .html, .htm, .csv]`.
- **Usage / cost tracking** — every `/chat` and `/chat/stream` call logs prompt/completion tokens and an estimated USD cost (`PRICE_PER_1K_PROMPT`/`PRICE_PER_1K_COMPLETION`) to a `usage_log` table. `GET /usage` returns per-tenant totals; shown live in the Streamlit sidebar.
- **Lightweight eval harness** — `eval/evaluate.py` runs a small QA test set (`eval/qa_testset.json`) through `hybrid_search` and reports Hit Rate@k and MRR. No RAGAS dependency — just a fast, offline sanity check to run after changing chunking/embeddings/reranking.

### Quickstart (Docker, recommended)
1. `cp .env.example .env`, set `OPENAI_API_KEY` (or leave empty for mock mode) and real `API_KEYS` (e.g. `key1:alice`)
2. `docker-compose up -d --build`
3. Open `http://localhost:8501` (set `API_KEY=key1` in your shell before running Streamlit locally, or in the container env) and upload a document, or:
   `docker-compose exec api python -m app.ingest --folder docs --owner alice`

### Quickstart (local, no Docker for app)
1. `docker-compose up -d db`
2. `pip install -r requirements.txt`
3. `cp .env.example .env` and configure it
4. `uvicorn app.main:app --reload --port 8000`
5. In another terminal: `API_KEY=key1 streamlit run streamlit_app.py`

### Running tests
```
pip install -r requirements.txt
pytest tests/ -v
```
All tests are DB-free (prompt logic, mock-mode LLM, RRF fusion math, file loaders, tenant key parsing, pydantic validation) so they run in CI without a live Postgres instance.

### Running the eval harness
Requires a running DB with documents already ingested for the tenant you're testing:
```
python -m eval.evaluate --testset eval/qa_testset.json --owner alice --k 8
```
Edit `eval/qa_testset.json` to match your own documents (`expected_filename_contains` should be a substring of a filename you know is relevant to that question).

### Endpoints
| Endpoint | Method | Notes |
|---|---|---|
| `/chat` | POST | now returns `usage` (tokens + cost) alongside the answer |
| `/chat/stream` | POST | SSE token streaming |
| `/documents/upload` | POST | multipart upload; pdf/md/txt/docx/html/csv |
| `/documents/{id}/reindex` | POST | re-ingests the same file path in place |
| `/documents` / `DELETE /documents/{id}` | GET/DELETE | scoped to the caller's tenant |
| `/usage` | GET | per-tenant token/cost totals |

### Auth & multi-tenancy
Every call needs `X-API-Key: <your key>`. The tenant is resolved from `API_KEYS` in `.env` — each tenant's documents, chat history, and usage are fully isolated from every other tenant's.

### Architecture
```
docs/ or upload (pdf/md/txt/docx/html/csv)
   -> app/ingest.py (async, chunk 800/150 overlap, all-MiniLM-L6-v2 embeddings)
   -> Postgres pgvector (async pooled connections, owner-scoped)
   -> query rewriting (LLM paraphrases) -> hybrid_search per variant (concurrent)
   -> Reciprocal Rank Fusion -> cross-encoder reranker
   -> LLM (streaming or non-streaming, usage/cost logged)
   -> FastAPI (async, auth + multi-tenant scoping + rate limiting + validation)
   -> Streamlit (upload, reindex, delete, live streaming, usage dashboard)
```

### Still open for v5
Semantic (embedding-based) chunking instead of fixed-size splits, a real per-tenant admin UI, JWT-based auth instead of static keys, OpenTelemetry tracing, horizontal scaling notes (multiple API replicas behind a shared pool), a proper eval set generator (auto-derive QA pairs from ingested docs).
