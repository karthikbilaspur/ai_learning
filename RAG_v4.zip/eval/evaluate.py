"""Lightweight retrieval evaluation harness (RAGAS-style but dependency-free).

Runs each question in a QA test set through hybrid_search and checks whether
a chunk from the expected file shows up in the top-k results. Reports:
  - Hit Rate@k: fraction of questions where the expected file appears at all
  - MRR: mean reciprocal rank of the first chunk from the expected file

This intentionally avoids pulling in the full RAGAS package (heavy deps,
needs its own LLM judge calls) - it's meant as a fast, offline sanity check
you can run after changing chunking, embeddings, or reranking, against
documents already ingested for a given tenant.

Usage:
    python -m eval.evaluate --testset eval/qa_testset.json --owner default --k 8
"""
import argparse
import asyncio
import json
import sys

sys.path.insert(0, ".")
from app.retrieval import hybrid_search  # noqa: E402
from app.db import close_pool  # noqa: E402


async def run_eval(testset_path: str, owner: str, k: int):
    with open(testset_path) as f:
        testset = json.load(f)

    hits = 0
    reciprocal_ranks = []
    rows = []

    for case in testset:
        question = case["question"]
        expected = case.get("expected_filename_contains", "").lower()

        results = await hybrid_search(question, owner=owner, final_k=k)
        rank = None
        for i, r in enumerate(results):
            filename = str(r["metadata"].get("filename", "")).lower()
            if expected and expected in filename:
                rank = i + 1
                break

        if rank is not None:
            hits += 1
            reciprocal_ranks.append(1.0 / rank)
        else:
            reciprocal_ranks.append(0.0)

        rows.append({"question": question, "expected": expected, "hit_rank": rank, "n_results": len(results)})

    n = len(testset)
    hit_rate = hits / n if n else 0.0
    mrr = sum(reciprocal_ranks) / n if n else 0.0

    print(f"\n{'Question':<45} {'Expected':<12} {'Hit rank':<10}")
    print("-" * 70)
    for row in rows:
        print(f"{row['question'][:44]:<45} {row['expected']:<12} {str(row['hit_rank']):<10}")

    print("\n--- Summary ---")
    print(f"Test cases: {n}")
    print(f"Hit Rate@{k}: {hit_rate:.2%}")
    print(f"MRR: {mrr:.3f}")

    await close_pool()
    return {"hit_rate": hit_rate, "mrr": mrr, "n": n}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--testset", default="eval/qa_testset.json")
    parser.add_argument("--owner", default="default", help="Tenant whose documents to search")
    parser.add_argument("--k", type=int, default=8)
    args = parser.parse_args()
    asyncio.run(run_eval(args.testset, args.owner, args.k))
