# NOTE: These are cheap heuristic proxies for faithfulness/relevancy, not real
# semantic scoring. They exist so the eval suite runs fast and offline without
# an extra LLM call per question. For a real production gate, replace
# faithfulness_heuristic/answer_relevancy_heuristic with an LLM-as-judge call
# (e.g. ask a model "is this answer supported by this context? yes/no + why")
# and treat the numbers below as a smoke test, not a quality guarantee.
from typing import List

def keyword_recall(answer: str, expected_keywords: List[str]):
    answer_l = answer.lower()
    hits = sum(1 for kw in expected_keywords if kw.lower() in answer_l)
    return hits / max(len(expected_keywords),1)

def faithfulness_heuristic(answer: str, citations: List[dict]):
    # Heuristic only: checks that citations exist and that the answer shares
    # meaningful vocabulary with the cited chunk text (a very rough proxy for
    # "not hallucinated"). This does NOT verify factual claims or numbers -
    # swap in an LLM-as-judge for real faithfulness scoring.
    if not citations or len(answer.strip()) <= 20:
        return 0.0
    answer_words = set(w.lower() for w in answer.split() if len(w) > 3)
    context_words = set()
    for c in citations:
        context_words.update(w.lower() for w in c.get("text", "").split() if len(w) > 3)
    if not answer_words:
        return 0.0
    overlap = len(answer_words & context_words) / len(answer_words)
    return round(overlap, 3)

def answer_relevancy_heuristic(answer: str, question: str):
    # Heuristic only: lexical overlap between question and answer. Doesn't
    # capture paraphrase or semantic relevance - swap in embedding similarity
    # or LLM-as-judge for real relevancy scoring.
    q_words = set(question.lower().split())
    a_words = set(answer.lower().split())
    return len(q_words & a_words) / max(len(q_words),1)

# Backwards-compatible aliases (old names, kept so external callers don't break)
faithfulness = faithfulness_heuristic
answer_relevancy = answer_relevancy_heuristic
