from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # LLM
    llm_provider: str = "openai"  # openai, groq, mock
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"

    # Retrieval
    top_k: int = 5
    hybrid_alpha: float = 0.6  # 0.6 dense, 0.4 bm25
    reranker_enabled: bool = True

    # Cost
    cost_per_1k_prompt: float = 0.00015
    cost_per_1k_completion: float = 0.0006
    monthly_budget_usd: float = 50.0

    # Observability
    langfuse_enabled: bool = False

settings = Settings()
