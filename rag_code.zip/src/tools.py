import ast, operator, time, json, math
from typing import Dict, Any
from pydantic import BaseModel, Field

class CalculatorInput(BaseModel):
    expression: str = Field(..., description="Valid math expression, e.g. 2 * (3 + 4) / 5")

TOOLS_SCHEMA = {
    "calculator": {
        "name": "calculator",
        "description": "Use for math calculations",
        "parameters": CalculatorInput.model_json_schema()
    }
}

# --- Safe expression evaluator -------------------------------------------
# We never use eval()/exec() on user-controlled input. Instead we parse the
# expression into a Python AST and walk it ourselves, allowing only a small
# whitelist of numeric literals, operators, and math-module function calls.
# Any other node type (names, attribute access, subscripts, comprehensions,
# calls to anything but the whitelisted functions, etc.) raises immediately.

_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.FloorDiv: operator.floordiv,
}
_ALLOWED_UNARYOPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}
_ALLOWED_FUNCS = {
    name: getattr(math, name)
    for name in ("sqrt", "sin", "cos", "tan", "log", "log10", "exp", "floor", "ceil", "fabs")
}
_MAX_EXPR_LEN = 200
_MAX_POWER_EXPONENT = 1000  # guard against pathological exponents like 9**9**9

class UnsafeExpressionError(ValueError):
    pass

def _eval_node(node):
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise UnsafeExpressionError(f"Unsupported constant: {node.value!r}")
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        if isinstance(node.op, ast.Pow) and (abs(right) > _MAX_POWER_EXPONENT):
            raise UnsafeExpressionError("Exponent too large")
        return _ALLOWED_BINOPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARYOPS:
        return _ALLOWED_UNARYOPS[type(node.op)](_eval_node(node.operand))
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.func.id not in _ALLOWED_FUNCS:
            raise UnsafeExpressionError("Only whitelisted math functions are allowed")
        if node.keywords:
            raise UnsafeExpressionError("Keyword arguments are not allowed")
        args = [_eval_node(a) for a in node.args]
        return _ALLOWED_FUNCS[node.func.id](*args)
    raise UnsafeExpressionError(f"Unsupported expression element: {type(node).__name__}")

def safe_eval_math(expr: str):
    """Safely evaluate a numeric expression without eval()/exec()."""
    if not expr or len(expr) > _MAX_EXPR_LEN:
        raise UnsafeExpressionError("Expression missing or too long")
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise UnsafeExpressionError(f"Invalid expression syntax: {e}")
    return _eval_node(tree)

class ToolRouter:
    def __init__(self, timeout=3.0, max_retries=2):
        self.timeout = timeout
        self.max_retries = max_retries
    
    def validate(self, tool_name, args: Dict):
        if tool_name not in TOOLS_SCHEMA:
            raise ValueError(f"Unknown tool {tool_name}")
        if tool_name == "calculator":
            CalculatorInput(**args)  # validation
        return True
    
    def execute(self, tool_name, args: Dict) -> Dict[str, Any]:
        self.validate(tool_name, args)
        last_err = None
        for attempt in range(self.max_retries+1):
            try:
                start = time.time()
                if tool_name == "calculator":
                    expr = args["expression"]
                    result = safe_eval_math(expr)
                    latency = (time.time()-start)*1000
                    return {"tool": tool_name, "result": result, "latency_ms": latency, "attempt": attempt}
            except UnsafeExpressionError as e:
                # Not retryable - the expression itself is invalid/unsafe, retrying won't help
                return {"tool": tool_name, "error": str(e), "latency_ms": 0, "attempt": attempt}
            except (ZeroDivisionError, OverflowError, ValueError) as e:
                last_err = str(e)
                time.sleep(0.2 * (attempt+1))
        return {"tool": tool_name, "error": last_err, "latency_ms": 0, "attempt": self.max_retries}

router = ToolRouter()
