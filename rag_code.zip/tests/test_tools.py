from src.tools import router

def test_tool_validation():
    router.validate("calculator", {"expression": "2+2"})
    try:
        router.validate("calculator", {"wrong": "field"})
        assert False, "should have raised"
    except:
        pass
    print("tool validation passed")

def test_tool_execution():
    res = router.execute("calculator", {"expression": "2*(3+4)"})
    assert res["result"] == 14
    print("tool execution passed")

def test_tool_execution_rejects_unsafe_expression():
    # Names, attribute access, imports, etc. must never be evaluated.
    res = router.execute("calculator", {"expression": "__import__('os').system('echo hi')"})
    assert "error" in res
    print("unsafe expression rejection passed")

def test_tool_execution_rejects_non_math():
    res = router.execute("calculator", {"expression": "os.getcwd()"})
    assert "error" in res
    print("non-math rejection passed")

if __name__ == "__main__":
    test_tool_validation()
    test_tool_execution()
    test_tool_execution_rejects_unsafe_expression()
    test_tool_execution_rejects_non_math()
