CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('planning','active','in_progress','done','archived')),
  owner TEXT NOT NULL,
  stack JSONB NOT NULL DEFAULT '[]'::jsonb,
  deadline DATE,
  budget_usd INTEGER NOT NULL DEFAULT 0 CHECK (budget_usd >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects(owner);
CREATE INDEX IF NOT EXISTS idx_projects_deadline ON projects(deadline);

INSERT INTO projects (id,name,status,owner,stack,deadline,budget_usd) VALUES
('p1','Website Redesign','active','Kai','["Next.js","Tailwind"]','2026-09-15',8000),
('p2','MCP Demo Server','in_progress','Kai','["Python","MCP"]','2026-08-20',0),
('p3','Analytics Pipeline','planning','Priya','["Python","BigQuery"]','2026-10-01',15000),
('p4','Mobile App v2','active','Arjun','["React Native","Firebase"]','2026-11-30',25000),
('p5','AI Chatbot','in_progress','Kai','["Python","LangChain","OpenAI"]','2026-09-01',12000),
('p6','E-commerce Backend','planning','Sara','["Node.js","Postgres","Redis"]','2026-12-15',30000),
('p7','Data Migration','done','Priya','["Python","Airflow"]','2026-07-01',5000),
('p8','Marketing Website SEO','active','Rahul','["Next.js","Contentful"]','2026-08-30',7000),
('p9','Payment Integration','in_progress','Sara','["Stripe","Node.js"]','2026-08-25',10000),
('p10','Internal HR Tool','planning','Arjun','["Retool","Postgres"]','2026-10-20',9000),
('p11','Customer Support Bot','archived','Kai','["Python","Rasa"]','2026-05-15',4000),
('p12','Cloud Infra Migration','active','Priya','["AWS","Terraform","Docker"]','2026-11-01',45000)
ON CONFLICT (id) DO NOTHING;
