"""Production-oriented MCP project server.

Architecture:
    Model -> MCP Client -> MCP Server -> Database

The server supports PostgreSQL with a JSON-file fallback for local demos.
Secrets are never exposed as MCP tool arguments. When MCP_API_KEY is set,
callers must also provide the matching MCP_CLIENT_API_KEY in the server
process environment. For stdio deployments, the MCP client launcher should
set that environment variable for the server process.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import pathlib
import tempfile
import uuid
from contextlib import contextmanager
from typing import Any, Iterator, Literal, Optional

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field, field_validator

load_dotenv()

BASE_DIR = pathlib.Path(__file__).resolve().parent
DB_PATH = pathlib.Path(os.getenv("JSON_DB_PATH", BASE_DIR / "project_db.json"))
LOG_PATH = pathlib.Path(os.getenv("ACTIVITY_LOG_PATH", BASE_DIR / "activity.log"))

Status = Literal["planning", "active", "in_progress", "done", "archived"]
VALID_STATUSES = {"planning", "active", "in_progress", "done", "archived"}


def _json_default(value: Any) -> Any:
    if isinstance(value, (dt.datetime, dt.date)):
        return value.isoformat()
    return str(value)


def _dump(value: Any) -> str:
    return json.dumps(value, indent=2, default=_json_default)


def check_auth() -> None:
    """Enforce optional server-side API-key protection.

    Tool arguments intentionally do not contain secrets. If MCP_API_KEY is
    configured, the server expects MCP_CLIENT_API_KEY in its environment.
    """
    expected = os.getenv("MCP_API_KEY")
    if not expected:
        return

    provided = os.getenv("MCP_CLIENT_API_KEY")
    if not provided or provided != expected:
        raise PermissionError("Unauthorized: invalid or missing MCP client credential")


class CreateProjectInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=2, max_length=100)
    owner: str = Field(..., min_length=2, max_length=100)
    status: Status = "planning"
    stack: str = Field("", max_length=500)
    budget_usd: int = Field(0, ge=0, le=1_000_000)
    deadline: Optional[dt.date] = None

    @field_validator("name", "owner")
    @classmethod
    def strip_required_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("must not be blank")
        return value

    @field_validator("deadline", mode="before")
    @classmethod
    def normalize_deadline(cls, value: Any) -> Any:
        if value in (None, ""):
            return None
        if isinstance(value, dt.date):
            return value
        if isinstance(value, str):
            try:
                return dt.date.fromisoformat(value.strip())
            except ValueError as exc:
                raise ValueError("deadline must use YYYY-MM-DD") from exc
        raise ValueError("deadline must use YYYY-MM-DD")


class ListProjectsInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: Optional[Status] = None
    owner: Optional[str] = Field(None, max_length=100)
    limit: int = Field(20, ge=1, le=100)
    offset: int = Field(0, ge=0)

    @field_validator("owner")
    @classmethod
    def normalize_owner(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        value = value.strip()
        return value or None


class SearchProjectsInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    query: str = Field(..., min_length=1, max_length=200)
    limit: int = Field(20, ge=1, le=100)

    @field_validator("query")
    @classmethod
    def strip_query(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("query must not be blank")
        return value


class UpdateStatusInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    project_id: str = Field(..., min_length=1, max_length=100)
    new_status: Status


class DB:
    """Small repository abstraction with PostgreSQL and JSON implementations."""

    def __init__(self, force_json: Optional[bool] = None) -> None:
        self.conn_str = os.getenv("DATABASE_URL")
        self.use_postgres = False
        self.pg_pool = None

        requested_json = os.getenv("USE_JSON_FALLBACK", "false").lower() == "true"
        if force_json is None:
            force_json = requested_json

        if self.conn_str and not force_json:
            try:
                import psycopg2
                from psycopg2.pool import ThreadedConnectionPool

                self.psycopg2 = psycopg2
                pool_min = int(os.getenv("PG_POOL_MIN", "1"))
                pool_max = int(os.getenv("PG_POOL_MAX", "5"))
                self.pg_pool = ThreadedConnectionPool(pool_min, pool_max, self.conn_str)
                self.use_postgres = True
                self._ensure_table()
                print("[DB] Using PostgreSQL")
            except Exception as exc:
                print(f"[DB] PostgreSQL unavailable ({exc}); using JSON fallback")
                self._close_pool()

        if not self.use_postgres:
            print(f"[DB] Using JSON fallback: {DB_PATH}")
            self._ensure_json_file()

    def _close_pool(self) -> None:
        if self.pg_pool is not None:
            try:
                self.pg_pool.closeall()
            finally:
                self.pg_pool = None

    @contextmanager
    def pg_conn(self) -> Iterator[Any]:
        if not self.pg_pool:
            raise RuntimeError("PostgreSQL pool is not available")
        conn = self.pg_pool.getconn()
        try:
            yield conn
        except Exception:
            conn.rollback()
            raise
        finally:
            self.pg_pool.putconn(conn)

    def _ensure_table(self) -> None:
        sql = """
        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('planning','active','in_progress','done','archived')),
            owner TEXT NOT NULL,
            stack JSONB NOT NULL DEFAULT '[]'::jsonb,
            deadline DATE,
            budget_usd INTEGER NOT NULL DEFAULT 0 CHECK (budget_usd >= 0),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
        CREATE INDEX IF NOT EXISTS idx_projects_owner ON projects(owner);
        CREATE INDEX IF NOT EXISTS idx_projects_deadline ON projects(deadline);
        """
        with self.pg_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                cur.execute("SELECT COUNT(*) FROM projects")
                if cur.fetchone()[0] == 0:
                    for project in self._load_json().get("projects", []):
                        cur.execute(
                            """
                            INSERT INTO projects
                                (id, name, status, owner, stack, deadline, budget_usd,
                                 created_at, updated_at)
                            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                            ON CONFLICT (id) DO NOTHING
                            """,
                            (
                                project["id"],
                                project["name"],
                                project["status"],
                                project["owner"],
                                json.dumps(project.get("stack", [])),
                                project.get("deadline") or None,
                                project.get("budget_usd", 0),
                                project.get("created_at") or dt.datetime.now(dt.timezone.utc),
                                project.get("updated_at") or dt.datetime.now(dt.timezone.utc),
                            ),
                        )
                conn.commit()

    def _ensure_json_file(self) -> None:
        if not DB_PATH.exists():
            DB_PATH.parent.mkdir(parents=True, exist_ok=True)
            DB_PATH.write_text(json.dumps({"projects": []}, indent=2), encoding="utf-8")

    def _load_json(self) -> dict[str, Any]:
        self._ensure_json_file()
        with DB_PATH.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def _save_json(self, data: dict[str, Any]) -> None:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix="projects-", suffix=".json", dir=DB_PATH.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2)
                handle.write("\n")
            os.replace(temp_name, DB_PATH)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
        with LOG_PATH.open("a", encoding="utf-8") as log:
            log.write(f"{dt.datetime.now(dt.timezone.utc).isoformat()} projects={len(data['projects'])}\n")

    @staticmethod
    def _sort_json(projects: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return sorted(projects, key=lambda p: p.get("updated_at", ""), reverse=True)

    @staticmethod
    def _new_id(existing: set[str]) -> str:
        while True:
            candidate = f"p-{uuid.uuid4().hex[:10]}"
            if candidate not in existing:
                return candidate

    def list(self, status: Optional[str] = None, owner: Optional[str] = None,
             limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    query = """
                        SELECT id,name,status,owner,stack,deadline,budget_usd,created_at,updated_at
                        FROM projects WHERE TRUE
                    """
                    params: list[Any] = []
                    if status:
                        query += " AND status=%s"
                        params.append(status)
                    if owner:
                        query += " AND owner ILIKE %s"
                        params.append(f"%{owner}%")
                    query += " ORDER BY updated_at DESC, id ASC LIMIT %s OFFSET %s"
                    params.extend([limit, offset])
                    cur.execute(query, params)
                    columns = [desc[0] for desc in cur.description]
                    return [dict(zip(columns, row)) for row in cur.fetchall()]

        projects = self._sort_json(self._load_json().get("projects", []))
        if status:
            projects = [p for p in projects if p.get("status") == status]
        if owner:
            owner_lower = owner.lower()
            projects = [p for p in projects if owner_lower in p.get("owner", "").lower()]
        return projects[offset: offset + limit]

    def get(self, project_id: str) -> Optional[dict[str, Any]]:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT id,name,status,owner,stack,deadline,budget_usd,created_at,updated_at "
                        "FROM projects WHERE id=%s",
                        (project_id,),
                    )
                    row = cur.fetchone()
                    if not row:
                        return None
                    columns = [desc[0] for desc in cur.description]
                    return dict(zip(columns, row))

        return next((p for p in self._load_json().get("projects", []) if p.get("id") == project_id), None)

    def search(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    pattern = f"%{query}%"
                    cur.execute(
                        """
                        SELECT id,name,status,owner,stack,deadline,budget_usd,created_at,updated_at
                        FROM projects
                        WHERE name ILIKE %s OR owner ILIKE %s OR stack::text ILIKE %s
                        ORDER BY updated_at DESC, id ASC
                        LIMIT %s
                        """,
                        (pattern, pattern, pattern, limit),
                    )
                    columns = [desc[0] for desc in cur.description]
                    return [dict(zip(columns, row)) for row in cur.fetchall()]

        query_lower = query.lower()
        projects = self._sort_json(self._load_json().get("projects", []))
        return [
            project for project in projects
            if query_lower in json.dumps(project, default=_json_default).lower()
        ][:limit]

    def create(self, project: dict[str, Any]) -> dict[str, Any]:
        if self.use_postgres:
            project_id = self._new_id(set())
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        INSERT INTO projects
                            (id,name,status,owner,stack,deadline,budget_usd)
                        VALUES (%s,%s,%s,%s,%s,%s,%s)
                        RETURNING id,name,status,owner,stack,deadline,budget_usd,created_at,updated_at
                        """,
                        (
                            project_id,
                            project["name"],
                            project["status"],
                            project["owner"],
                            json.dumps(project.get("stack", [])),
                            project.get("deadline"),
                            project.get("budget_usd", 0),
                        ),
                    )
                    row = cur.fetchone()
                    conn.commit()
                    columns = [desc[0] for desc in cur.description]
                    return dict(zip(columns, row))

        data = self._load_json()
        now = dt.datetime.now(dt.timezone.utc).isoformat()
        project = dict(project)
        project["id"] = self._new_id({p["id"] for p in data.get("projects", [])})
        project["created_at"] = now
        project["updated_at"] = now
        data.setdefault("projects", []).append(project)
        self._save_json(data)
        return project

    def update_status(self, project_id: str, new_status: str) -> Optional[dict[str, Any]]:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE projects SET status=%s, updated_at=NOW()
                        WHERE id=%s
                        RETURNING id,name,status,owner,stack,deadline,budget_usd,created_at,updated_at
                        """,
                        (new_status, project_id),
                    )
                    row = cur.fetchone()
                    if not row:
                        conn.rollback()
                        return None
                    columns = [desc[0] for desc in cur.description]
                    result = dict(zip(columns, row))
                    conn.commit()
                    return result

        data = self._load_json()
        for project in data.get("projects", []):
            if project.get("id") == project_id:
                project["status"] = new_status
                project["updated_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
                self._save_json(data)
                return project
        return None

    def delete(self, project_id: str) -> bool:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute("DELETE FROM projects WHERE id=%s", (project_id,))
                    deleted = cur.rowcount > 0
                    conn.commit()
                    return deleted

        data = self._load_json()
        before = len(data.get("projects", []))
        data["projects"] = [p for p in data.get("projects", []) if p.get("id") != project_id]
        if len(data["projects"]) == before:
            return False
        self._save_json(data)
        return True

    def analytics(self) -> dict[str, Any]:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT status, COUNT(*) AS count, COALESCE(SUM(budget_usd),0) AS total_budget,
                               COALESCE(AVG(budget_usd),0) AS avg_budget
                        FROM projects GROUP BY status ORDER BY status
                        """
                    )
                    by_status = [
                        {"status": row[0], "count": row[1], "total_budget": row[2], "avg_budget": float(row[3])}
                        for row in cur.fetchall()
                    ]

                    cur.execute(
                        "SELECT COALESCE(SUM(budget_usd),0), COUNT(*), COALESCE(MAX(budget_usd),0) FROM projects"
                    )
                    total_budget, total_projects, max_budget = cur.fetchone()

                    cur.execute(
                        """
                        SELECT owner, COUNT(*) AS count, COALESCE(SUM(budget_usd),0) AS budget
                        FROM projects GROUP BY owner ORDER BY owner
                        """
                    )
                    by_owner = [
                        {"owner": row[0], "count": row[1], "budget": row[2]}
                        for row in cur.fetchall()
                    ]

                    cur.execute(
                        """
                        SELECT COUNT(*) FROM projects
                        WHERE deadline < CURRENT_DATE AND status NOT IN ('done','archived')
                        """
                    )
                    overdue_count = cur.fetchone()[0]

                    return {
                        "by_status": by_status,
                        "by_owner": by_owner,
                        "total_budget": total_budget,
                        "total_projects": total_projects,
                        "max_budget": max_budget,
                        "overdue_count": overdue_count,
                    }

        projects = self._load_json().get("projects", [])
        status_map: dict[str, dict[str, Any]] = {}
        owner_map: dict[str, dict[str, Any]] = {}
        total_budget = 0
        max_budget = 0
        today = dt.date.today()
        overdue_count = 0

        for project in projects:
            status = project["status"]
            budget = int(project.get("budget_usd", 0))
            status_item = status_map.setdefault(status, {"status": status, "count": 0, "total_budget": 0, "avg_budget": 0})
            status_item["count"] += 1
            status_item["total_budget"] += budget

            owner = project["owner"]
            owner_item = owner_map.setdefault(owner, {"owner": owner, "count": 0, "budget": 0})
            owner_item["count"] += 1
            owner_item["budget"] += budget

            total_budget += budget
            max_budget = max(max_budget, budget)

            deadline = project.get("deadline")
            if deadline and dt.date.fromisoformat(deadline) < today and project["status"] not in {"done", "archived"}:
                overdue_count += 1

        for item in status_map.values():
            item["avg_budget"] = item["total_budget"] / item["count"] if item["count"] else 0

        return {
            "by_status": sorted(status_map.values(), key=lambda item: item["status"]),
            "by_owner": sorted(owner_map.values(), key=lambda item: item["owner"]),
            "total_budget": total_budget,
            "total_projects": len(projects),
            "max_budget": max_budget,
            "overdue_count": overdue_count,
        }

    def overdue(self) -> list[dict[str, Any]]:
        if self.use_postgres:
            with self.pg_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT id,name,deadline,status,owner,budget_usd
                        FROM projects
                        WHERE deadline < CURRENT_DATE AND status NOT IN ('done','archived')
                        ORDER BY deadline ASC, id ASC
                        """
                    )
                    columns = [desc[0] for desc in cur.description]
                    return [dict(zip(columns, row)) for row in cur.fetchall()]

        today = dt.date.today()
        return [
            project for project in self._load_json().get("projects", [])
            if project.get("deadline")
            and dt.date.fromisoformat(project["deadline"]) < today
            and project.get("status") not in {"done", "archived"}
        ]


db = DB()
mcp = FastMCP("project-db-prod")


@mcp.resource("projects://all")
def res_all() -> str:
    return _dump(db.list(limit=100))


@mcp.resource("projects://stats")
def res_stats() -> str:
    return _dump(db.analytics())


@mcp.resource("projects://activity")
def res_activity() -> str:
    if not LOG_PATH.exists():
        return "No activity yet"
    return LOG_PATH.read_text(encoding="utf-8")[-3000:]


@mcp.resource("projects://{project_id}")
def res_one(project_id: str) -> str:
    project = db.get(project_id)
    return _dump(project or {"error": "not found"})


@mcp.tool()
def list_projects(status: Optional[str] = None, owner: Optional[str] = None,
                   limit: int = 20, offset: int = 0) -> str:
    """List projects with validated filtering and pagination."""
    check_auth()
    args = ListProjectsInput(status=status, owner=owner, limit=limit, offset=offset)
    return _dump(db.list(args.status, args.owner, args.limit, args.offset))


@mcp.tool()
def get_project(project_id: str) -> str:
    """Get one project by ID."""
    check_auth()
    if not project_id.strip():
        return _dump({"error": "project_id must not be blank"})
    project = db.get(project_id.strip())
    return _dump(project or {"error": "not found", "hint": "Use list_projects to see IDs"})


@mcp.tool()
def search_projects(query: str, limit: int = 20) -> str:
    """Search project name, owner, or technology stack."""
    check_auth()
    args = SearchProjectsInput(query=query, limit=limit)
    return _dump(db.search(args.query, args.limit))


@mcp.tool()
def create_project(name: str, owner: str, status: Status = "planning", stack: str = "",
                   budget_usd: int = 0, deadline: Optional[str] = None) -> str:
    """Create a validated project."""
    check_auth()
    args = CreateProjectInput(
        name=name,
        owner=owner,
        status=status,
        stack=stack,
        budget_usd=budget_usd,
        deadline=deadline,
    )
    project = {
        "name": args.name,
        "owner": args.owner,
        "status": args.status,
        "stack": [item.strip() for item in args.stack.split(",") if item.strip()],
        "budget_usd": args.budget_usd,
        "deadline": args.deadline.isoformat() if args.deadline else None,
    }
    return _dump({"created": db.create(project)})


@mcp.tool()
def update_project_status(project_id: str, new_status: Status) -> str:
    """Update a project's status and timestamp."""
    check_auth()
    args = UpdateStatusInput(project_id=project_id, new_status=new_status)
    updated = db.update_status(args.project_id, args.new_status)
    if not updated:
        return _dump({"error": "not found"})
    return _dump({"updated": updated})


@mcp.tool()
def delete_project(project_id: str) -> str:
    """Delete a project. Disabled unless MCP_API_KEY is configured."""
    check_auth()
    if not os.getenv("MCP_API_KEY"):
        return _dump({"error": "Delete requires MCP_API_KEY to be configured"})
    deleted = db.delete(project_id.strip())
    if not deleted:
        return _dump({"deleted": False, "error": "not found"})
    return _dump({"deleted": True, "project_id": project_id.strip()})


@mcp.tool()
def analytics_dashboard() -> str:
    """Return database-side project and budget analytics."""
    check_auth()
    return _dump(db.analytics())


@mcp.tool()
def budget_summary() -> str:
    """Return a compact budget summary."""
    check_auth()
    analytics = db.analytics()
    return _dump({
        "total_budget": analytics["total_budget"],
        "by_owner": analytics["by_owner"],
        "by_status": analytics["by_status"],
    })


@mcp.tool()
def overdue_projects() -> str:
    """List projects past deadline and not done or archived."""
    check_auth()
    return _dump(db.overdue())


@mcp.prompt()
def project_status_report() -> str:
    """Create a project-management report from current server data."""
    projects = db.list(limit=100)
    analytics = db.analytics()
    return f"""You are a project manager. Use the following server data.

Projects:
{_dump(projects)}

Analytics:
{_dump(analytics)}

Create:
1. A Markdown table: ID | Name | Status | Owner | Budget | Deadline
2. Three concrete risks, including overdue work, high-budget planning work, and owner workload
3. Budget insights based on the analytics
4. The next three recommended actions, with reasons
"""


@mcp.prompt()
def budget_review() -> str:
    """Create a finance-focused project budget review."""
    return f"""Review the following project budget analytics:

{_dump(db.analytics())}

Identify concentration risks, unusually large budgets, planning projects with significant budgets,
and practical opportunities for reallocation. Do not invent missing data.
"""


if __name__ == "__main__":
    mcp.run()
