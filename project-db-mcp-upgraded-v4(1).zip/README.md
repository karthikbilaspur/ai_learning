# MCP Project DB Server — Upgraded v4

A stronger version of the original v3 project, focused on correctness, consistency, and safer operations.

## What was fixed

- **Secrets removed from tool arguments.** Tools no longer accept `api_key`; authentication is server-side through environment variables.
- **Consistent Pydantic v2 validation.** Create, list, search, and status-update inputs are validated before database operations.
- **Real date validation.** `deadline` is parsed as `YYYY-MM-DD` instead of being treated as an arbitrary string.
- **Safe project IDs.** New projects use collision-resistant IDs instead of `count + 1`.
- **Postgres connection pooling.** A small `ThreadedConnectionPool` avoids opening a new database connection for every operation.
- **JSON/Postgres parity.** Both backends now return the same analytics fields and use the same ordering rules.
- **Consistent timestamps.** JSON projects now have `created_at` and `updated_at`, and status updates refresh `updated_at`.
- **Atomic JSON writes.** JSON updates are written to a temporary file and atomically replaced.
- **Correct delete behavior.** Deleting a missing project now reports `deleted: false` instead of claiming success.
- **Database indexes.** Status, owner, and deadline indexes are created for common queries.
- **Postgres readiness check.** Docker waits for `pg_isready` before starting the MCP service.
- **Regression tests.** `tests.py` covers IDs, pagination, updates, deletes, analytics, and validation.

## Authentication note

For stdio MCP deployments there is no HTTP request header to inspect inside a normal tool function. This version therefore keeps secrets out of the tool schema and uses environment variables:

```text
MCP_API_KEY=server-secret
MCP_CLIENT_API_KEY=server-secret
```

When `MCP_API_KEY` is not set, read-only and write tools work without authentication for local development. `delete_project` remains disabled unless `MCP_API_KEY` is configured.

For a network-exposed deployment, put the MCP server behind an authenticated transport/proxy and do not expose PostgreSQL directly to the internet.

## Quick JSON demo

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export USE_JSON_FALLBACK=true
python server.py
```

## Run the tests

```bash
python tests.py
```

## Run PostgreSQL with Docker

```bash
cp .env.example .env
docker compose up --build
```

The Compose setup includes a Postgres healthcheck so the MCP container does not race the database during startup.

## Useful MCP operations

Tools:

- `list_projects`
- `get_project`
- `search_projects`
- `create_project`
- `update_project_status`
- `delete_project`
- `analytics_dashboard`
- `budget_summary`
- `overdue_projects`

Resources:

- `projects://all`
- `projects://stats`
- `projects://activity`
- `projects://{project_id}`

Prompts:

- `project_status_report`
- `budget_review`

## Architecture

```text
Model
  ↓
MCP Client
  ↓
MCP Server
  ├── validation
  ├── optional authentication
  ├── tools
  ├── resources
  └── prompts
       ↓
   Repository layer
       ├── PostgreSQL + connection pool
       └── JSON fallback
```

The model never receives database credentials, and tool schemas do not expose API-key parameters.
