"""Lightweight regression tests for the JSON backend.

Run with:
    python tests.py
"""

import json
import os
import tempfile
import unittest
from pathlib import Path


class JsonBackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db_file = Path(cls.tmp.name) / "projects.json"
        cls.log_file = Path(cls.tmp.name) / "activity.log"
        os.environ["USE_JSON_FALLBACK"] = "true"
        os.environ["JSON_DB_PATH"] = str(cls.db_file)
        os.environ["ACTIVITY_LOG_PATH"] = str(cls.log_file)

        # Import after environment setup because server creates its DB globally.
        import server
        cls.server = server
        cls.db = server.DB(force_json=True)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_create_generates_unique_id_and_timestamps(self):
        first = self.db.create({
            "name": "Test One", "owner": "Alice", "status": "planning",
            "stack": ["Python"], "budget_usd": 1000, "deadline": "2026-12-01",
        })
        second = self.db.create({
            "name": "Test Two", "owner": "Alice", "status": "active",
            "stack": ["Postgres"], "budget_usd": 2000, "deadline": None,
        })
        self.assertNotEqual(first["id"], second["id"])
        self.assertIn("created_at", first)
        self.assertIn("updated_at", first)

    def test_list_is_sorted_and_paginated(self):
        projects = self.db.list(limit=1, offset=0)
        self.assertEqual(len(projects), 1)

    def test_update_missing_project_returns_none(self):
        self.assertIsNone(self.db.update_status("does-not-exist", "done"))

    def test_delete_reports_false_for_missing_project(self):
        self.assertFalse(self.db.delete("does-not-exist"))

    def test_analytics_has_consistent_shape(self):
        analytics = self.db.analytics()
        for key in ("by_status", "by_owner", "total_budget", "total_projects", "max_budget", "overdue_count"):
            self.assertIn(key, analytics)

    def test_validation_rejects_bad_deadline(self):
        with self.assertRaises(Exception):
            self.server.CreateProjectInput(name="Bad", owner="Alice", deadline="12/01/2026")


if __name__ == "__main__":
    unittest.main(verbosity=2)
