"""
agent.py — the agent loop (v2).

Upgrades over v1:
  - Retry-with-backoff around both the LLM call and each tool call, so a
    single transient failure (network blip, flaky tool) doesn't kill the run.
  - Malformed tool-call recovery: if a tool call keeps failing, the error is
    fed back as a tool_result instead of crashing, so the model gets a chance
    to self-correct on the next turn.
  - Structured logging to both console and a log file.
  - Full transcript persistence to JSON, so a run can be inspected, replayed,
    or resumed later instead of vanishing when the process exits.
  - Usage/cost tracking, when the backend reports token usage.
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from llm_client import LLMResponse, ToolCall
from tools import TOOL_IMPLS, TOOL_SCHEMAS

SYSTEM_PROMPT = """You are a focused research agent. You have four tools:
- document_retrieval: search internal/private analyst documents
- database_query: run read-only SQL against the research database
- web_search: search the public web
- calculator: evaluate arithmetic expressions

Rules:
1. Only call a tool when you actually need information or computation you
   don't already have. Don't call a tool "just in case."
2. Never do arithmetic yourself — always use the calculator tool for any
   computation, however simple.
3. Prefer internal documents and the database over the public web when the
   question is about the company's own data.
4. When you have enough evidence, stop calling tools and write a final answer
   that cites which source (document / database / web) each claim came from.
5. If a tool returns an error, don't repeat the exact same call — either fix
   the input or work around it.
"""

# ---------------------------------------------------------------------------
# Logging setup — console + file, so a run can be audited after the fact.
# ---------------------------------------------------------------------------
LOG_DIR = os.path.join(os.path.dirname(__file__), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

logger = logging.getLogger("research_agent")
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    fh = logging.FileHandler(os.path.join(LOG_DIR, "agent.log"))
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(fh)


# ---------------------------------------------------------------------------
# Retry helper — small, dependency-free exponential backoff.
# ---------------------------------------------------------------------------
def _retry(fn, *, attempts: int = 3, base_delay: float = 0.5, label: str = "call"):
    last_err = None
    for attempt in range(1, attempts + 1):
        try:
            return fn()
        except Exception as e:
            last_err = e
            logger.warning(f"{label} failed on attempt {attempt}/{attempts}: {e}")
            if attempt < attempts:
                time.sleep(base_delay * (2 ** (attempt - 1)))
    raise RuntimeError(f"{label} failed after {attempts} attempts: {last_err}")


@dataclass
class AgentStep:
    kind: str  # "tool_call" | "tool_result" | "tool_error" | "final_answer"
    detail: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class UsageTotals:
    input_tokens: int = 0
    output_tokens: int = 0
    llm_calls: int = 0

    def add(self, input_tokens: int, output_tokens: int):
        self.input_tokens += input_tokens
        self.output_tokens += output_tokens
        self.llm_calls += 1


@dataclass
class AgentTrace:
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    steps: list[AgentStep] = field(default_factory=list)
    usage: UsageTotals = field(default_factory=UsageTotals)

    def log(self, kind: str, detail: str):
        self.steps.append(AgentStep(kind, detail))
        logger.debug(f"[{self.run_id}] {kind}: {detail[:300]}")

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "steps": [
                {"kind": s.kind, "detail": s.detail, "timestamp": s.timestamp}
                for s in self.steps
            ],
            "usage": {
                "input_tokens": self.usage.input_tokens,
                "output_tokens": self.usage.output_tokens,
                "llm_calls": self.usage.llm_calls,
            },
        }

    def save(self, path: str | None = None) -> str:
        path = path or os.path.join(LOG_DIR, f"transcript_{self.run_id}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)
        return path


class ResearchAgent:
    def __init__(
        self,
        llm_client,
        max_iterations: int = 6,
        tool_retry_attempts: int = 2,
        llm_retry_attempts: int = 3,
    ):
        self.llm_client = llm_client
        self.max_iterations = max_iterations
        self.tool_retry_attempts = tool_retry_attempts
        self.llm_retry_attempts = llm_retry_attempts

    def run(self, question: str, messages: list[dict] | None = None) -> tuple[str, AgentTrace]:
        """Run the agent. Pass `messages` from a prior saved transcript to
        resume a conversation instead of starting fresh."""
        trace = AgentTrace()
        logger.info(f"[{trace.run_id}] starting run: {question!r}")
        messages = messages or [{"role": "user", "content": question}]

        for iteration in range(1, self.max_iterations + 1):
            try:
                response: LLMResponse = _retry(
                    lambda: self.llm_client.next_step(messages, TOOL_SCHEMAS, SYSTEM_PROMPT),
                    attempts=self.llm_retry_attempts,
                    label="LLM call",
                )
            except RuntimeError as e:
                trace.log("final_answer", f"LLM backend unavailable: {e}")
                return f"Sorry, the LLM backend failed repeatedly: {e}", trace

            usage = getattr(response, "usage", None)
            if usage:
                trace.usage.add(usage.get("input_tokens", 0), usage.get("output_tokens", 0))

            if response.stop_reason != "tool_use" or not response.tool_calls:
                final = response.text or "(no answer produced)"
                trace.log("final_answer", final)
                logger.info(f"[{trace.run_id}] finished in {iteration} iteration(s)")
                return final, trace

            messages.append({
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.input}
                    for tc in response.tool_calls
                ],
            })

            result_blocks = []
            for tc in response.tool_calls:
                trace.log("tool_call", f"{tc.name}({tc.input})")
                result_text = self._execute_tool_with_retry(tc, trace)
                result_blocks.append({
                    "type": "tool_result",
                    "tool_use_id": tc.id,
                    "content": result_text,
                })
            messages.append({"role": "user", "content": result_blocks})

        trace.log("final_answer", "(stopped: hit max_iterations without a final answer)")
        logger.warning(f"[{trace.run_id}] hit max_iterations ({self.max_iterations})")
        return "I wasn't able to reach a final answer within the iteration budget.", trace

    def _execute_tool_with_retry(self, tc: ToolCall, trace: AgentTrace) -> str:
        impl = TOOL_IMPLS.get(tc.name)
        if impl is None:
            msg = f"ERROR: unknown tool '{tc.name}'"
            trace.log("tool_error", msg)
            return msg

        def call():
            result = impl(**tc.input)
            # Tools return "ERROR: ..." strings rather than raising on bad
            # input (see tools.py) — treat that as a retryable failure too,
            # so a transient bad SQL/arg gets one more shot before giving up.
            if isinstance(result, str) and result.startswith("ERROR"):
                raise ValueError(result)
            return result

        try:
            result = _retry(call, attempts=self.tool_retry_attempts, label=f"tool:{tc.name}")
            trace.log("tool_result", result)
            return result
        except RuntimeError as e:
            msg = f"ERROR: {e}"
            trace.log("tool_error", msg)
            return msg
