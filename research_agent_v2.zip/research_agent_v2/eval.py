"""
eval.py — a minimal but real regression harness.

Without this, "I improved the agent" is a vibe, not a measurement. This runs
a fixed set of questions, checks the final answer against expectations, and
reports pass/fail per case plus tool-usage stats. Run it before and after any
change to agent.py / tools.py / prompts to see if you actually helped.

Usage: python eval.py
"""
from __future__ import annotations

from dataclasses import dataclass

from agent import ResearchAgent
from llm_client import get_default_client


@dataclass
class EvalCase:
    name: str
    question: str
    # substrings that must appear (case-insensitive) somewhere in the final answer
    must_contain: list[str]
    # tool names that should be called at least once for this to be a "good" run
    expected_tools: list[str]


CASES = [
    EvalCase(
        name="db_sales_lookup",
        question="What were total sales units in APAC in Q2 2025 according to our database?",
        must_contain=["46500", "apac"],
        expected_tools=["database_query"],
    ),
    EvalCase(
        name="internal_doc_risk",
        question="What does our internal analyst commentary say about APAC market risk?",
        must_contain=["byd", "domestic"],
        expected_tools=["document_retrieval"],
    ),
    EvalCase(
        name="web_market_stat",
        question="According to public market reports, what were global EV sales in 2025?",
        must_contain=["17.1 million"],
        expected_tools=["web_search"],
    ),
    EvalCase(
        name="math_question",
        question="If APAC Q1 revenue was 984000000 and Q2 was 1116000000, what was the dollar increase?",
        must_contain=["132000000", "132,000,000"],
        expected_tools=["calculator"],
    ),
]


def run_eval():
    client = get_default_client()
    agent = ResearchAgent(client)
    print(f"Backend: {type(client).__name__}\n{'=' * 60}")

    passed = 0
    for case in CASES:
        answer, trace = agent.run(case.question)
        answer_l = answer.lower()

        content_ok = any(s.lower() in answer_l for s in case.must_contain)
        tools_used = {
            s.detail.split("(")[0] for s in trace.steps if s.kind == "tool_call"
        }
        tools_ok = all(t in tools_used for t in case.expected_tools)

        ok = content_ok and tools_ok
        passed += ok
        status = "PASS" if ok else "FAIL"
        print(f"[{status}] {case.name}")
        if not content_ok:
            print(f"         expected one of {case.must_contain} in answer — not found")
        if not tools_ok:
            print(f"         expected tools {case.expected_tools}, got {sorted(tools_used)}")
        print(f"         tool calls: {len(tools_used)} | iterations: "
              f"{sum(1 for s in trace.steps if s.kind == 'tool_call')} | "
              f"tokens: in={trace.usage.input_tokens} out={trace.usage.output_tokens}")

    print("=" * 60)
    print(f"{passed}/{len(CASES)} cases passed")
    return passed, len(CASES)


if __name__ == "__main__":
    run_eval()
