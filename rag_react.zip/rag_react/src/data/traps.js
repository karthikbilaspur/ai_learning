export const traps = {
  KB017:{label:'IRRELEVANT TRAP',desc:'Unrelated wiki dump - tests precision'},
  KB018:{label:'OUTDATED TRAP',desc:'2019 policy superseded - should be filtered'},
  KB019:{label:'PARTIAL TRAP',desc:'Truncated - leads to missing_info'},
  KB020:{label:'CONFLICTING TRAP',desc:'False founder claim - causes hallucination if grounded'}
};
