export default function MetricCard({label,value,note,max=1}) {
  const pct = max===5 ? value/5 : max===1 ? value : 1-Math.min(1,value/3000);
  return <div className="metric-card"><div className="eyebrow">{label}</div><div className="metric-value">{max===5?value:label==='Latency'?`${value}ms`:value.toFixed(2)}</div><div className="metric-note">{note} {label!=='Latency' && <>{Math.round(pct*100)}%</>}</div><div className="meter"><span style={{width:`${Math.max(0,Math.min(100,pct*100))}%`}}/></div></div>
}
