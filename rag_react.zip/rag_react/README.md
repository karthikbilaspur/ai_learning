# RAG Evaluation Lab — React Migration

This project is a React/Vite migration of the uploaded `Rag-Eval-Lab.html` prototype. The migration keeps the source project's core concepts and demo behavior while separating UI, evaluation logic, data, and pages.

## Included
- Overview dashboard
- 10-record clean KB and 20-record noisy KB
- KB017–KB020 trap document behavior
- 12-test suite extracted from the source artifact
- Faithfulness, precision, recall, correctness, completeness, latency
- Failure-mode view
- Retrieval simulator
- Heuristic evaluation runner
- Add-a-test behavior from the evaluation runner
- Responsive dark UI

## Run

Requirements: Node.js 18+.

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Build

```bash
npm run build
npm run preview
```

## Architecture

- `src/components` — reusable UI pieces
- `src/pages` — major application views
- `src/data` — source-derived knowledge bases and 12 test cases
- `src/lib/evaluation.js` — retrieval simulation and heuristic scoring
- `src/App.jsx` — application state and page orchestration

## Important

This remains the source project's heuristic/simulation model. It does not add real embeddings, vector databases, LLM calls, NLI judges, or production retrieval infrastructure. The goal of this migration is to show how the same working prototype looks and behaves when organized as a maintainable React project.
