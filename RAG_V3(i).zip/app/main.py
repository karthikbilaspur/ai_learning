import time
import uuid
import pathlib
import tempfile
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, field_validator
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from .retrieval import hybrid_search
from .llm import generate_answer, stream_answer
from .db import init_db, db_cursor
from .ingest import ingest_single_file
from .auth import require_api_key
from .config import (
    CORS_ORIGINS, API_KEY, RATE_LIMIT_CHAT, RATE_LIMIT_UPLOAD,
    MAX_QUESTION_LEN, MAX_FILENAME_FILTER_LEN, MAX_TOP_K, MAX_UPLOAD_MB,
)
from .logging_conf import get_logger

log = get_logger(__name__)

limiter = Limiter(key_func=get_remote_address)

app = FastAPI(title="Chat with Docs - pgvector RAG")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration_ms = (time.time() - start) * 1000
    log.info(f"{request.method} {request.url.path} -> {response.status_code} ({duration_ms:.1f}ms)")
    return response


class ChatRequest(BaseModel):
    question: str
    session_id: str | None = None
    filename_filter: str | None = None
    top_k: int = 8

    @field_validator("question")
    @classmethod
    def question_not_empty_or_too_long(cls, v):
        v = v.strip()
        if not v:
            raise ValueError("question must not be empty")
        if len(v) > MAX_QUESTION_LEN:
            raise ValueError(f"question exceeds {MAX_QUESTION_LEN} characters")
        return v

    @field_validator("filename_filter")
    @classmethod
    def filter_len(cls, v):
        if v and len(v) > MAX_FILENAME_FILTER_LEN:
            raise ValueError(f"filename_filter exceeds {MAX_FILENAME_FILTER_LEN} characters")
        return v

    @field_validator("top_k")
    @classmethod
    def top_k_bounds(cls, v):
        if v < 1 or v > MAX_TOP_K:
            raise ValueError(f"top_k must be between 1 and {MAX_TOP_K}")
        return v


@app.on_event("startup")
def startup():
    init_db()
    if not API_KEY:
        log.warning("API_KEY is not set - endpoints are UNAUTHENTICATED. Set API_KEY in .env for production.")


@app.get("/")
def health():
    return {
        "status": "ok",
        "db": "pgvector",
        "auth_enabled": bool(API_KEY),
        "features": [
            "hybrid_search", "reranking", "chat_history", "streaming",
            "api_key_auth", "connection_pooling", "rate_limiting",
            "file_upload", "per_file_reindex",
        ],
    }


def _load_history(cur, session_id):
    cur.execute(
        "SELECT role, content FROM chat_history WHERE session_id=%s ORDER BY id ASC LIMIT 20",
        (session_id,),
    )
    return [{"role": r[0], "content": r[1]} for r in cur.fetchall()]


def _save_turn(cur, session_id, question, answer):
    cur.execute(
        "INSERT INTO chat_history (session_id, role, content) VALUES (%s,%s,%s)",
        (session_id, "user", question),
    )
    cur.execute(
        "INSERT INTO chat_history (session_id, role, content) VALUES (%s,%s,%s)",
        (session_id, "assistant", str(answer)),
    )


@app.post("/chat", dependencies=[Depends(require_api_key)])
@limiter.limit(RATE_LIMIT_CHAT)
def chat(request: Request, req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())

    try:
        with db_cursor(commit=True) as cur:
            history = _load_history(cur, session_id)
            chunks = hybrid_search(req.question, final_k=req.top_k, filename_filter=req.filename_filter)

            if not chunks:
                answer = "I couldn't find that in your documents."
            else:
                answer = generate_answer(chunks, req.question, chat_history=history)

            _save_turn(cur, session_id, req.question, answer)
    except Exception as e:
        log.error(f"/chat failed: {e}")
        raise HTTPException(status_code=500, detail="Something went wrong processing your question.")

    return {"session_id": session_id, "answer": answer, "sources": chunks}


@app.post("/chat/stream", dependencies=[Depends(require_api_key)])
@limiter.limit(RATE_LIMIT_CHAT)
def chat_stream(request: Request, req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())

    try:
        with db_cursor() as cur:
            history = _load_history(cur, session_id)
        chunks = hybrid_search(req.question, final_k=req.top_k, filename_filter=req.filename_filter)
    except Exception as e:
        log.error(f"/chat/stream setup failed: {e}")
        raise HTTPException(status_code=500, detail="Something went wrong preparing your answer.")

    def event_gen():
        collected = []
        yield f"event: session\ndata: {session_id}\n\n"

        if not chunks:
            msg = "I couldn't find that in your documents."
            collected.append(msg)
            yield f"data: {msg}\n\n"
        else:
            for piece in stream_answer(chunks, req.question, chat_history=history):
                collected.append(piece)
                safe = piece.replace("\n", "\\n")
                yield f"data: {safe}\n\n"

        full_answer = "".join(collected)
        try:
            with db_cursor(commit=True) as cur:
                _save_turn(cur, session_id, req.question, full_answer)
        except Exception as e:
            log.error(f"Failed to save chat history after stream: {e}")

        yield "event: done\ndata: [DONE]\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/documents", dependencies=[Depends(require_api_key)])
def list_docs():
    try:
        with db_cursor() as cur:
            cur.execute("SELECT id, filename, total_chunks, created_at FROM documents ORDER BY created_at DESC")
            rows = cur.fetchall()
    except Exception as e:
        log.error(f"/documents failed: {e}")
        raise HTTPException(status_code=500, detail="Could not list documents.")

    return [{"id": r[0], "filename": r[1], "chunks": r[2], "created_at": str(r[3])} for r in rows]


@app.delete("/documents/{doc_id}", dependencies=[Depends(require_api_key)])
def delete_doc(doc_id: int):
    try:
        with db_cursor(commit=True) as cur:
            cur.execute("SELECT id FROM documents WHERE id=%s", (doc_id,))
            if cur.fetchone() is None:
                raise HTTPException(status_code=404, detail=f"Document {doc_id} not found.")
            cur.execute("DELETE FROM documents WHERE id=%s", (doc_id,))
    except HTTPException:
        raise
    except Exception as e:
        log.error(f"delete_doc failed: {e}")
        raise HTTPException(status_code=500, detail="Could not delete document.")

    return {"deleted": doc_id}


@app.post("/documents/upload", dependencies=[Depends(require_api_key)])
@limiter.limit(RATE_LIMIT_UPLOAD)
async def upload_doc(request: Request, file: UploadFile = File(...)):
    suffix = pathlib.Path(file.filename).suffix.lower()
    if suffix not in [".pdf", ".md", ".txt"]:
        raise HTTPException(status_code=400, detail="Only .pdf, .md, .txt files are supported.")

    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > MAX_UPLOAD_MB:
        raise HTTPException(status_code=413, detail=f"File exceeds {MAX_UPLOAD_MB}MB limit.")

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(contents)
        tmp_path = pathlib.Path(tmp.name)

    try:
        doc_id = ingest_single_file(tmp_path)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        log.error(f"Upload ingest failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to ingest uploaded file.")
    finally:
        tmp_path.unlink(missing_ok=True)

    return {"document_id": doc_id, "filename": file.filename, "status": "ingested"}


@app.post("/documents/{doc_id}/reindex", dependencies=[Depends(require_api_key)])
def reindex_doc(doc_id: int):
    with db_cursor() as cur:
        cur.execute("SELECT filename FROM documents WHERE id=%s", (doc_id,))
        row = cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Document {doc_id} not found.")

    original_path = pathlib.Path(row[0])
    if not original_path.exists():
        raise HTTPException(
            status_code=409,
            detail=f"Original file '{original_path}' is no longer on disk - cannot reindex. "
                   f"Delete and re-upload instead.",
        )

    try:
        ingest_single_file(original_path, existing_doc_id=doc_id)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        log.error(f"Reindex failed for doc {doc_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to reindex document.")

    return {"document_id": doc_id, "status": "reindexed"}
