"""Simple API-key auth dependency for FastAPI.

Set API_KEY in the environment to require clients to send a matching
`X-API-Key` header on every request. If API_KEY is left empty (default
for local dev), auth is skipped entirely.
"""
from fastapi import Header, HTTPException, status
from .config import API_KEY


def require_api_key(x_api_key: str = Header(default=None)):
    if not API_KEY:
        # Auth disabled (no API_KEY configured) - allow through.
        return
    if x_api_key != API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key. Send it in the X-API-Key header.",
        )
