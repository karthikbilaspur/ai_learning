import os
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://raguser:ragpass@localhost:5432/ragdb")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "384"))
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")

# --- API auth ---
API_KEY = os.getenv("API_KEY", "")

# --- CORS ---
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8501").split(",") if o.strip()]

# --- Logging ---
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# --- New: connection pool sizing ---
DB_POOL_MIN_CONN = int(os.getenv("DB_POOL_MIN_CONN", "1"))
DB_POOL_MAX_CONN = int(os.getenv("DB_POOL_MAX_CONN", "10"))

# --- New: rate limiting (requests per client per window) ---
RATE_LIMIT_CHAT = os.getenv("RATE_LIMIT_CHAT", "20/minute")
RATE_LIMIT_UPLOAD = os.getenv("RATE_LIMIT_UPLOAD", "5/minute")

# --- New: input validation caps ---
MAX_QUESTION_LEN = int(os.getenv("MAX_QUESTION_LEN", "2000"))
MAX_FILENAME_FILTER_LEN = int(os.getenv("MAX_FILENAME_FILTER_LEN", "255"))
MAX_TOP_K = int(os.getenv("MAX_TOP_K", "25"))
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))
