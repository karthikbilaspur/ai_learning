import pathlib
import json
import argparse
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from psycopg2.extras import execute_values
from .db import get_conn, release_conn, init_db
from .config import EMBEDDING_MODEL
from .logging_conf import get_logger

log = get_logger(__name__)

splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=150,
    separators=["\n## ", "\n### ", "\n\n", "\n", ". ", " "]
)

_model = None


def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(EMBEDDING_MODEL)
    return _model


def load_file(path: pathlib.Path):
    if path.suffix.lower() == ".pdf":
        try:
            reader = PdfReader(str(path))
        except Exception as e:
            log.error(f"Could not read PDF {path}: {e}")
            return []
        texts = []
        for i, page in enumerate(reader.pages):
            t = page.extract_text() or ""
            if t.strip():
                texts.append((t, {"page": i + 1}))
        return texts
    elif path.suffix.lower() in [".md", ".txt"]:
        try:
            txt = path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            log.error(f"Could not read {path}: {e}")
            return []
        return [(txt, {})]
    else:
        return []


def ingest_single_file(path: pathlib.Path, existing_doc_id: int | None = None) -> int:
    """Ingest (or re-ingest) one file. Returns the document id.

    If `existing_doc_id` is given, its old chunks are deleted first and the
    same document row is reused (used by the /reindex endpoint) instead of
    creating a duplicate `documents` row.
    """
    pages = load_file(path)
    if not pages:
        raise ValueError(f"No extractable text in {path}")

    model = get_model()
    all_chunks = []
    for text, meta in pages:
        chunks = splitter.split_text(text)
        for ch in chunks:
            all_chunks.append((ch, {**meta, "filename": str(path)}))

    if not all_chunks:
        raise ValueError(f"No chunks produced for {path}")

    embeddings = model.encode([c[0] for c in all_chunks], show_progress_bar=False, batch_size=32)
    rows_data = [(content, json.dumps(meta), emb.tolist()) for (content, meta), emb in zip(all_chunks, embeddings)]

    conn = get_conn()
    try:
        cur = conn.cursor()
        if existing_doc_id is not None:
            doc_id = existing_doc_id
            cur.execute("DELETE FROM chunks WHERE document_id=%s", (doc_id,))
        else:
            cur.execute("INSERT INTO documents (filename, filetype) VALUES (%s,%s) RETURNING id", (str(path), path.suffix))
            doc_id = cur.fetchone()[0]

        rows = [(doc_id, content, meta_json, emb) for content, meta_json, emb in rows_data]
        execute_values(cur, "INSERT INTO chunks (document_id, content, metadata, embedding) VALUES %s", rows)
        cur.execute("UPDATE documents SET total_chunks=%s WHERE id=%s", (len(rows), doc_id))
        conn.commit()
        cur.close()
        return doc_id
    except Exception:
        conn.rollback()
        raise
    finally:
        release_conn(conn)


def ingest(folder="docs"):
    init_db()
    docs_path = pathlib.Path(folder)
    if not docs_path.exists():
        log.error(f"Folder '{folder}' does not exist.")
        return

    files = [f for f in docs_path.rglob("*") if f.is_file() and f.suffix.lower() in [".pdf", ".md", ".txt"]]
    if not files:
        log.warning(f"No .pdf/.md/.txt files found in '{folder}'.")

    for file in files:
        try:
            log.info(f"Ingesting {file}...")
            doc_id = ingest_single_file(file)
            log.info(f"  -> doc_id={doc_id}")
        except Exception as e:
            log.error(f"Failed to ingest {file}: {e}")

    log.info("Ingestion done")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", default="docs")
    args = parser.parse_args()
    ingest(args.folder)
