from openai import OpenAI, OpenAIError
from .config import OPENAI_API_KEY, LLM_MODEL
from .logging_conf import get_logger

log = get_logger(__name__)

client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

SYSTEM_PROMPT = '''You are a helpful assistant for "Chat with my documents".
Rules:
1. Answer ONLY from the provided context.
2. If not in context, say "I couldn't find that in your documents."
3. Always cite sources as [chunk_id] after the sentence.
4. Be concise, but include page numbers/filename if present in metadata.
5. If user asks for summary, summarize across chunks.
'''


def build_prompt(context_chunks, question, chat_history=None):
    ctx = "\n\n".join([
        f"[{c['id']}] (File: {c['metadata'].get('filename')} Page: {c['metadata'].get('page', 'N/A')})\n{c['content']}"
        for c in context_chunks
    ])
    hist = ""
    if chat_history:
        hist = "\n".join([f"{m['role']}: {m['content']}" for m in chat_history[-6:]])
    return f"{SYSTEM_PROMPT}\n\nChat History:\n{hist}\n\nContext:\n{ctx}\n\nQuestion: {question}\nAnswer:"


def generate_answer(context_chunks, question, chat_history=None):
    """Non-streaming answer generation. Returns a plain string."""
    if not client:
        return (
            f"(Mock LLM - set OPENAI_API_KEY)\nBased on {len(context_chunks)} chunks, "
            f"the answer to '{question}' is in the context.\n\n"
            + "\n".join([c['content'][:300] for c in context_chunks])
        )

    prompt = build_prompt(context_chunks, question, chat_history)
    try:
        resp = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return resp.choices[0].message.content
    except OpenAIError as e:
        log.error(f"OpenAI call failed: {e}")
        return "Sorry, I hit an error talking to the language model. Please try again in a moment."


def stream_answer(context_chunks, question, chat_history=None):
    """Generator yielding text chunks as they arrive from the LLM (SSE-friendly).
    Falls back to yielding the whole mock/error answer in one chunk when
    streaming isn't available."""
    if not client:
        yield generate_answer(context_chunks, question, chat_history)
        return

    prompt = build_prompt(context_chunks, question, chat_history)
    try:
        stream = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            stream=True,
        )
        for event in stream:
            delta = event.choices[0].delta.content if event.choices else None
            if delta:
                yield delta
    except OpenAIError as e:
        log.error(f"OpenAI streaming call failed: {e}")
        yield "\n\n[Error talking to the language model. Please try again.]"
