from contextlib import contextmanager
import psycopg2
from psycopg2 import pool as pg_pool
from psycopg2.extras import execute_values
from pgvector.psycopg2 import register_vector
from .config import DATABASE_URL, DB_POOL_MIN_CONN, DB_POOL_MAX_CONN
from .logging_conf import get_logger

log = get_logger(__name__)

_pool = None


def _get_pool():
    """Lazily create a threaded connection pool. Reusing connections instead
    of opening a fresh TCP+auth handshake per request is the single biggest
    latency win under concurrent load."""
    global _pool
    if _pool is None:
        log.info(f"Creating DB connection pool (min={DB_POOL_MIN_CONN}, max={DB_POOL_MAX_CONN})")
        _pool = pg_pool.ThreadedConnectionPool(DB_POOL_MIN_CONN, DB_POOL_MAX_CONN, dsn=DATABASE_URL)
    return _pool


def get_conn():
    """Grab a connection straight from the pool (bypassing the context
    manager). Caller is responsible for returning it via release_conn()."""
    try:
        conn = _get_pool().getconn()
        register_vector(conn)
        return conn
    except psycopg2.OperationalError as e:
        log.error(f"Could not get DB connection from pool: {e}")
        raise


def release_conn(conn):
    _get_pool().putconn(conn)


@contextmanager
def db_cursor(commit: bool = False):
    """Context manager that checks a connection out of the pool, guarantees
    it's returned (not closed) afterwards, and rolls back on error."""
    conn = get_conn()
    cur = conn.cursor()
    try:
        yield cur
        if commit:
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        release_conn(conn)


def init_db():
    with db_cursor(commit=True) as cur:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        cur.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id SERIAL PRIMARY KEY,
                filename TEXT NOT NULL,
                filetype TEXT,
                total_chunks INT DEFAULT 0,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
        cur.execute('''
            CREATE TABLE IF NOT EXISTS chunks (
                id SERIAL PRIMARY KEY,
                document_id INT REFERENCES documents(id) ON DELETE CASCADE,
                content TEXT NOT NULL,
                metadata JSONB,
                embedding vector(384),
                tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', content)) STORED
            );
        ''')
        cur.execute("CREATE INDEX IF NOT EXISTS chunks_embedding_idx ON chunks USING hnsw (embedding vector_cosine_ops);")
        cur.execute("CREATE INDEX IF NOT EXISTS chunks_tsv_idx ON chunks USING GIN (tsv);")
        cur.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id SERIAL PRIMARY KEY,
                session_id TEXT,
                role TEXT,
                content TEXT,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
    log.info("DB initialized")
