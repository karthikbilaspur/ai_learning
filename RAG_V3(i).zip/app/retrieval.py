from .db import db_cursor
from .config import EMBEDDING_MODEL
from .logging_conf import get_logger
from sentence_transformers import SentenceTransformer, CrossEncoder

log = get_logger(__name__)

_embed_model = None
_reranker = None


def get_embed_model():
    global _embed_model
    if _embed_model is None:
        log.info(f"Loading embedding model {EMBEDDING_MODEL}...")
        _embed_model = SentenceTransformer(EMBEDDING_MODEL)
    return _embed_model


def get_reranker():
    global _reranker
    if _reranker is None:
        log.info("Loading reranker cross-encoder/ms-marco-MiniLM-L-6-v2...")
        _reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
    return _reranker


def hybrid_search(query: str, top_k=50, final_k=8, filename_filter=None):
    model = get_embed_model()
    q_emb = model.encode(query).tolist()

    with db_cursor() as cur:
        # Vector search + optional filename filter (fixed: params now match
        # placeholder order exactly - the original build had them swapped).
        if filename_filter:
            cur.execute('''
                SELECT id, content, metadata, 1 - (embedding <=> %s) as score
                FROM chunks
                WHERE metadata->>'filename' ILIKE %s
                ORDER BY embedding <=> %s
                LIMIT %s
            ''', (q_emb, f"%{filename_filter}%", q_emb, top_k))
        else:
            cur.execute('''
                SELECT id, content, metadata, 1 - (embedding <=> %s) as score
                FROM chunks
                ORDER BY embedding <=> %s
                LIMIT %s
            ''', (q_emb, q_emb, top_k))

        rows = cur.fetchall()
        candidates = [{"id": r[0], "content": r[1], "metadata": r[2], "score": r[3]} for r in rows]

        # BM25-style full-text boost - hybrid fusion
        if filename_filter:
            cur.execute('''
                SELECT id, content, metadata, ts_rank(tsv, plainto_tsquery('english', %s)) as rank
                FROM chunks
                WHERE tsv @@ plainto_tsquery('english', %s) AND metadata->>'filename' ILIKE %s
                ORDER BY rank DESC
                LIMIT %s
            ''', (query, query, f"%{filename_filter}%", top_k))
        else:
            cur.execute('''
                SELECT id, content, metadata, ts_rank(tsv, plainto_tsquery('english', %s)) as rank
                FROM chunks
                WHERE tsv @@ plainto_tsquery('english', %s)
                ORDER BY rank DESC
                LIMIT %s
            ''', (query, query, top_k))
        ft_rows = [{"id": r[0], "content": r[1], "metadata": r[2], "score": r[3]} for r in cur.fetchall()]

    # Merge dedup
    seen = {c["id"]: c for c in candidates}
    for c in ft_rows:
        if c["id"] not in seen:
            seen[c["id"]] = c
    merged = list(seen.values())

    if not merged:
        return []

    # Reranking stage
    reranker = get_reranker()
    pairs = [[query, c["content"]] for c in merged]
    scores = reranker.predict(pairs)

    reranked = sorted(zip(merged, scores), key=lambda x: x[1], reverse=True)
    final = [{**doc, "rerank_score": float(score)} for doc, score in reranked[:final_k]]
    return final
