"""Unit tests for file loading logic in ingest.py (no DB/model needed)."""
import pathlib
import tempfile
from app.ingest import load_file, splitter


def test_load_txt_file():
    with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False) as f:
        f.write("Hello world. This is a test document.")
        path = pathlib.Path(f.name)
    try:
        pages = load_file(path)
        assert len(pages) == 1
        text, meta = pages[0]
        assert "Hello world" in text
        assert meta == {}
    finally:
        path.unlink()


def test_load_unsupported_extension_returns_empty():
    with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
        path = pathlib.Path(f.name)
    try:
        assert load_file(path) == []
    finally:
        path.unlink()


def test_splitter_chunks_long_text():
    long_text = "word " * 1000
    chunks = splitter.split_text(long_text)
    assert len(chunks) > 1
    assert all(len(c) <= 900 for c in chunks)  # chunk_size=800 + slack
