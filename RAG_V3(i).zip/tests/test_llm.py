"""Unit tests for prompt building and mock-mode answer generation.
These don't need a live DB or an OpenAI key."""
import os
os.environ.setdefault("OPENAI_API_KEY", "")  # force mock mode

from app.llm import build_prompt, generate_answer


def _sample_chunks():
    return [
        {"id": 1, "content": "The sky is blue.", "metadata": {"filename": "sky.txt", "page": 1}},
        {"id": 2, "content": "Water boils at 100C.", "metadata": {"filename": "physics.txt"}},
    ]


def test_build_prompt_includes_question_and_context():
    prompt = build_prompt(_sample_chunks(), "Why is the sky blue?")
    assert "Why is the sky blue?" in prompt
    assert "The sky is blue." in prompt
    assert "sky.txt" in prompt


def test_build_prompt_includes_recent_history_only():
    history = [{"role": "user", "content": f"msg{i}"} for i in range(10)]
    prompt = build_prompt(_sample_chunks(), "question", chat_history=history)
    # only the last 6 history entries should be included
    assert "msg9" in prompt
    assert "msg0" not in prompt


def test_generate_answer_mock_mode_when_no_api_key():
    answer = generate_answer(_sample_chunks(), "What color is the sky?")
    assert "Mock LLM" in answer
    assert "sky is blue" in answer.lower() or "blue" in answer.lower()
