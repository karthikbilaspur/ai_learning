"""Unit tests for ChatRequest input validation added in v3."""
import pytest
from pydantic import ValidationError
from app.main import ChatRequest
from app.config import MAX_QUESTION_LEN, MAX_TOP_K


def test_valid_request_passes():
    req = ChatRequest(question="What is this doc about?")
    assert req.top_k == 8


def test_empty_question_rejected():
    with pytest.raises(ValidationError):
        ChatRequest(question="   ")


def test_question_too_long_rejected():
    with pytest.raises(ValidationError):
        ChatRequest(question="x" * (MAX_QUESTION_LEN + 1))


def test_top_k_out_of_bounds_rejected():
    with pytest.raises(ValidationError):
        ChatRequest(question="hi", top_k=MAX_TOP_K + 1)
    with pytest.raises(ValidationError):
        ChatRequest(question="hi", top_k=0)


def test_filename_filter_too_long_rejected():
    with pytest.raises(ValidationError):
        ChatRequest(question="hi", filename_filter="x" * 300)
