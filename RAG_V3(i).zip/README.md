# Chat with my Documents - PostgreSQL + pgvector RAG (v3)

Full RAG pipeline in Postgres: ingestion, chunking, embeddings, vector storage, hybrid retrieval, reranking, LLM generation — with a FastAPI backend and Streamlit chat UI.

### Core features (v1)
- Hybrid search: vector cosine + full-text (tsvector) fusion
- Reranking: cross-encoder/ms-marco-MiniLM-L-6-v2
- Chat history stored in Postgres
- Metadata filtering by filename, HNSW index

### v2 additions
- API key auth (`X-API-Key` header), CORS locked down
- Streaming answers via SSE (`/chat/stream`)
- Full Dockerization (API + Streamlit + DB in one `docker-compose.yml`)
- Structured error handling & logging
- Fixed a SQL param-order bug in the filename filter
- Pinned dependencies

### v3 additions
- **File upload endpoint** — `POST /documents/upload` — ingest a PDF/MD/TXT directly via the API or the Streamlit sidebar, no CLI step needed
- **Per-file re-index** — `POST /documents/{id}/reindex` — re-chunk and re-embed a single file (e.g. after editing it) without wiping the whole DB or duplicating the document row
- **Connection pooling** — `psycopg2.pool.ThreadedConnectionPool` replaces per-request `connect()/close()`, cutting latency under concurrent load (`DB_POOL_MIN_CONN`/`DB_POOL_MAX_CONN` in `.env`)
- **Rate limiting** — `slowapi` caps `/chat`, `/chat/stream`, and `/documents/upload` per client IP (`RATE_LIMIT_CHAT`, `RATE_LIMIT_UPLOAD` in `.env`)
- **Input validation** — question length, `top_k` bounds, filename-filter length, and upload size (`MAX_UPLOAD_MB`) are all enforced with clear 4xx errors instead of failing deep in the pipeline
- **Request logging middleware** — every request logs method, path, status code, and latency
- **Test suite** — `tests/` covers prompt building, mock-mode LLM answers, file loading, and input validation with pytest (no live DB required)
- **CI** — GitHub Actions workflow runs the test suite and a syntax check on every push/PR

### Quickstart (Docker, recommended)
1. `cp .env.example .env` and set `OPENAI_API_KEY` (or leave empty for mock mode) and a real `API_KEY`
2. `docker-compose up -d --build`
3. Open `http://localhost:8501` and upload a PDF/MD/TXT from the sidebar — or ingest a folder:
   `docker-compose exec api python -m app.ingest --folder docs`

### Quickstart (local, no Docker for app)
1. `docker-compose up -d db`
2. `pip install -r requirements.txt`
3. `cp .env.example .env` and configure it
4. `uvicorn app.main:app --reload --port 8000`
5. In another terminal: `API_KEY=<same as .env> streamlit run streamlit_app.py`

### Running tests
```
pip install -r requirements.txt
pytest tests/ -v
```
Tests are DB-free (they test prompt logic, file loading, and pydantic validation directly) so they run in CI without a Postgres instance.

### New endpoints
| Endpoint | Method | Notes |
|---|---|---|
| `/documents/upload` | POST | multipart file upload, rate-limited, 20MB default cap |
| `/documents/{id}/reindex` | POST | re-ingests the same file path in place |
| `/chat/stream` | POST | SSE token streaming |

### Auth
Every API call needs `X-API-Key: <your key>` if `API_KEY` is set in `.env`. The Streamlit app attaches it automatically from its own environment.

### Architecture
```
docs/ or upload -> app/ingest.py (chunk 800/150 overlap, all-MiniLM-L6-v2 embeddings)
                -> Postgres pgvector (pooled connections)
                -> hybrid_search (vector + tsv) -> reranker
                -> LLM (streaming or non-streaming, rate-limited)
                -> FastAPI (auth + CORS + validation + request logging)
                -> Streamlit (upload, reindex, delete, live streaming)
```

### Still open for v4
Async DB driver (`asyncpg`/`psycopg3`), multi-tenancy / per-user document scoping, query rewriting for retrieval, semantic chunking, RAGAS-based eval harness, cost/usage dashboard, more file types (docx/html/csv).
