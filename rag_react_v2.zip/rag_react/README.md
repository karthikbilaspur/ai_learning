# RAG Evaluation Lab — React v2

This is a structured React/Vite migration of the supplied RAG Evaluation Lab, extended through the requested Version 4 roadmap.

## Included enhancements

### Version 2 — Better evaluation
- Precision/Recall retrieval helpers
- MRR, NDCG and Hit Rate
- Claim-level faithfulness analysis
- Failure heatmap
- Expanded metric interpretation

### Version 3 — Experiments and regression
- Experiment snapshots
- Baseline saving
- Run comparison
- Quality-over-time chart
- Regression rules

### Version 4 — Real RAG integration
- Pluggable HTTP pipeline adapter
- Demo/local mode remains available
- Configurable endpoint, bearer key, Top-K and reranker flag
- Documented JSON API contract
- External pipeline results can provide answer, retrieved docs, latency and evaluation metrics

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## HTTP pipeline contract

Configure `Real HTTP Pipeline` under **Pipeline**. POST JSON to the configured endpoint. The adapter expects at minimum:

```json
{
  "question": "...",
  "expected_answer": "...",
  "answer": "...",
  "retrieved_docs": [
    {"id":"D1","text":"...","score":0.92}
  ],
  "latency_ms": 842
}
```

Optional fields:

- `metrics`: faithfulness, precision, recall, correctness, completeness, tokens
- `claims`: `{score, details:[{claim,supported,grounded}]}`
- `retrieval_metrics`: `{mrr, ndcg, hitRate}`

The external adapter is intentionally provider-neutral; it does not ship credentials or hard-code a cloud LLM.
