import {useMemo,useState} from 'react';
import TopNav from './components/TopNav';
import Overview from './pages/Overview';
import TestSuite from './pages/TestSuite';
import Metrics from './pages/Metrics';
import Failures from './pages/Failures';
import RunEvaluation from './pages/RunEvaluation';
import Experiments from './pages/Experiments';
import Settings from './pages/Settings';
import kb10 from './data/kb10.json';
import kb20 from './data/kb20.json';
import initialTests from './data/tests.json';
import {makeRun} from './lib/experiments';

export default function App(){
 const [page,setPage]=useState('overview'); const [kbMode,setKbMode]=useState('10'); const [tests,setTests]=useState(initialTests); const [selected,setSelected]=useState(initialTests[0]?.id); const [runs,setRuns]=useState(()=>[makeRun('Baseline',null,{topK:3,reranker:false})]);
 const [pipelineConfig,setPipelineConfig]=useState({mode:'demo',endpoint:'',apiKey:'',topK:3,reranker:false});
 const kb=kbMode==='10'?kb10:kb20;
 const summary=useMemo(()=>{const n=tests.length||1;const avg=k=>tests.reduce((s,t)=>s+(t.scores[k]??0),0)/n;const p50=Math.round(tests.reduce((s,t)=>s+t.latency,0)/n);const p95=[...tests].sort((a,b)=>a.latency-b.latency)[Math.max(0,Math.floor(n*.95)-1)]?.latency||p50;const faith=avg('faith'),prec=avg('precision'),rec=avg('recall'),corr=avg('correctness'),comp=avg('completeness'),latScore=1-Math.min(1,p50/3000);return {faith,prec,rec,corr,comp,p50,p95,latScore,passes:tests.filter(t=>t.scores.faith>.7&&t.scores.correctness>=3).length,hallucRate:tests.filter(t=>t.scores.faith<.5).length/n,overall:faith*.3+prec*.2+rec*.15+(corr/5)*.2+comp*.1+latScore*.05}},[tests]);
 const effectiveRuns=runs.map(r=>r.name==='Baseline'?{...r,summary}:r);
 const saveBaseline=()=>setRuns(rs=>rs.map(r=>r.name==='Baseline'?{...r,summary}:r));
 return <><TopNav page={page} setPage={setPage} summary={summary}/><main className="shell main"><div className="kbbar"><span>Knowledge Base</span><button className={kbMode==='10'?'active':''} onClick={()=>setKbMode('10')}>10 Records (Clean)</button><button className={kbMode==='20'?'active':''} onClick={()=>setKbMode('20')}>20 Records (With Noise Traps)</button><span className="muted">{kb.length} docs • {kbMode==='20'?'4 trap docs: KB017-020':'clean'}</span></div>{page==='overview'&&<Overview summary={summary} setPage={setPage}/>} {page==='suite'&&<TestSuite tests={tests} kb={kb} selected={selected} setSelected={setSelected}/>} {page==='metrics'&&<Metrics summary={summary} history={effectiveRuns}/>} {page==='experiments'&&<Experiments runs={effectiveRuns} setRuns={setRuns} summary={summary}/>} {page==='failures'&&<Failures tests={tests}/>} {page==='run'&&<RunEvaluation kb={kb} setTests={setTests} pipelineConfig={pipelineConfig}/>} {page==='settings'&&<Settings config={pipelineConfig} setConfig={setPipelineConfig}/>}<button className="floating-save" onClick={saveBaseline}>Save baseline</button></main><footer className="footer"><div className="shell">RAG Evaluation Lab • React v2 • {pipelineConfig.mode==='demo'?'local simulation':'HTTP pipeline adapter'} • overall {(summary.overall*100).toFixed(0)}%</div></footer></>}
