import os
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://raguser:ragpass@localhost:5432/ragdb")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "384"))
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")

# --- New: API auth ---
# Clients must send this value in the `X-API-Key` header on every request.
# Leave unset (empty) to disable auth for local dev.
API_KEY = os.getenv("API_KEY", "")

# --- New: CORS ---
# Comma-separated list of allowed origins, e.g. "http://localhost:8501,https://myapp.com"
# Defaults to the bundled Streamlit app only, instead of the previous wildcard "*".
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8501").split(",") if o.strip()]

# --- New: logging ---
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
