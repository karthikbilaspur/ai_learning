import pathlib
import json
import argparse
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from psycopg2.extras import execute_values
from .db import get_conn, init_db
from .config import EMBEDDING_MODEL
from .logging_conf import get_logger

log = get_logger(__name__)

splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=150,
    separators=["\n## ", "\n### ", "\n\n", "\n", ". ", " "]
)


def load_file(path: pathlib.Path):
    if path.suffix.lower() == ".pdf":
        try:
            reader = PdfReader(str(path))
        except Exception as e:
            log.error(f"Could not read PDF {path}: {e}")
            return []
        texts = []
        for i, page in enumerate(reader.pages):
            t = page.extract_text() or ""
            if t.strip():
                texts.append((t, {"page": i + 1}))
        return texts
    elif path.suffix.lower() in [".md", ".txt"]:
        try:
            txt = path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            log.error(f"Could not read {path}: {e}")
            return []
        return [(txt, {})]
    else:
        return []


def ingest(folder="docs"):
    init_db()
    model = SentenceTransformer(EMBEDDING_MODEL)
    conn = get_conn()
    cur = conn.cursor()

    docs_path = pathlib.Path(folder)
    if not docs_path.exists():
        log.error(f"Folder '{folder}' does not exist.")
        cur.close()
        conn.close()
        return

    files = [f for f in docs_path.rglob("*") if f.is_file() and f.suffix.lower() in [".pdf", ".md", ".txt"]]
    if not files:
        log.warning(f"No .pdf/.md/.txt files found in '{folder}'.")

    for file in files:
        try:
            log.info(f"Ingesting {file}...")
            pages = load_file(file)
            if not pages:
                log.warning(f"  -> skipped (no extractable text)")
                continue

            cur.execute("INSERT INTO documents (filename, filetype) VALUES (%s,%s) RETURNING id", (str(file), file.suffix))
            doc_id = cur.fetchone()[0]

            all_chunks = []
            for text, meta in pages:
                chunks = splitter.split_text(text)
                for ch in chunks:
                    all_chunks.append((ch, {**meta, "filename": str(file)}))

            if not all_chunks:
                log.warning(f"  -> no chunks produced, skipping")
                conn.rollback()
                continue

            log.info(f"  -> {len(all_chunks)} chunks")
            embeddings = model.encode([c[0] for c in all_chunks], show_progress_bar=True, batch_size=32)

            rows = [(doc_id, content, json.dumps(meta), emb.tolist())
                    for (content, meta), emb in zip(all_chunks, embeddings)]

            execute_values(cur, "INSERT INTO chunks (document_id, content, metadata, embedding) VALUES %s", rows)
            cur.execute("UPDATE documents SET total_chunks=%s WHERE id=%s", (len(rows), doc_id))
            conn.commit()
        except Exception as e:
            log.error(f"Failed to ingest {file}: {e}")
            conn.rollback()

    cur.close()
    conn.close()
    log.info("Ingestion done")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", default="docs")
    args = parser.parse_args()
    ingest(args.folder)
