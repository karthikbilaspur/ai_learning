import uuid
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .retrieval import hybrid_search
from .llm import generate_answer, stream_answer
from .db import get_conn, init_db, db_cursor
from .auth import require_api_key
from .config import CORS_ORIGINS, API_KEY
from .logging_conf import get_logger

log = get_logger(__name__)

app = FastAPI(title="Chat with Docs - pgvector RAG")

# CORS is now restricted to configured origins instead of "*".
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    question: str
    session_id: str | None = None
    filename_filter: str | None = None
    top_k: int = 8


@app.on_event("startup")
def startup():
    init_db()
    if not API_KEY:
        log.warning("API_KEY is not set - endpoints are UNAUTHENTICATED. Set API_KEY in .env for production.")


@app.get("/")
def health():
    return {
        "status": "ok",
        "db": "pgvector",
        "auth_enabled": bool(API_KEY),
        "features": ["hybrid_search", "reranking", "chat_history", "streaming", "api_key_auth"],
    }


def _load_history(cur, session_id):
    cur.execute(
        "SELECT role, content FROM chat_history WHERE session_id=%s ORDER BY id ASC LIMIT 20",
        (session_id,),
    )
    return [{"role": r[0], "content": r[1]} for r in cur.fetchall()]


def _save_turn(cur, session_id, question, answer):
    cur.execute(
        "INSERT INTO chat_history (session_id, role, content) VALUES (%s,%s,%s)",
        (session_id, "user", question),
    )
    cur.execute(
        "INSERT INTO chat_history (session_id, role, content) VALUES (%s,%s,%s)",
        (session_id, "assistant", str(answer)),
    )


@app.post("/chat", dependencies=[Depends(require_api_key)])
def chat(req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())

    try:
        with db_cursor(commit=True) as cur:
            history = _load_history(cur, session_id)
            chunks = hybrid_search(req.question, final_k=req.top_k, filename_filter=req.filename_filter)

            if not chunks:
                answer = "I couldn't find that in your documents."
            else:
                answer = generate_answer(chunks, req.question, chat_history=history)

            _save_turn(cur, session_id, req.question, answer)
    except Exception as e:
        log.error(f"/chat failed: {e}")
        raise HTTPException(status_code=500, detail="Something went wrong processing your question.")

    return {"session_id": session_id, "answer": answer, "sources": chunks}


@app.post("/chat/stream", dependencies=[Depends(require_api_key)])
def chat_stream(req: ChatRequest):
    """Server-Sent-Events endpoint: streams the answer token-by-token,
    then saves the full turn to chat history once generation completes."""
    session_id = req.session_id or str(uuid.uuid4())

    try:
        with db_cursor() as cur:
            history = _load_history(cur, session_id)
        chunks = hybrid_search(req.question, final_k=req.top_k, filename_filter=req.filename_filter)
    except Exception as e:
        log.error(f"/chat/stream setup failed: {e}")
        raise HTTPException(status_code=500, detail="Something went wrong preparing your answer.")

    def event_gen():
        collected = []
        yield f"event: session\ndata: {session_id}\n\n"

        if not chunks:
            msg = "I couldn't find that in your documents."
            collected.append(msg)
            yield f"data: {msg}\n\n"
        else:
            for piece in stream_answer(chunks, req.question, chat_history=history):
                collected.append(piece)
                # SSE requires newline-safe payloads
                safe = piece.replace("\n", "\\n")
                yield f"data: {safe}\n\n"

        full_answer = "".join(collected)
        try:
            with db_cursor(commit=True) as cur:
                _save_turn(cur, session_id, req.question, full_answer)
        except Exception as e:
            log.error(f"Failed to save chat history after stream: {e}")

        yield "event: done\ndata: [DONE]\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/documents", dependencies=[Depends(require_api_key)])
def list_docs():
    try:
        with db_cursor() as cur:
            cur.execute("SELECT id, filename, total_chunks, created_at FROM documents ORDER BY created_at DESC")
            rows = cur.fetchall()
    except Exception as e:
        log.error(f"/documents failed: {e}")
        raise HTTPException(status_code=500, detail="Could not list documents.")

    return [{"id": r[0], "filename": r[1], "chunks": r[2], "created_at": str(r[3])} for r in rows]


@app.delete("/documents/{doc_id}", dependencies=[Depends(require_api_key)])
def delete_doc(doc_id: int):
    try:
        with db_cursor(commit=True) as cur:
            cur.execute("SELECT id FROM documents WHERE id=%s", (doc_id,))
            if cur.fetchone() is None:
                raise HTTPException(status_code=404, detail=f"Document {doc_id} not found.")
            cur.execute("DELETE FROM documents WHERE id=%s", (doc_id,))
    except HTTPException:
        raise
    except Exception as e:
        log.error(f"delete_doc failed: {e}")
        raise HTTPException(status_code=500, detail="Could not delete document.")

    return {"deleted": doc_id}
