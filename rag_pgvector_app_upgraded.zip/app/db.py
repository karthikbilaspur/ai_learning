from contextlib import contextmanager
import psycopg2
from psycopg2.extras import execute_values
from pgvector.psycopg2 import register_vector
from .config import DATABASE_URL
from .logging_conf import get_logger

log = get_logger(__name__)


def get_conn():
    try:
        conn = psycopg2.connect(DATABASE_URL)
        register_vector(conn)
        return conn
    except psycopg2.OperationalError as e:
        log.error(f"Could not connect to database: {e}")
        raise


@contextmanager
def db_cursor(commit: bool = False):
    """Context manager that guarantees the connection/cursor are closed,
    and rolls back on error instead of leaving a dangling transaction."""
    conn = get_conn()
    cur = conn.cursor()
    try:
        yield cur
        if commit:
            conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def init_db():
    with db_cursor(commit=True) as cur:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        cur.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id SERIAL PRIMARY KEY,
                filename TEXT NOT NULL,
                filetype TEXT,
                total_chunks INT DEFAULT 0,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
        cur.execute('''
            CREATE TABLE IF NOT EXISTS chunks (
                id SERIAL PRIMARY KEY,
                document_id INT REFERENCES documents(id) ON DELETE CASCADE,
                content TEXT NOT NULL,
                metadata JSONB,
                embedding vector(384),
                tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', content)) STORED
            );
        ''')
        cur.execute("CREATE INDEX IF NOT EXISTS chunks_embedding_idx ON chunks USING hnsw (embedding vector_cosine_ops);")
        cur.execute("CREATE INDEX IF NOT EXISTS chunks_tsv_idx ON chunks USING GIN (tsv);")
        cur.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id SERIAL PRIMARY KEY,
                session_id TEXT,
                role TEXT,
                content TEXT,
                created_at TIMESTAMPTZ DEFAULT now()
            );
        ''')
    log.info("DB initialized")
