# Chat with my Documents - PostgreSQL + pgvector RAG (Upgraded v2)

Full RAG pipeline in Postgres: document ingestion, chunking, embeddings, vector storage, hybrid retrieval, reranking, and LLM generation, with a FastAPI backend and Streamlit chat UI.

### Features
- Hybrid Search: vector cosine + full-text (tsvector) fusion
- Reranking: cross-encoder/ms-marco-MiniLM-L-6-v2 for context selection
- Chat history stored in Postgres
- Metadata filtering (filter by filename)
- HNSW index for fast retrieval
- Streamlit UI + FastAPI backend
- Delete docs, list docs APIs

### New in this version
- **API key auth** — set `API_KEY` in `.env`; all endpoints require an `X-API-Key` header. Leave blank to disable for local dev.
- **CORS locked down** — was `allow_origins=["*"]`, now defaults to just the bundled Streamlit app (`CORS_ORIGINS` in `.env`).
- **Streaming answers** — new `POST /chat/stream` SSE endpoint; Streamlit UI streams tokens live (toggle in the sidebar).
- **Full Dockerization** — `Dockerfile.api` and `Dockerfile.streamlit` added; `docker-compose.yml` now runs Postgres + API + Streamlit together.
- **Error handling & logging** — DB/OpenAI calls wrapped in try/except with structured logging instead of silent failures; API returns proper HTTP error codes.
- **Bug fix** — the original hybrid-search filename filter had its SQL parameters in the wrong order (would have thrown/misfiltered); fixed and applied to both the vector and full-text queries.
- **Pinned dependencies** — `requirements.txt` now pins versions for reproducible installs; removed the invalid `cross-encoder` package (CrossEncoder ships inside `sentence-transformers`).
- **Streamlit UI polish** — delete-document button per row, clearer error messages when the API is unreachable.

### Quickstart (Docker, recommended)
1. `cp .env.example .env` and set `OPENAI_API_KEY` (or leave empty for mock mode) and a real `API_KEY`
2. `docker-compose up -d --build`
3. Put your PDFs/MD/TXT in `./docs/`
4. `docker-compose exec api python -m app.ingest --folder docs`
5. Open the UI at `http://localhost:8501`

### Quickstart (local, no Docker for app)
1. `docker-compose up -d db` (just the database)
2. `pip install -r requirements.txt`
3. `cp .env.example .env` and configure it
4. Put your PDFs/MD/TXT in `./docs/`
5. `python -m app.ingest --folder docs`
6. `uvicorn app.main:app --reload --port 8000`
7. In another terminal: `API_KEY=<same as .env> streamlit run streamlit_app.py`

### Auth
If `API_KEY` is set, every API call (from curl, Postman, or the Streamlit app) must include:
```
X-API-Key: <your key>
```
The bundled Streamlit app reads `API_KEY` from its own environment and attaches the header automatically.

### Architecture
```
docs/ -> app/ingest.py (RecursiveCharacterTextSplitter 800/150 overlap)
       -> all-MiniLM-L6-v2 embeddings -> Postgres pgvector
       -> hybrid_search (vector + tsv) -> reranker
       -> LLM (gpt-4o-mini, streaming or non-streaming)
       -> FastAPI (auth + CORS locked down)
       -> Streamlit (live token streaming)
```
All in PostgreSQL — no Pinecone/Qdrant needed.

### Still not done (see previous discussion for the full list)
No tests, no async DB driver, no rate limiting, no multi-tenancy, no per-file re-index endpoint yet — flagged here rather than silently left out.
