# Nimbus RAG Agent - Level 4 Enterprise

## Level 4 Upgrades over Level 2:
1. **Retriever:** Query rewriting + Semantic chunking + Hybrid (0.7 dense) + Cross-encoder reranker + Metadata filtering
2. **LLM:** Multi-model routing, semantic cache (Redis), PII masking (Presidio), prompt injection detection
3. **Agent:** LangGraph ReAct, 5 tools, conversation memory, tenant isolation
4. **Tracer:** Langfuse + OTEL + local JSON triple logging, cost attribution per tenant
5. **Eval:** 60 Qs (50 + 10 adversarial/unanswerable), RAGAS 5 metrics + hallucination_rate + cache_hit_rate + p95 latency
6. **API:** FastAPI /query endpoint, health
7. **Dashboard:** Streamlit with latency vs cost scatter, cache, hallucination
8. **CI:** GitHub Actions workflow runs eval on PR, fails if faithfulness < 0.8
9. **Security:** PII masking, injection check
10. **Deployment:** Dockerfile, docker-compose with Redis

## Run
pip install -r requirements_level4.txt
cp .env.example .env
python -m evals.run_eval
streamlit run dashboard_app.py
uvicorn api.main:app --reload

## Deliverable
/evals/traces/*.json + Langfuse Cloud traces
/evals/results/eval_results.csv, eval_summary.md, cost_report.md
/dashboard_app.py live cost dashboard
