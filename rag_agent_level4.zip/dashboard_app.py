import streamlit as st, pandas as pd, plotly.express as px, json
st.set_page_config(page_title="Nimbus Level 4 - Cost & Quality", layout="wide")
st.title("Level 4 - Enterprise RAG Agent Dashboard")
try:
    df = pd.read_csv("evals/results/eval_results.csv")
    with open("evals/results/eval_summary.md") as f: summary = f.read()
    col1,col2,col3,col4 = st.columns(4)
    col1.metric("Avg Latency", f"{df['latency_ms'].mean():.0f} ms")
    col2.metric("Avg Cost/Q", f"${df['cost'].mean():.5f}")
    col3.metric("Cost / 1k", f"${df['cost'].mean()*1000:.2f}")
    col4.metric("Total Qs", len(df))
    fig = px.scatter(df, x="latency_ms", y="cost", color="route", hover_data=["question"])
    st.plotly_chart(fig, use_container_width=True)
    st.dataframe(df)
    st.markdown(summary)
except Exception as e:
    st.error(f"Run eval first: {e}")
