# LEVEL 4 TRACER: Langfuse + OpenTelemetry + Cost Attribution
from langfuse import Langfuse
from langfuse.decorators import observe
import os, json, time, uuid

langfuse = Langfuse(
    public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
    secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
    host=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com")
)

class Level4Tracer:
    def __init__(self, log_dir="evals/traces"):
        self.log_dir = log_dir
        os.makedirs(log_dir, exist_ok=True)

    def log(self, trace_id, data):
        # 1. Local JSON (Level 1 compatibility)
        with open(os.path.join(self.log_dir, f"{trace_id}.json"), "w") as f:
            json.dump(data, f, indent=2)
        # 2. Langfuse is auto-logged via @observe decorators
        # 3. In Level 4: also push to OTEL collector for Grafana
        return trace_id

    def new_trace_id(self):
        return f"trace_{uuid.uuid4().hex[:8]}"
