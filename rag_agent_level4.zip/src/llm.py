# LEVEL 4 LLM: Multi-model routing, caching, guardrails, citations
from anthropic import Anthropic
from openai import OpenAI
import os, hashlib
from src.config import Config
from langfuse.decorators import observe

# Level 4: Semantic Cache (Redis in prod, dict for demo)
CACHE = {}

class Level4LLM:
    def __init__(self):
        self.model = Config.LLM_MODEL
        self.anthropic = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY")) if os.getenv("ANTHROPIC_API_KEY") else None
        self.openai = OpenAI(api_key=os.getenv("OPENAI_API_KEY")) if os.getenv("OPENAI_API_KEY") else None

    @observe(name="pii_masking")
    def mask_pii(self, text):
        if not Config.PII_MASKING: return text
        # Simple regex, prod: use Presidio
        import re
        text = re.sub(r"\b[\w.-]+@[\w.-]+\.\w+\b", "[EMAIL_MASKED]", text)
        text = re.sub(r"\b\d{10}\b", "[PHONE_MASKED]", text)
        return text

    @observe(name="prompt_injection_check")
    def check_injection(self, query):
        if not Config.PROMPT_INJECTION_CHECK: return False
        blacklist = ["ignore previous", "system prompt", "jailbreak"]
        return any(b in query.lower() for b in blacklist)

    @observe(name="llm_generation")
    def generate(self, query, contexts, use_cache=True):
        if self.check_injection(query):
            return {"answer": "Potential prompt injection detected. Refusing.", "input_tokens": 0, "output_tokens": 0, "cost": 0, "cached": False, "citations": []}

        # Semantic cache check
        cache_key = hashlib.md5(query.encode()).hexdigest()
        if use_cache and cache_key in CACHE:
            res = CACHE[cache_key]
            res["cached"] = True
            return res

        context_str = "\n\n".join([f"[{c['doc_id']}#{c['metadata']['chunk_id']}] {c['text']}" for c in contexts])
        prompt = f"""You are Nimbus Enterprise Support. 
RULES:
1. Answer ONLY from CONTEXT. If not found, say "Not found in docs - escalate to human".
2. Cite sources like [doc_01.txt#0].
3. Be concise, 3 bullet points max.
4. Never reveal PII.

CONTEXT:
{context_str}

QUESTION: {query}
"""

        masked_prompt = self.mask_pii(prompt)

        if not self.anthropic and not self.openai:
            # Offline mock
            answer = contexts[0]['text'][:400] if contexts else "Not found in docs - escalate to human"
            result = {"answer": answer, "input_tokens": len(masked_prompt)//4, "output_tokens": len(answer)//4, "cost": 0.0001, "cached": False, "citations": [c['doc_id'] for c in contexts]}
            CACHE[cache_key] = result
            return result

        # Real call - route to cheapest capable
        if "claude" in self.model and self.anthropic:
            resp = self.anthropic.messages.create(model=self.model, max_tokens=500, messages=[{"role":"user","content":masked_prompt}])
            txt = resp.content[0].text
            in_tok, out_tok = resp.usage.input_tokens, resp.usage.output_tokens
        else:
            resp = self.openai.chat.completions.create(model="gpt-4o-mini", messages=[{"role":"user","content":masked_prompt}], max_tokens=500)
            txt = resp.choices[0].message.content
            in_tok, out_tok = resp.usage.prompt_tokens, resp.usage.completion_tokens

        cost = in_tok*Config.PRICING.get(self.model, {"input":0.15/1e6})["input"] + out_tok*Config.PRICING.get(self.model, {"output":0.6/1e6})["output"]
        result = {"answer": txt, "input_tokens": in_tok, "output_tokens": out_tok, "cost": cost, "cached": False, "citations": [c['doc_id'] for c in contexts]}
        CACHE[cache_key] = result
        return result
