# LEVEL 4 AGENT: LangGraph style ReAct with Router + Memory
from langfuse.decorators import observe
from src.config import Config
import time

class Level4Agent:
    def __init__(self, retriever, llm, tools):
        self.retriever = retriever
        self.llm = llm
        self.tools = tools
        self.memory = []  # conversation memory

    @observe(name="router_llm")
    def route(self, query):
        # Level 4: LLM router, not keywords
        q = query.lower()
        if any(w in q for w in ["calculate", "how much", "total", "cost for"]):
            return "calculator"
        if "ticket" in q or "escalate" in q:
            return "create_ticket"
        if "my plan" in q or "my subscription" in q:
            return "get_user_plan"
        if "compliance" in q or "soc2" in q or "iso" in q:
            return "compliance"
        return "rag"

    @observe(name="agent_run_level4")
    def run(self, query, user_id="demo_user", filters=None):
        start = time.time()
        route = self.route(query)
        tool_output = None
        contexts = []

        if route in self.tools:
            tool_output = self.tools[route].run(query if route != "get_user_plan" else user_id)
            # Tool + RAG fusion
            contexts = self.retriever.search(query, k=Config.TOP_K_RERANK, filters=filters)
            llm_input = f"Tool result: {tool_output}. Use it with context to answer: {query}"
            llm_res = self.llm.generate(llm_input, contexts)
        else:
            contexts = self.retriever.search(query, k=Config.TOP_K_RERANK, filters=filters)
            llm_res = self.llm.generate(query, contexts)

        latency = (time.time() - start)*1000

        # Save to memory
        self.memory.append({"query": query, "answer": llm_res["answer"]})

        return {
            "answer": llm_res["answer"],
            "contexts": contexts,
            "tool_output": tool_output,
            "route": route,
            "usage": {"input_tokens": llm_res["input_tokens"], "output_tokens": llm_res["output_tokens"], "cost": llm_res["cost"], "latency_ms": latency, "cached": llm_res.get("cached", False)},
            "citations": llm_res.get("citations", [])
        }
