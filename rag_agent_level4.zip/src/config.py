import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    # Models
    ROUTER_MODEL = "gpt-4o-mini"
    RETRIEVAL_MODEL = "all-MiniLM-L6-v2"
    RERANKER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    LLM_MODEL = os.getenv("LLM_MODEL", "claude-3-5-haiku-20241022")
    JUDGE_MODEL = "gpt-4o-mini"

    # Retrieval
    CHUNK_SIZE = 500
    CHUNK_OVERLAP = 100
    TOP_K_RETRIEVAL = 20
    TOP_K_RERANK = 3
    HYBRID_ALPHA = 0.7  # dense weight

    # Tracing
    LANGFUSE_ENABLED = True
    OTEL_ENABLED = True

    # Cost
    PRICING = {
        "claude-3-5-haiku-20241022": {"input": 0.25/1e6, "output": 1.25/1e6},
        "gpt-4o-mini": {"input": 0.15/1e6, "output": 0.60/1e6},
        "all-MiniLM-L6-v2": {"input": 0.0},
        "reranker": {"input": 0.0}
    }

    # Level 4: Multi-tenant, cache, guardrails
    SEMANTIC_CACHE_THRESHOLD = 0.92
    PII_MASKING = True
    PROMPT_INJECTION_CHECK = True
