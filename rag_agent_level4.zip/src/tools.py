# LEVEL 4: 5 tools with Langfuse tracing
from langfuse.decorators import observe
import re

class CalculatorTool:
    @observe(name="tool_calculator")
    def run(self, query):
        # Extract "29*5*0.8"
        expr = re.findall(r"[0-9\*\+\-\/\.\(\)\%]+", query)
        if not expr: return "No math found"
        try:
            # Safe eval
            result = eval(expr[0], {"__builtins__": {}})
            return f"Result: {result}"
        except Exception as e:
            return f"Calc error: {e}"

class TicketTool:
    @observe(name="tool_create_ticket")
    def run(self, query):
        return f"Ticket created for: {query[:50]} - ID TICKET-{hash(query)%10000}"

class UserPlanTool:
    @observe(name="tool_get_user_plan")
    def run(self, user_id="demo_user"):
        return "User is on Pro plan $29, 5 seats, 20% discount"

class ComplianceTool:
    @observe(name="tool_compliance_check")
    def run(self, query):
        return "SOC2 valid till Dec 2026, ISO27001 till June 2027 - compliant"

TOOLS = {
    "calculator": CalculatorTool(),
    "create_ticket": TicketTool(),
    "get_user_plan": UserPlanTool(),
    "compliance": ComplianceTool()
}
