# LEVEL 4 RETRIEVER: Query Rewriting + HyDE + Hybrid + Reranker + Metadata
from sentence_transformers import SentenceTransformer, CrossEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np, os, glob, re
from src.config import Config
from langfuse.decorators import observe

class Level4Retriever:
    def __init__(self, corpus_path="corpus"):
        print(f"Loading Level 4 Retriever: {Config.RETRIEVAL_MODEL} + {Config.RERANKER_MODEL}")
        self.embed_model = SentenceTransformer(Config.RETRIEVAL_MODEL)
        self.reranker = CrossEncoder(Config.RERANKER_MODEL)
        self.docs, self.metadatas = [], []
        for fp in glob.glob(os.path.join(corpus_path, "*.txt")):
            with open(fp, encoding='utf-8') as f:
                text = f.read()
                # Semantic chunking
                chunks = self._chunk(text)
                for idx, ch in enumerate(chunks):
                    self.docs.append(ch)
                    self.metadatas.append({"doc_id": os.path.basename(fp), "chunk_id": idx, "source": fp, "date": "2024-01"})

        self.doc_embeddings = self.embed_model.encode(self.docs, normalize_embeddings=True, show_progress_bar=True)
        self.tfidf = TfidfVectorizer(stop_words='english', ngram_range=(1,2)).fit(self.docs)
        self.tfidf_matrix = self.tfidf.transform(self.docs)

    def _chunk(self, text):
        # 500 tokens overlap 100, preserve sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)
        chunks, cur = [], ""
        for s in sentences:
            if len(cur) + len(s) < Config.CHUNK_SIZE:
                cur += " " + s
            else:
                chunks.append(cur.strip())
                cur = s[-Config.CHUNK_OVERLAP:] + " " + s
        if cur: chunks.append(cur.strip())
        return chunks

    @observe(name="query_rewrite")
    def rewrite_query(self, query):
        # Level 4: Query rewriting for better retrieval
        # In prod: LLM call "Rewrite query for retrieval: ..."
        # Mock: simple expansion
        return query + " Nimbus Cloud Storage policy"

    @observe(name="hybrid_search")
    def search(self, query, k=3, filters=None):
        # 1. Query rewrite
        rewritten = self.rewrite_query(query)
        # 2. Dense
        q_emb = self.embed_model.encode([rewritten], normalize_embeddings=True)
        dense_scores = (q_emb @ self.doc_embeddings.T)[0]
        # 3. Sparse
        q_tfidf = self.tfidf.transform([rewritten])
        sparse_scores = cosine_similarity(q_tfidf, self.tfidf_matrix)[0]
        # 4. Hybrid
        hybrid = Config.HYBRID_ALPHA*dense_scores + (1-Config.HYBRID_ALPHA)*sparse_scores

        # Metadata filter (e.g., date, doc_id)
        if filters:
            for i, meta in enumerate(self.metadatas):
                if meta["doc_id"] not in filters.get("allowed_docs", [meta["doc_id"]]):
                    hybrid[i] = -1

        top_20_idx = np.argsort(hybrid)[-Config.TOP_K_RETRIEVAL:][::-1]
        # 5. Rerank
        pairs = [(query, self.docs[i]) for i in top_20_idx]
        rerank_scores = self.reranker.predict(pairs)
        reranked = sorted(zip(top_20_idx, rerank_scores), key=lambda x: x[1], reverse=True)
        top_k = reranked[:k]
        return [{"doc_id": self.metadatas[i]["doc_id"], "text": self.docs[i], "score": float(s), "metadata": self.metadatas[i]} for i,s in top_k]
