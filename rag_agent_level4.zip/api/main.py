# LEVEL 4: FastAPI production endpoint
from fastapi import FastAPI
from pydantic import BaseModel
from src.retriever import Level4Retriever
from src.llm import Level4LLM
from src.agent import Level4Agent
from src.tools import TOOLS
from src.tracer import Level4Tracer

app = FastAPI(title="Nimbus RAG Agent Level 4")
retriever = Level4Retriever()
llm = Level4LLM()
agent = Level4Agent(retriever, llm, TOOLS)
tracer = Level4Tracer()

class QueryReq(BaseModel):
    question: str
    user_id: str = "demo_user"
    tenant_id: str = "tenant_1"

@app.post("/query")
def query(req: QueryReq):
    result = agent.run(req.question, user_id=req.user_id)
    trace_id = tracer.new_trace_id()
    tracer.log(trace_id, {"query": req.question, "result": result, "tenant": req.tenant_id})
    return {"trace_id": trace_id, **result}

@app.get("/health")
def health():
    return {"status": "ok", "level": 4}
