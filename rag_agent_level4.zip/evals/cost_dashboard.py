import pandas as pd, plotly.express as px, json
# Level 4 dashboard aggregates Langfuse data
df = pd.read_csv("evals/results/eval_results.csv")
print(df.describe())
# For Streamlit, see dashboard_app.py
