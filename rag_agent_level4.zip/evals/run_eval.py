import json, time, os, sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from src.retriever import Level4Retriever
from src.llm import Level4LLM
from src.agent import Level4Agent
from src.tools import TOOLS
from src.tracer import Level4Tracer
from evals.metrics import evaluate_level4
import csv

retriever = Level4Retriever()
llm = Level4LLM()
agent = Level4Agent(retriever, llm, TOOLS)
tracer = Level4Tracer()

with open("evals/eval_questions.json") as f:
    questions = json.load(f)

results = []
for q in questions:
    start = time.time()
    res = agent.run(q["question"])
    latency = (time.time()-start)*1000
    trace_id = tracer.new_trace_id()
    tracer.log(trace_id, {"question": q["question"], "answer": res["answer"], "contexts": res["contexts"], "route": res["route"], "usage": res["usage"]})

    results.append({
        "id": q["id"],
        "question": q["question"],
        "answer": res["answer"],
        "contexts": res["contexts"],
        "ground_truth": q["ground_truth_doc_id"],
        "expected_keywords": q["expected_keywords"][0],
        "route": res["route"],
        "latency_ms": latency,
        "cost": res["usage"]["cost"],
        "cached": res["usage"].get("cached", False),
        "total_tokens": res["usage"]["input_tokens"] + res["usage"]["output_tokens"]
    })
    print(f"{q['id']}/60 done - route:{res['route']} cost:{res['usage']['cost']:.5f}")

scores = evaluate_level4(results)

# Save
os.makedirs("evals/results", exist_ok=True)
with open("evals/results/eval_results.csv","w",newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f, fieldnames=["id","question","route","latency_ms","cost","total_tokens"])
    w.writeheader()
    for r in results:
        w.writerow({k:r[k] for k in ["id","question","route","latency_ms","cost","total_tokens"]})

with open("evals/results/eval_summary.md","w") as f:
    f.write(f"# Level 4 Eval Summary\n\nScores: {scores}\n\nTotal: {len(results)} Qs\n")

with open("evals/results/cost_report.md","w") as f:
    avg_cost = sum([r["cost"] for r in results])/len(results)
    f.write(f"# Cost Report Level 4\nAvg cost/query: ${avg_cost:.5f}\nCost/1k: ${avg_cost*1000:.2f}\nCache hit: {scores.get('cache_hit_rate',0):.2%}\nHallucination: {scores.get('hallucination_rate',0):.2%}\n")

print("Eval done", scores)
