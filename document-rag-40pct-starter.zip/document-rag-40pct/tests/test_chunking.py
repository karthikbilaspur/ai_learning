from app.chunking import chunk_pages
from app.models import TextPage

def test_chunking_produces_multiple_chunks():
    pages = [TextPage(text="A" * 2000)]
    chunks = chunk_pages(pages, chunk_size=500, overlap=100)

    assert len(chunks) > 1
    assert chunks[0].chunk_index == 0
    assert chunks[1].chunk_index == 1

def test_page_metadata_is_preserved():
    pages = [TextPage(text="hello world", page_number=7)]
    chunks = chunk_pages(pages, chunk_size=100)

    assert chunks[0].page_number == 7
