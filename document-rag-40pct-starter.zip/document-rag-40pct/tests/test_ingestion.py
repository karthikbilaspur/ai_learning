from pathlib import Path
from app.ingestion import load_file

def test_text_file(tmp_path: Path):
    path = tmp_path / "notes.txt"
    path.write_text("hello rag", encoding="utf-8")

    pages = load_file(path)

    assert len(pages) == 1
    assert pages[0].text == "hello rag"
