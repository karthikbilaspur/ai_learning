# Document RAG — ~40% Starter

A small, deliberately understandable implementation of the first ~40% of a "Chat with my documents" RAG system.

## Included
- PDF / Markdown / TXT ingestion
- Page-aware PDF extraction
- Basic chunking with overlap
- Local sentence-transformer embeddings
- PostgreSQL + pgvector storage
- Vector similarity retrieval
- Metadata and source tracking
- Simple CLI
- Docker Compose for PostgreSQL + pgvector

## Not included yet
- Cross-encoder reranking
- Advanced context selection / token budgeting
- LLM answer generation
- Citation-aware answer formatting
- Hybrid BM25 + vector retrieval
- Evaluation metrics
- Web UI

## Run it

1. Start the database:
```bash
docker compose up -d
```

2. Create a virtual environment and install:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

3. Copy `.env.example` to `.env` if you want to customize settings.

4. Put `.pdf`, `.md`, or `.txt` files in `data/documents/`.

5. Ingest:
```bash
python -m app.cli ingest data/documents
```

6. Search:
```bash
python -m app.cli search "Why is connection pooling used?"
```

The first embedding run downloads the local `all-MiniLM-L6-v2` model.

## Pipeline

file → text extraction → chunks → embeddings → PostgreSQL/pgvector → top-K retrieval

## Suggested next steps
1. Retrieve top 20 and add a cross-encoder reranker.
2. Select the best 3–5 chunks with duplicate removal and token budgeting.
3. Add an LLM generation layer.
4. Return page/file citations from chunk metadata.
5. Create 20–30 evaluation questions and measure Recall@5 / MRR.
6. Add a Streamlit UI.
