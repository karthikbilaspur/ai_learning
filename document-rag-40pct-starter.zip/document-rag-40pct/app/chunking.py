import re
from app.models import Chunk, TextPage

def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

def chunk_pages(
    pages: list[TextPage],
    chunk_size: int = 900,
    overlap: int = 150,
) -> list[Chunk]:
    """Simple character-based baseline chunker."""
    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    chunks = []
    chunk_index = 0

    for page in pages:
        text = normalize_text(page.text)
        if not text:
            continue

        start = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))

            if end < len(text):
                boundary = text.rfind("\n\n", start, end)
                if boundary > start + chunk_size // 2:
                    end = boundary

            content = text[start:end].strip()
            if content:
                chunks.append(
                    Chunk(
                        content=content,
                        chunk_index=chunk_index,
                        page_number=page.page_number,
                        metadata=page.metadata.copy(),
                    )
                )
                chunk_index += 1

            if end >= len(text):
                break
            start = max(0, end - overlap)

    return chunks
