from pathlib import Path
from app.chunking import chunk_pages
from app.db import insert_document, search_chunks, sha256_file
from app.embeddings import embed_query, embed_texts
from app.ingestion import load_file

def ingest(path: Path) -> int:
    pages = load_file(path)
    chunks = chunk_pages(pages, chunk_size=900, overlap=150)

    if not chunks:
        raise ValueError(f"No extractable text found in {path}")

    embeddings = embed_texts([chunk.content for chunk in chunks])

    return insert_document(
        filename=path.name,
        file_hash=sha256_file(path),
        chunks=chunks,
        embeddings=embeddings,
    )

def retrieve(question: str, top_k: int = 5) -> list[dict]:
    return search_chunks(embed_query(question), limit=top_k)
