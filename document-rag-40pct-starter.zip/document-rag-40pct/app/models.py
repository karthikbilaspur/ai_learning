from dataclasses import dataclass, field

@dataclass
class TextPage:
    text: str
    page_number: int | None = None
    metadata: dict = field(default_factory=dict)

@dataclass
class Chunk:
    content: str
    chunk_index: int
    page_number: int | None
    metadata: dict = field(default_factory=dict)
