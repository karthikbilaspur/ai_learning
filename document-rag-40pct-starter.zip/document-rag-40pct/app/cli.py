import argparse
from pathlib import Path
from app.pipeline import ingest, retrieve

def cmd_ingest(directory: Path):
    paths = [
        p for p in directory.rglob("*")
        if p.is_file() and p.suffix.lower() in {".pdf", ".md", ".txt"}
    ]

    if not paths:
        print("No PDF, Markdown, or TXT files found.")
        return

    for path in paths:
        print(f"\nIngesting: {path}")
        document_id = ingest(path)
        print(f"Stored as document id: {document_id}")

def cmd_search(question: str, top_k: int):
    results = retrieve(question, top_k=top_k)

    if not results:
        print("No results.")
        return

    print("\nRetrieved context:\n")
    for rank, result in enumerate(results, start=1):
        page = (
            f", page {result['page_number']}"
            if result["page_number"] is not None else ""
        )
        print(
            f"[{rank}] {result['filename']}{page} "
            f"(similarity={result['similarity']:.4f})"
        )
        print(result["content"])
        print("-" * 80)

def main():
    parser = argparse.ArgumentParser(
        description="Small PostgreSQL/pgvector RAG starter"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    ingest_parser = sub.add_parser("ingest")
    ingest_parser.add_argument("directory", type=Path)

    search_parser = sub.add_parser("search")
    search_parser.add_argument("question")
    search_parser.add_argument("--top-k", type=int, default=5)

    args = parser.parse_args()

    if args.command == "ingest":
        cmd_ingest(args.directory)
    elif args.command == "search":
        cmd_search(args.question, args.top_k)

if __name__ == "__main__":
    main()
