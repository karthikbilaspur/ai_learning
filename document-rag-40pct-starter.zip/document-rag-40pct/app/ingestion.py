from pathlib import Path
from pypdf import PdfReader
from app.models import TextPage

SUPPORTED = {".pdf", ".md", ".txt"}

def load_file(path: Path) -> list[TextPage]:
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED:
        raise ValueError(f"Unsupported file type: {suffix}")

    if suffix == ".pdf":
        return _load_pdf(path)

    text = path.read_text(encoding="utf-8", errors="replace")
    return [TextPage(text=text, metadata={"source": path.name})]

def _load_pdf(path: Path) -> list[TextPage]:
    reader = PdfReader(str(path))
    pages = []

    for number, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        if text.strip():
            pages.append(
                TextPage(
                    text=text,
                    page_number=number,
                    metadata={"source": path.name, "page": number},
                )
            )
    return pages
