import hashlib
import json
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
from app.config import settings
from app.models import Chunk

def get_connection():
    return psycopg.connect(settings.database_url)

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def insert_document(filename, file_hash, chunks, embeddings):
    if len(chunks) != len(embeddings):
        raise ValueError("chunks and embeddings must have the same length")

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO documents (filename, file_hash)
                VALUES (%s, %s)
                ON CONFLICT (file_hash)
                DO UPDATE SET filename = EXCLUDED.filename
                RETURNING id
                """,
                (filename, file_hash),
            )
            document_id = cur.fetchone()[0]

            cur.execute(
                "DELETE FROM chunks WHERE document_id = %s",
                (document_id,),
            )

            for chunk, embedding in zip(chunks, embeddings):
                cur.execute(
                    """
                    INSERT INTO chunks (
                        document_id, chunk_index, content,
                        page_number, metadata, embedding
                    )
                    VALUES (%s, %s, %s, %s, %s, %s::vector)
                    """,
                    (
                        document_id,
                        chunk.chunk_index,
                        chunk.content,
                        chunk.page_number,
                        json.dumps(chunk.metadata),
                        str(embedding),
                    ),
                )
    return document_id

def search_chunks(query_embedding: list[float], limit: int = 5) -> list[dict]:
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT
                    c.id,
                    d.filename,
                    c.content,
                    c.page_number,
                    c.metadata,
                    1 - (c.embedding <=> %s::vector) AS similarity
                FROM chunks c
                JOIN documents d ON d.id = c.document_id
                ORDER BY c.embedding <=> %s::vector
                LIMIT %s
                """,
                (str(query_embedding), str(query_embedding), limit),
            )
            return cur.fetchall()
