
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from resilient_agent import ResilientAgent, AgentConfig
import logging

app = FastAPI(title="Resilient AI Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class RunRequest(BaseModel):
    input: str
    attack: str | None = None

@app.post("/run")
def run_agent(req: RunRequest):
    config = AgentConfig(max_iterations=5, max_retries=3, tool_timeout=2)
    agent = ResilientAgent(config)
    result = agent.run(req.input)
    return result

@app.get("/attacks")
def list_attacks():
    return ["tool_failure","invalid_args","api_timeout","hallucinated_tool","infinite_loop","malicious_input","unexpected_output"]

@app.get("/")
def root():
    return {"status": "Resilient Agent API running"}
