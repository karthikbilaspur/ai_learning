
# RESILIENT AI AGENT - Due 24th

Full-stack implementation that BREAKS and FIXES an AI agent.

## Structure
```
RESILIENT AI AGENT
├── 1. Dashboard (Health, Tests, Run All)
├── 2. Attack Lab (7 attacks)
├── 3. Agent Monitor (Live logs, iterations)
└── 4. Test Reports (Before vs After, charts)
```

## Backend (Python)
- `backend/resilient_agent.py` - core resilient agent with:
  - Tool failures, Invalid args, Timeouts, Hallucinated tools, Infinite loops, Malicious inputs, Unexpected outputs
  - Retries with exponential backoff + jitter
  - Validation (allowlist, schema, malicious patterns)
  - Timeouts via ThreadPoolExecutor
  - Logging + max iterations + loop detection

Run backend:
```
cd backend
pip install -r requirements.txt
python resilient_agent.py          # runs break tests
uvicorn main:app --reload          # runs API on :8000
```

## Frontend (React)
- Vite + React + Tailwind + Recharts + Lucide

Run frontend:
```
cd frontend
npm install
npm run dev   # http://localhost:5173
```

## Quick Start (both)
```
chmod +x run.sh
./run.sh
```

## For submission
- Single file: backend/resilient_agent.py
- Full demo: frontend dashboard + backend API
