import os
import logging
from typing import Optional
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

class LLMClient:
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini"):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("OPENAI_API_KEY not set - running in mock mode")
        self.model = model
        self._client = None
        if OPENAI_AVAILABLE and self.api_key:
            self._client = OpenAI(api_key=self.api_key)

    def query(self, prompt: str) -> str:
        if self._client:
            try:
                resp = self._client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.3,
                    max_tokens=800
                )
                return resp.choices[0].message.content
            except Exception as e:
                logger.error(f"OpenAI call failed: {e}")
                return f"[LLM Error] {e}"
        return f"[MOCK] Response to: {prompt[:300]}..."
