# research_agent_v2 - Improved

Improvements:
1. No hardcoded API keys
2. Query sanitization
3. Context managers
4. Logging
5. Mock fallback

Run:
 pip install -r requirements.txt
 cp .env.example .env
 python setup_data.py
 python main.py
