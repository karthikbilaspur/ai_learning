import sqlite3
import logging
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

def read_db_note(db_path: str, note_id: int) -> Optional[str]:
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT content FROM notes WHERE id = ?", (note_id,))
            row = cur.fetchone()
            return row["content"] if row else None
    except sqlite3.Error as e:
        logger.error(f"DB read error: {e}")
        return None

def list_notes(db_path: str, limit: int = 10) -> List[Dict]:
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute("SELECT id, content FROM notes ORDER BY id DESC LIMIT ?", (limit,))
            return [dict(r) for r in cur.fetchall()]
    except sqlite3.Error as e:
        logger.error(f"DB list error: {e}")
        return []

def init_db_if_not_exists(db_path: str):
    with sqlite3.connect(db_path) as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
