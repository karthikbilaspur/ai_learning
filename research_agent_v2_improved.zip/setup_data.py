import os
import sqlite3
import logging
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

def init_db(db_path: str = "data/research.db", seed_files_dir: str = "data/docs"):
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        cur = conn.cursor()
        cur.execute("DROP TABLE IF EXISTS notes")
        cur.execute("""
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                source_file TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        if os.path.exists(seed_files_dir):
            for fname in os.listdir(seed_files_dir):
                if fname.endswith(".txt"):
                    fpath = os.path.join(seed_files_dir, fname)
                    try:
                        with open(fpath, "r", encoding="utf-8") as f:
                            content = f.read().strip()
                            if content:
                                cur.execute("INSERT INTO notes (content, source_file) VALUES (?, ?)", (content, fname))
                                logger.info(f"Seeded {fname}")
                    except Exception as e:
                        logger.warning(f"Failed to seed {fname}: {e}")
        conn.commit()
    logger.info(f"DB initialized at {db_path}")

if __name__ == "__main__":
    init_db()
