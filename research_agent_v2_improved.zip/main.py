import os
import logging
from dotenv import load_dotenv
from llm_client import LLMClient
from agent import ResearchAgent
from tools import init_db_if_not_exists

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

def main():
    db_path = os.getenv("DB_PATH", "data/research.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    init_db_if_not_exists(db_path)

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Warning: OPENAI_API_KEY not set in .env - using mock mode")
    
    client = LLMClient(api_key=api_key, model=os.getenv("MODEL", "gpt-4o-mini"))
    agent = ResearchAgent(llm_client=client, db_path=db_path)

    query = input("Enter research query: ")
    result = agent.run(query)
    print("\n--- Result ---\n")
    print(result)

if __name__ == "__main__":
    main()
