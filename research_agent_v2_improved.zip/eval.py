import logging
from typing import List, Dict
from agent import ResearchAgent

logger = logging.getLogger(__name__)

def evaluate_agent(agent: ResearchAgent, test_dataset: List[Dict]) -> Dict:
    passed = 0
    results = []
    for test in test_dataset:
        prompt = test.get("prompt", "")
        expected = test.get("expected")
        expected_contains = test.get("expected_contains")
        output = agent.run(prompt)
        if expected is not None:
            ok = output.strip() == expected.strip()
        elif expected_contains is not None:
            ok = expected_contains.lower() in output.lower()
        else:
            ok = len(output) > 0
        if ok:
            passed += 1
        results.append({"prompt": prompt, "output": output, "pass": ok})
    accuracy = passed / len(test_dataset) if test_dataset else 0
    logger.info(f"Eval: {passed}/{len(test_dataset)} passed - Accuracy: {accuracy:.2%}")
    return {"accuracy": accuracy, "passed": passed, "total": len(test_dataset), "details": results}
