# Chat with my Documents - PostgreSQL + pgvector RAG (Upgraded)

This zip contains full production-ready code combining:
1. Document ingestion, chunking, embeddings, vector storage, retrieval, reranking, LLM generation
2. Chat with my documents app

### Upgrades in this version:
- Hybrid Search: vector cosine + full-text (tsvector) fusion
- Reranking: cross-encoder/ms-marco-MiniLM-L-6-v2 for context selection
- Chat history stored in Postgres
- Metadata filtering (filter by filename)
- HNSW index (not IVFFlat) for fast retrieval
- Streamlit UI + FastAPI backend
- Delete docs, list docs APIs

### Quickstart
1. docker-compose up -d
2. pip install -r requirements.txt
3. cp .env.example .env and set OPENAI_API_KEY (or leave empty for mock mode)
4. Put your PDFs/MD/TXT in ./docs/
5. python -m app.ingest --folder docs
6. uvicorn app.main:app --reload --port 8000
7. In another terminal: streamlit run streamlit_app.py

### Architecture
docs/ -> app/ingest.py (RecursiveCharacterTextSplitter 800/150 overlap) -> all-MiniLM-L6-v2 embeddings -> Postgres pgvector -> hybrid_search (vector + tsv) -> reranker -> LLM (gpt-4o-mini) -> FastAPI -> Streamlit

All in PostgreSQL, no Pinecone/Qdrant needed.
