import streamlit as st
import requests

API = "http://localhost:8000"

st.set_page_config(page_title="Chat with my Docs - pgvector", layout="wide")
st.title("📄 Chat with my documents (PostgreSQL + pgvector)")

with st.sidebar:
    st.header("Controls")
    filter_file = st.text_input("Filter by filename (optional)")
    top_k = st.slider("Context chunks (final after reranking)", 3, 15, 8)
    st.markdown("---")
    st.write("Documents in DB:")
    try:
        docs = requests.get(f"{API}/documents").json()
        for d in docs:
            st.caption(f"{d['filename']} - {d['chunks']} chunks")
    except:
        st.warning("API not running")

if "session_id" not in st.session_state:
    st.session_state.session_id = None
if "messages" not in st.session_state:
    st.session_state.messages = []

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

q = st.chat_input("Ask about your docs...")
if q:
    st.session_state.messages.append({"role":"user","content": q})
    with st.chat_message("user"):
        st.markdown(q)
    
    with st.chat_message("assistant"):
        with st.spinner("Searching + reranking..."):
            payload = {"question": q, "session_id": st.session_state.session_id, "filename_filter": filter_file, "top_k": top_k}
            res = requests.post(f"{API}/chat", json=payload).json()
            st.session_state.session_id = res["session_id"]
            st.markdown(res["answer"])
            st.markdown("---")
            st.subheader("Sources (reranked)")
            for s in res["sources"]:
                with st.expander(f"Chunk {s['id']} | score {s.get('rerank_score',0):.3f} | {s['metadata'].get('filename')} p{ s['metadata'].get('page','-') }"):
                    st.write(s["content"])
                    st.json(s["metadata"])
            st.session_state.messages.append({"role":"assistant","content": res["answer"]})
