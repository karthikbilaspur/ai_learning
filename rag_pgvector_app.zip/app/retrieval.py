from .db import get_conn
from .config import EMBEDDING_MODEL
from sentence_transformers import SentenceTransformer, CrossEncoder
import json

_embed_model = None
_reranker = None

def get_embed_model():
    global _embed_model
    if _embed_model is None:
        _embed_model = SentenceTransformer(EMBEDDING_MODEL)
    return _embed_model

def get_reranker():
    global _reranker
    if _reranker is None:
        _reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
    return _reranker

def hybrid_search(query: str, top_k=50, final_k=8, filename_filter=None):
    model = get_embed_model()
    q_emb = model.encode(query).tolist()
    
    conn = get_conn()
    cur = conn.cursor()
    
    # Vector search + optional filter
    filter_sql = ""
    params = [q_emb]
    if filename_filter:
        filter_sql = "WHERE metadata->>'filename' ILIKE %s"
        params.append(f"%{filename_filter}%")
        params.append(q_emb)
        # actually need to adjust order
        cur.execute(f'''
            SELECT id, content, metadata, 1 - (embedding <=> %s) as score
            FROM chunks
            {filter_sql}
            ORDER BY embedding <=> %s
            LIMIT %s
        ''', (q_emb, f"%{filename_filter}%", top_k))
    else:
        cur.execute('''
            SELECT id, content, metadata, 1 - (embedding <=> %s) as score
            FROM chunks
            ORDER BY embedding <=> %s
            LIMIT %s
        ''', (q_emb, q_emb, top_k))
    
    rows = cur.fetchall()
    candidates = [{"id": r[0], "content": r[1], "metadata": r[2], "score": r[3]} for r in rows]
    
    # BM25 full-text boost - optional hybrid fusion
    cur.execute('''
        SELECT id, content, metadata, ts_rank(tsv, plainto_tsquery('english', %s)) as rank
        FROM chunks
        WHERE tsv @@ plainto_tsquery('english', %s)
        ORDER BY rank DESC
        LIMIT %s
    ''', (query, query, top_k))
    ft_rows = [{"id": r[0], "content": r[1], "metadata": r[2], "score": r[3]} for r in cur.fetchall()]
    
    # Merge dedup
    seen = {c["id"]: c for c in candidates}
    for c in ft_rows:
        if c["id"] not in seen:
            seen[c["id"]] = c
    merged = list(seen.values())
    
    # Reranking stage - THE upgrade
    if not merged:
        return []
    
    reranker = get_reranker()
    pairs = [[query, c["content"]] for c in merged]
    scores = reranker.predict(pairs)
    
    reranked = sorted(zip(merged, scores), key=lambda x: x[1], reverse=True)
    final = [ {**doc, "rerank_score": float(score)} for doc, score in reranked[:final_k] ]
    
    cur.close()
    conn.close()
    return final
