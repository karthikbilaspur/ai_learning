from openai import OpenAI
from .config import OPENAI_API_KEY, LLM_MODEL

client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

SYSTEM_PROMPT = '''You are a helpful assistant for "Chat with my documents".
Rules:
1. Answer ONLY from the provided context.
2. If not in context, say "I couldn't find that in your documents."
3. Always cite sources as [chunk_id] after the sentence.
4. Be concise, but include page numbers/filename if present in metadata.
5. If user asks for summary, summarize across chunks.
'''

def build_prompt(context_chunks, question, chat_history=None):
    ctx = "\n\n".join([f"[{c['id']}] (File: {c['metadata'].get('filename')} Page: {c['metadata'].get('page','N/A')})\n{c['content']}" for c in context_chunks])
    hist = ""
    if chat_history:
        hist = "\n".join([f"{m['role']}: {m['content']}" for m in chat_history[-6:]])
    return f"{SYSTEM_PROMPT}\n\nChat History:\n{hist}\n\nContext:\n{ctx}\n\nQuestion: {question}\nAnswer:"

def generate_answer(context_chunks, question, chat_history=None, stream=False):
    if not client:
        # Fallback mock if no key - returns context
        return f"(Mock LLM - set OPENAI_API_KEY)\nBased on {len(context_chunks)} chunks, the answer to '{question}' is in the context.\n\n" + "\n".join([c['content'][:300] for c in context_chunks])
    
    prompt = build_prompt(context_chunks, question, chat_history)
    if stream:
        return client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role":"user","content": prompt}],
            temperature=0.2,
            stream=True
        )
    else:
        resp = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role":"user","content": prompt}],
            temperature=0.2
        )
        return resp.choices[0].message.content
