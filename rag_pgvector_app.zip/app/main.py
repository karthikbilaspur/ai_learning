from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from .retrieval import hybrid_search
from .llm import generate_answer
from .db import get_conn, init_db
import uuid

app = FastAPI(title="Chat with Docs - pgvector RAG")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ChatRequest(BaseModel):
    question: str
    session_id: str = None
    filename_filter: str = None
    top_k: int = 8

@app.on_event("startup")
def startup():
    init_db()

@app.get("/")
def health():
    return {"status":"ok","db":"pgvector","features":["hybrid_search","reranking","chat_history"]}

@app.post("/chat")
def chat(req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())
    
    # get history
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT role, content FROM chat_history WHERE session_id=%s ORDER BY id ASC LIMIT 20", (session_id,))
    history = [{"role": r[0], "content": r[1]} for r in cur.fetchall()]
    
    # retrieve + rerank
    chunks = hybrid_search(req.question, final_k=req.top_k, filename_filter=req.filename_filter)
    
    if not chunks:
        answer = "I couldn't find that in your documents."
    else:
        answer = generate_answer(chunks, req.question, chat_history=history)
    
    # save history
    cur.execute("INSERT INTO chat_history (session_id, role, content) VALUES (%s,%s,%s)", (session_id, "user", req.question))
    cur.execute("INSERT INTO chat_history (session_id, role, content) VALUES (%s,%s,%s)", (session_id, "assistant", str(answer)))
    conn.commit()
    cur.close()
    conn.close()
    
    return {"session_id": session_id, "answer": answer, "sources": chunks}

@app.get("/documents")
def list_docs():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, filename, total_chunks, created_at FROM documents ORDER BY created_at DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return [{"id": r[0], "filename": r[1], "chunks": r[2], "created_at": str(r[3])} for r in rows]

@app.delete("/documents/{doc_id}")
def delete_doc(doc_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM documents WHERE id=%s", (doc_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"deleted": doc_id}
