import pathlib, re, json
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
from .db import get_conn, init_db
from .config import EMBEDDING_MODEL
import argparse

splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=150,
    separators=["\n## ", "\n### ", "\n\n", "\n", ". ", " "]
)

def load_file(path: pathlib.Path):
    if path.suffix.lower() == ".pdf":
        reader = PdfReader(str(path))
        texts = []
        for i, page in enumerate(reader.pages):
            t = page.extract_text() or ""
            if t.strip():
                texts.append((t, {"page": i+1}))
        return texts
    elif path.suffix.lower() in [".md", ".txt"]:
        txt = path.read_text(encoding="utf-8", errors="ignore")
        return [(txt, {})]
    else:
        return []

def ingest(folder="docs"):
    init_db()
    model = SentenceTransformer(EMBEDDING_MODEL)
    conn = get_conn()
    cur = conn.cursor()
    
    docs_path = pathlib.Path(folder)
    for file in docs_path.rglob("*"):
        if not file.is_file(): continue
        if file.suffix.lower() not in [".pdf",".md",".txt"]: continue
        
        print(f"Ingesting {file}...")
        cur.execute("INSERT INTO documents (filename, filetype) VALUES (%s,%s) RETURNING id", (str(file), file.suffix))
        doc_id = cur.fetchone()[0]
        
        pages = load_file(file)
        all_chunks = []
        for text, meta in pages:
            chunks = splitter.split_text(text)
            for ch in chunks:
                all_chunks.append((ch, {**meta, "filename": str(file)}))
        
        print(f"  -> {len(all_chunks)} chunks")
        embeddings = model.encode([c[0] for c in all_chunks], show_progress_bar=True, batch_size=32)
        
        rows = []
        for (content, meta), emb in zip(all_chunks, embeddings):
            rows.append((doc_id, content, json.dumps(meta), emb.tolist()))
        
        # bulk insert
        from psycopg2.extras import execute_values
        execute_values(cur, "INSERT INTO chunks (document_id, content, metadata, embedding) VALUES %s", rows)
        cur.execute("UPDATE documents SET total_chunks=%s WHERE id=%s", (len(rows), doc_id))
        conn.commit()
    
    cur.close()
    conn.close()
    print("Ingestion done")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", default="docs")
    args = parser.parse_args()
    ingest(args.folder)
