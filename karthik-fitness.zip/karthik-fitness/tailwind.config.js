/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        surface: {
          light: '#F5F6F3',
          dark: '#0E1512',
        },
        card: {
          light: '#FFFFFF',
          dark: '#161F1B',
        },
        ink: {
          light: '#141815',
          dark: '#EDEFEC',
        },
        muted: {
          light: '#5B6660',
          dark: '#9AA69F',
        },
        kinetic: {
          DEFAULT: '#FF5A1F',
          light: '#FF7A47',
          dark: '#E24E17',
        },
        pulse: {
          DEFAULT: '#3DDC97',
          dark: '#2FBD81',
        },
        border: {
          light: '#E2E4DF',
          dark: '#243029',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      clipPath: {
        angled: 'polygon(0 0, 100% 0, 100% 92%, 0 100%)',
      },
    },
  },
  plugins: [],
}
