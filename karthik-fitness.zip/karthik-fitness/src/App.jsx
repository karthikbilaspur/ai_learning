import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import Dashboard from './components/Dashboard.jsx'
import Services from './components/Services.jsx'
import About from './components/About.jsx'
import Testimonials from './components/Testimonials.jsx'
import BookingForm from './components/BookingForm.jsx'
import Footer from './components/Footer.jsx'

export default function App() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-surface-light dark:bg-surface-dark text-ink-light dark:text-ink-dark">
      <Navbar />
      <main>
        <Hero />
        <Dashboard />
        <Services />
        <About />
        <Testimonials />
        <BookingForm />
      </main>
      <Footer />
    </div>
  )
}
