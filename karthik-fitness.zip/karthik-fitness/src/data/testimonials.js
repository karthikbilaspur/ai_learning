export const testimonials = [
  {
    id: 1,
    name: 'Ananya Rao',
    initials: 'AR',
    rating: 5,
    quote: 'Karthik completely changed the way I approach fitness. The structured workouts and progress tracking keep me consistent and motivated.',
  },
  {
    id: 2,
    name: 'Vikram Shetty',
    initials: 'VS',
    rating: 5,
    quote: "Six months in and I've hit strength numbers I didn't think were possible. The plans are realistic and actually fit my work schedule.",
  },
  {
    id: 3,
    name: 'Meera Iyer',
    initials: 'MI',
    rating: 5,
    quote: 'What stands out is the accountability. Seeing my weekly progress laid out makes it so much easier to stay on track.',
  },
  {
    id: 4,
    name: 'Rohan Nair',
    initials: 'RN',
    rating: 4,
    quote: 'Solid coaching, clear communication, and a training style that actually adjusts to how my body responds week to week.',
  },
]
