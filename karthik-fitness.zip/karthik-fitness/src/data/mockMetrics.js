// Static mock data for v1. Dashboard is visually complete but non-interactive —
// no click handlers or live data fetching. Swap this file for an API response
// when a backend is connected; component props/shape should not need to change.

export const statCards = [
  { id: 'steps', label: 'Steps', value: '8,426', unit: '', icon: 'Footprints' },
  { id: 'calories', label: 'Calories Burned', value: '624', unit: 'kcal', icon: 'Flame' },
  { id: 'workout', label: 'Workout Time', value: '58', unit: 'min', icon: 'Timer' },
  { id: 'heartrate', label: 'Heart Rate', value: '128', unit: 'BPM', icon: 'HeartPulse' },
  { id: 'weight', label: 'Current Weight', value: '72.4', unit: 'kg', icon: 'Scale' },
  { id: 'goal', label: 'Weekly Goal', value: '82', unit: '%', icon: 'Target' },
]

export const weeklyActivity = [
  { day: 'Mon', minutes: 45 },
  { day: 'Tue', minutes: 62 },
  { day: 'Wed', minutes: 30 },
  { day: 'Thu', minutes: 58 },
  { day: 'Fri', minutes: 70 },
  { day: 'Sat', minutes: 40 },
  { day: 'Sun', minutes: 20 },
]

export const recentWorkouts = [
  { id: 1, type: 'Strength Training — Upper Body', duration: '58 min', date: 'Today' },
  { id: 2, type: 'HIIT Circuit', duration: '32 min', date: 'Yesterday' },
  { id: 3, type: 'Mobility & Core', duration: '25 min', date: '2 days ago' },
  { id: 4, type: 'Strength Training — Lower Body', duration: '52 min', date: '3 days ago' },
]

export const weeklyGoalPercent = 82
