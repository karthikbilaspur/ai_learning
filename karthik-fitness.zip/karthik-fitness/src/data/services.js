export const services = [
  {
    id: 'personal-training',
    icon: 'Dumbbell',
    title: 'Personal Training',
    description: 'One-on-one coaching designed around your goals, schedule, and current fitness level.',
  },
  {
    id: 'workout-plans',
    icon: 'ClipboardList',
    title: 'Custom Workout Plans',
    description: 'Structured training programs that adapt as you get stronger and your goals shift.',
  },
  {
    id: 'nutrition',
    icon: 'Apple',
    title: 'Nutrition Guidance',
    description: 'Practical, sustainable nutrition guidance that supports training and everyday life.',
  },
  {
    id: 'tracking',
    icon: 'LineChart',
    title: 'Progress Tracking',
    description: 'Track workouts, measurements, and activity over time so progress is never a guess.',
  },
]
