import { useState } from 'react'
import { CheckCircle2, AlertCircle, Loader2 } from 'lucide-react'

const initialForm = {
  fullName: '',
  email: '',
  phone: '',
  preferredDate: '',
  preferredTime: '',
  fitnessGoal: '',
  message: '',
}

// Isolated submission function — this is the single place to swap in a real
// API call later (e.g. fetch('/api/bookings', { method: 'POST', body: ... })).
// Currently simulates a network request against mock data only.
async function handleBookingSubmit(formData) {
  await new Promise((resolve) => setTimeout(resolve, 900))
  // Simulated success. Replace with real fetch/axios call + error handling.
  return { ok: true }
}

function validate(form) {
  const errors = {}
  if (!form.fullName.trim()) errors.fullName = 'Full name is required.'
  if (!form.email.trim()) {
    errors.email = 'Email is required.'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    errors.email = 'Enter a valid email address.'
  }
  if (!form.phone.trim()) errors.phone = 'Phone number is required.'
  if (!form.preferredDate) errors.preferredDate = 'Pick a preferred date.'
  if (!form.preferredTime) errors.preferredTime = 'Pick a preferred time.'
  if (!form.fitnessGoal) errors.fitnessGoal = 'Select a fitness goal.'
  return errors
}

export default function BookingForm() {
  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState('idle') // idle | loading | success | error

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const validationErrors = validate(form)
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) return

    setStatus('loading')
    try {
      const result = await handleBookingSubmit(form)
      if (result.ok) {
        setStatus('success')
        setForm(initialForm)
      } else {
        setStatus('error')
      }
    } catch {
      setStatus('error')
    }
  }

  const inputClass = (field) =>
    `w-full rounded-md border bg-surface-light dark:bg-surface-dark px-4 py-3 text-sm outline-none transition-colors focus:border-kinetic ${
      errors[field] ? 'border-red-500' : 'border-border-light dark:border-border-dark'
    }`

  return (
    <section id="contact" className="py-20 sm:py-24">
      <div className="mx-auto max-w-3xl px-5 sm:px-8">
        <div className="mb-10 text-center">
          <p className="mb-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-kinetic">
            Booking
          </p>
          <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Ready to Start?
          </h2>
          <p className="mt-3 text-muted-light dark:text-muted-dark">
            Book your session and take the first step toward a stronger, healthier you.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          noValidate
          className="rounded-2xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-6 sm:p-8"
        >
          {status === 'success' && (
            <div className="mb-6 flex items-center gap-2 rounded-md bg-pulse/10 px-4 py-3 text-sm text-pulse-dark">
              <CheckCircle2 size={18} className="shrink-0" />
              <span>Booking request received. Karthik's team will confirm your slot shortly.</span>
            </div>
          )}
          {status === 'error' && (
            <div className="mb-6 flex items-center gap-2 rounded-md bg-red-500/10 px-4 py-3 text-sm text-red-600 dark:text-red-400">
              <AlertCircle size={18} className="shrink-0" />
              <span>Something went wrong. Please try again.</span>
            </div>
          )}

          <div className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="fullName" className="mb-1.5 block text-sm font-medium">Full Name</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                value={form.fullName}
                onChange={handleChange}
                className={inputClass('fullName')}
                aria-invalid={!!errors.fullName}
                aria-describedby={errors.fullName ? 'fullName-error' : undefined}
              />
              {errors.fullName && <p id="fullName-error" className="mt-1.5 text-xs text-red-500">{errors.fullName}</p>}
            </div>

            <div>
              <label htmlFor="email" className="mb-1.5 block text-sm font-medium">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                className={inputClass('email')}
                aria-invalid={!!errors.email}
                aria-describedby={errors.email ? 'email-error' : undefined}
              />
              {errors.email && <p id="email-error" className="mt-1.5 text-xs text-red-500">{errors.email}</p>}
            </div>

            <div>
              <label htmlFor="phone" className="mb-1.5 block text-sm font-medium">Phone Number</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={form.phone}
                onChange={handleChange}
                className={inputClass('phone')}
                aria-invalid={!!errors.phone}
                aria-describedby={errors.phone ? 'phone-error' : undefined}
              />
              {errors.phone && <p id="phone-error" className="mt-1.5 text-xs text-red-500">{errors.phone}</p>}
            </div>

            <div>
              <label htmlFor="preferredDate" className="mb-1.5 block text-sm font-medium">Preferred Date</label>
              <input
                id="preferredDate"
                name="preferredDate"
                type="date"
                value={form.preferredDate}
                onChange={handleChange}
                className={inputClass('preferredDate')}
                aria-invalid={!!errors.preferredDate}
                aria-describedby={errors.preferredDate ? 'preferredDate-error' : undefined}
              />
              {errors.preferredDate && <p id="preferredDate-error" className="mt-1.5 text-xs text-red-500">{errors.preferredDate}</p>}
            </div>

            <div>
              <label htmlFor="preferredTime" className="mb-1.5 block text-sm font-medium">Preferred Time</label>
              <input
                id="preferredTime"
                name="preferredTime"
                type="time"
                value={form.preferredTime}
                onChange={handleChange}
                className={inputClass('preferredTime')}
                aria-invalid={!!errors.preferredTime}
                aria-describedby={errors.preferredTime ? 'preferredTime-error' : undefined}
              />
              {errors.preferredTime && <p id="preferredTime-error" className="mt-1.5 text-xs text-red-500">{errors.preferredTime}</p>}
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="fitnessGoal" className="mb-1.5 block text-sm font-medium">Fitness Goal</label>
              <select
                id="fitnessGoal"
                name="fitnessGoal"
                value={form.fitnessGoal}
                onChange={handleChange}
                className={inputClass('fitnessGoal')}
                aria-invalid={!!errors.fitnessGoal}
                aria-describedby={errors.fitnessGoal ? 'fitnessGoal-error' : undefined}
              >
                <option value="">Select a goal</option>
                <option value="weight-loss">Weight Loss</option>
                <option value="muscle-gain">Muscle Gain</option>
                <option value="general-fitness">General Fitness</option>
                <option value="athletic-performance">Athletic Performance</option>
              </select>
              {errors.fitnessGoal && <p id="fitnessGoal-error" className="mt-1.5 text-xs text-red-500">{errors.fitnessGoal}</p>}
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="message" className="mb-1.5 block text-sm font-medium">
                Message <span className="text-muted-light dark:text-muted-dark font-normal">(optional)</span>
              </label>
              <textarea
                id="message"
                name="message"
                rows={4}
                value={form.message}
                onChange={handleChange}
                className={inputClass('message')}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={status === 'loading'}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-md bg-kinetic px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-kinetic-dark disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto"
          >
            {status === 'loading' && <Loader2 size={16} className="animate-spin" />}
            {status === 'loading' ? 'Booking...' : 'Book Now'}
          </button>
        </form>
      </div>
    </section>
  )
}
