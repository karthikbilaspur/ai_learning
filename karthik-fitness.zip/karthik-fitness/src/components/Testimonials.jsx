import { Star } from 'lucide-react'
import { testimonials } from '../data/testimonials.js'

export default function Testimonials() {
  return (
    <section id="testimonials" className="bg-card-light/40 dark:bg-card-dark/30 py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mb-12 max-w-2xl">
          <p className="mb-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-kinetic">
            Testimonials
          </p>
          <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Results, in their words
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="flex flex-col rounded-xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-6"
            >
              <div className="mb-4 flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className={i < t.rating ? 'fill-kinetic text-kinetic' : 'fill-none text-border-light dark:text-border-dark'}
                  />
                ))}
              </div>
              <p className="flex-1 text-sm leading-relaxed text-ink-light dark:text-ink-dark">
                "{t.quote}"
              </p>
              <div className="mt-5 flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-kinetic/10 font-mono text-xs font-semibold text-kinetic">
                  {t.initials}
                </span>
                <span className="text-sm font-medium">{t.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
