import { UserCheck, LineChart, MapPin } from 'lucide-react'

const trustIndicators = [
  { icon: UserCheck, label: 'Personalized Training' },
  { icon: LineChart, label: 'Progress Tracking' },
  { icon: MapPin, label: 'Bengaluru Based' },
]

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-2 lg:py-28">
        <div>
          <p className="mb-4 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-kinetic">
            Coaching · Tracking · Bengaluru
          </p>
          <h1 className="font-display text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
            Train Smarter. Track Better.{' '}
            <span className="text-kinetic">Become Your Strongest Self.</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-muted-light dark:text-muted-dark">
            Personalized fitness coaching and intelligent progress tracking designed to help you build consistency, strength, and confidence.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href="#contact"
              className="rounded-md bg-kinetic px-7 py-3.5 text-center text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 hover:bg-kinetic-dark"
            >
              Book Now
            </a>
            <a
              href="#tracker"
              className="rounded-md border border-border-light dark:border-border-dark px-7 py-3.5 text-center text-sm font-semibold text-ink-light dark:text-ink-dark transition-colors hover:bg-card-light dark:hover:bg-card-dark"
            >
              Track Your Progress
            </a>
          </div>

          <dl className="mt-10 grid grid-cols-1 gap-3 sm:grid-cols-3">
            {trustIndicators.map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2 text-sm text-muted-light dark:text-muted-dark">
                <Icon size={16} className="text-pulse shrink-0" />
                <span>{label}</span>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative">
          <div className="angled-corner overflow-hidden rounded-2xl">
            <img
              src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=1200&q=80"
              alt="Athlete mid strength-training rep, focused and in motion"
              loading="lazy"
              className="h-[420px] w-full object-cover sm:h-[520px]"
            />
          </div>
          <div className="absolute -bottom-6 -left-6 hidden rounded-xl bg-card-light dark:bg-card-dark border border-border-light dark:border-border-dark px-5 py-4 shadow-lg sm:block">
            <p className="font-mono text-2xl font-semibold text-kinetic">82%</p>
            <p className="text-xs text-muted-light dark:text-muted-dark">Weekly goal on track</p>
          </div>
        </div>
      </div>
    </section>
  )
}
