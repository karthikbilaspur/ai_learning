import { useState } from 'react'
import { Menu, X, Sun, Moon, Dumbbell } from 'lucide-react'
import { useTheme } from '../context/ThemeContext.jsx'

const links = [
  { label: 'Home', href: '#home' },
  { label: 'Services', href: '#services' },
  { label: 'Tracker', href: '#tracker' },
  { label: 'About', href: '#about' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const { theme, toggleTheme } = useTheme()

  return (
    <header className="sticky top-0 z-50 border-b border-border-light dark:border-border-dark bg-surface-light/90 dark:bg-surface-dark/90 backdrop-blur-md">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
        <a href="#home" className="flex items-center gap-2 font-display text-lg font-700 tracking-tight">
          <span className="flex h-9 w-9 items-center justify-center rounded-md bg-kinetic text-white">
            <Dumbbell size={18} strokeWidth={2.5} />
          </span>
          <span className="font-display font-semibold">Karthik Fitness</span>
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm font-medium text-muted-light dark:text-muted-dark transition-colors hover:text-ink-light dark:hover:text-ink-dark"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-border-light dark:border-border-dark text-ink-light dark:text-ink-dark transition-colors hover:bg-card-light dark:hover:bg-card-dark"
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          <a
            href="#contact"
            className="hidden rounded-md bg-kinetic px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-kinetic-dark sm:inline-block"
          >
            Book Now
          </a>

          <button
            className="flex h-10 w-10 items-center justify-center rounded-md text-ink-light dark:text-ink-dark md:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="border-t border-border-light dark:border-border-dark bg-surface-light dark:bg-surface-dark md:hidden">
          <ul className="flex flex-col gap-1 px-5 py-4">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-md px-3 py-3 text-base font-medium text-ink-light dark:text-ink-dark hover:bg-card-light dark:hover:bg-card-dark"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li className="pt-2">
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className="block rounded-md bg-kinetic px-5 py-3 text-center text-base font-semibold text-white"
              >
                Book Now
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  )
}
