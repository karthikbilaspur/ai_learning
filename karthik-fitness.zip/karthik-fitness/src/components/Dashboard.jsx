import { Footprints, Flame, Timer, HeartPulse, Scale, Target, Activity } from 'lucide-react'
import { BarChart, Bar, XAxis, ResponsiveContainer, Tooltip } from 'recharts'
import { statCards, weeklyActivity, recentWorkouts, weeklyGoalPercent } from '../data/mockMetrics.js'

const iconMap = { Footprints, Flame, Timer, HeartPulse, Scale, Target }

export default function Dashboard() {
  const circumference = 2 * Math.PI * 54
  const offset = circumference - (weeklyGoalPercent / 100) * circumference

  return (
    <section id="tracker" className="bg-card-light/40 dark:bg-card-dark/30 py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mb-12 max-w-2xl">
          <p className="mb-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-kinetic">
            Your Dashboard
          </p>
          <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            A clear view of where you stand
          </h2>
          <p className="mt-3 text-muted-light dark:text-muted-dark">
            Sample data shown below — this is a preview of the tracking experience, not a live feed.
          </p>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {statCards.map((stat) => {
            const Icon = iconMap[stat.icon]
            return (
              <div
                key={stat.id}
                className="rounded-xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-4 transition-shadow hover:shadow-md"
              >
                <Icon size={18} className="mb-3 text-kinetic" />
                <p className="font-mono text-xl font-semibold leading-none sm:text-2xl">
                  {stat.value}
                  <span className="ml-1 text-xs font-normal text-muted-light dark:text-muted-dark">{stat.unit}</span>
                </p>
                <p className="mt-2 text-xs text-muted-light dark:text-muted-dark">{stat.label}</p>
              </div>
            )
          })}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          {/* Weekly activity chart */}
          <div className="rounded-xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-6 lg:col-span-2">
            <h3 className="mb-4 font-display text-lg font-semibold">Weekly Activity</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyActivity}>
                  <XAxis
                    dataKey="day"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: '#9AA69F' }}
                  />
                  <Tooltip
                    cursor={{ fill: 'rgba(255,90,31,0.08)' }}
                    contentStyle={{ borderRadius: 8, border: '1px solid #E2E4DF', fontSize: 13 }}
                  />
                  <Bar dataKey="minutes" fill="#FF5A1F" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Goal ring */}
          <div className="flex flex-col items-center justify-center rounded-xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-6">
            <h3 className="mb-4 self-start font-display text-lg font-semibold">Weekly Goal</h3>
            <svg width="140" height="140" viewBox="0 0 140 140">
              <circle cx="70" cy="70" r="54" fill="none" stroke="#E2E4DF" strokeWidth="12" />
              <circle
                cx="70"
                cy="70"
                r="54"
                fill="none"
                stroke="#3DDC97"
                strokeWidth="12"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                transform="rotate(-90 70 70)"
              />
              <text x="70" y="76" textAnchor="middle" className="fill-ink-light dark:fill-ink-dark" style={{ font: '600 22px "JetBrains Mono", monospace' }}>
                {weeklyGoalPercent}%
              </text>
            </svg>
            <p className="mt-2 text-center text-xs text-muted-light dark:text-muted-dark">
              82% of this week's target reached
            </p>
          </div>
        </div>

        {/* Recent workouts */}
        <div className="mt-6 rounded-xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-6">
          <h3 className="mb-4 font-display text-lg font-semibold">Recent Workouts</h3>
          <ul className="divide-y divide-border-light dark:divide-border-dark">
            {recentWorkouts.map((w) => (
              <li key={w.id} className="flex items-center justify-between gap-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-kinetic/10 text-kinetic">
                    <Activity size={16} />
                  </span>
                  <span className="text-sm font-medium">{w.type}</span>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-light dark:text-muted-dark">
                  <span className="font-mono">{w.duration}</span>
                  <span>{w.date}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
