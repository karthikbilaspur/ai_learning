import { Dumbbell, Instagram, Facebook, Twitter, MapPin, Mail, Phone } from 'lucide-react'

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Services', href: '#services' },
  { label: 'Tracker', href: '#tracker' },
  { label: 'About', href: '#about' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
]

export default function Footer() {
  return (
    <footer className="border-t border-border-light dark:border-border-dark bg-card-light/40 dark:bg-card-dark/30">
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="#home" className="mb-3 flex items-center gap-2 font-display text-base font-semibold">
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-kinetic text-white">
                <Dumbbell size={16} strokeWidth={2.5} />
              </span>
              Karthik Fitness
            </a>
            <p className="text-sm text-muted-light dark:text-muted-dark leading-relaxed">
              Personal training and progress tracking built around consistency and real results.
            </p>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold">Navigate</h4>
            <ul className="space-y-2">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="text-sm text-muted-light dark:text-muted-dark hover:text-kinetic transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold">Contact</h4>
            <ul className="space-y-2 text-sm text-muted-light dark:text-muted-dark">
              <li className="flex items-center gap-2"><MapPin size={14} /> Bengaluru, India</li>
              <li className="flex items-center gap-2"><Mail size={14} /> hello@karthikfitness.in</li>
              <li className="flex items-center gap-2"><Phone size={14} /> +91 98765 43210</li>
            </ul>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-semibold">Follow</h4>
            <div className="flex gap-3">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social media link"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-border-light dark:border-border-dark text-muted-light dark:text-muted-dark transition-colors hover:border-kinetic hover:text-kinetic"
                >
                  <Icon size={15} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-border-light dark:border-border-dark pt-6 text-center text-xs text-muted-light dark:text-muted-dark">
          © {new Date().getFullYear()} Karthik Fitness. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
