import { CheckCircle2 } from 'lucide-react'

const points = [
  'Coaching philosophy built on consistency over intensity',
  'Personalized programs shaped around your life, not a template',
  'Sustainable progress you can measure week over week',
]

export default function About() {
  return (
    <section id="about" className="py-20 sm:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-2">
        <div className="angled-corner overflow-hidden rounded-2xl order-2 lg:order-1">
          <img
            src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=1000&q=80"
            alt="Karthik coaching a client through a strength training session"
            loading="lazy"
            className="h-[420px] w-full object-cover"
          />
        </div>

        <div className="order-1 lg:order-2">
          <p className="mb-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-kinetic">
            About Karthik
          </p>
          <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Coaching built around you, not a program
          </h2>
          <p className="mt-5 text-muted-light dark:text-muted-dark leading-relaxed">
            Based in Bengaluru, Karthik has spent over a decade helping clients build strength and confidence through personalized, sustainable training. His approach blends structured programming with real accountability — every plan adapts as you do.
          </p>

          <ul className="mt-6 space-y-3">
            {points.map((point) => (
              <li key={point} className="flex items-start gap-3 text-sm">
                <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-pulse" />
                <span>{point}</span>
              </li>
            ))}
          </ul>

          <a
            href="#contact"
            className="mt-8 inline-block rounded-md bg-kinetic px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-kinetic-dark"
          >
            Start Your Fitness Journey
          </a>
        </div>
      </div>
    </section>
  )
}
