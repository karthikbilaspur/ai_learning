import { Dumbbell, ClipboardList, Apple, LineChart } from 'lucide-react'
import { services } from '../data/services.js'

const iconMap = { Dumbbell, ClipboardList, Apple, LineChart }

export default function Services() {
  return (
    <section id="services" className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mb-12 max-w-2xl">
          <p className="mb-3 font-mono text-xs font-semibold uppercase tracking-[0.2em] text-kinetic">
            Services
          </p>
          <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Everything You Need to Reach Your Goals
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service) => {
            const Icon = iconMap[service.icon]
            return (
              <div
                key={service.id}
                className="group rounded-xl border border-border-light dark:border-border-dark bg-card-light dark:bg-card-dark p-6 transition-all hover:-translate-y-1 hover:shadow-lg"
              >
                <span className="mb-5 flex h-11 w-11 items-center justify-center rounded-lg bg-kinetic/10 text-kinetic transition-colors group-hover:bg-kinetic group-hover:text-white">
                  <Icon size={20} />
                </span>
                <h3 className="mb-2 font-display text-lg font-semibold">{service.title}</h3>
                <p className="text-sm leading-relaxed text-muted-light dark:text-muted-dark">
                  {service.description}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
