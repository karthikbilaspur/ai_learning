# Karthik Fitness

Production-ready React + Tailwind marketing/tracker site for a Bengaluru-based personal trainer.

## Setup

```bash
npm install
npm run dev
```

Open the printed local URL (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Notes

- **No backend in v1.** All dashboard/testimonial/service data lives in `src/data/`. The booking form's
  submit logic is isolated in `handleBookingSubmit()` inside `src/components/BookingForm.jsx` — that's
  the one place to wire up a real API call later.
- Dark/light mode is handled by `src/context/ThemeContext.jsx` and persists via `localStorage`.
- Dashboard (`src/components/Dashboard.jsx`) is intentionally static/non-interactive in v1 — it's a
  preview of the tracking UI, not a live feed. This is called out in a code comment so it isn't
  mistaken for a bug.
- Images are loaded from Unsplash via direct URLs with native lazy loading. Swap for real photography
  of Karthik/clients when available.
- This environment could not run `npm install` / `npm run build` (no network access) to test-compile
  the project before packaging — every file was written and manually checked for syntax balance, but
  run `npm install && npm run dev` locally as your first step to confirm.
